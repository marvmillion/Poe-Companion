// PoE 1 campaign route, English (exile-leveling by HeartofPhos, MIT)
window.CAMPAIGN_EN = [
{
"tip": "Grab a Quicksilver Flask and a movement skill right away – it saves time for the whole campaign.",
"title": "Act 1",
"steps": [
{
"t": "Find and kill <k>Hillock</k>",
"sub": []
},
{
"t": "Continue to <z>Lioneye's Watch</z>",
"sub": []
},
{
"t": "Hand in the quest <q>Enemy at the Gate</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Coast</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Continue to <z>The Mud Flats</z>",
"sub": []
},
{
"t": "Find 3× <i>Glyph</i>",
"sub": [
"Little streams connect the 3 Rhoa nests",
"Usually form a triangle, but will rarely form a line"
]
},
{
"t": "Continue to <z>The Submerged Passage</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Coast</z>",
"sub": []
},
{
"t": "Continue to <z>The Tidal Island</z>",
"sub": []
},
{
"t": "Find and kill <k>Hailrake</k>, take <i>Medicine Chest</i>",
"sub": [
"Go <d>←</d> <i>west</i>",
"If you find a ledge, turn around and go <d>→</d> <i>east</i>",
"Recommended Level: 4"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Breaking Some Eggs</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Mercy Mission</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Submerged Passage</z>",
"sub": []
},
{
"t": "Continue to <z>The Flooded Depths</z>",
"sub": [
"Go right of the bridge"
]
},
{
"t": "Find and kill <k>The Dweller of the Deep</k>",
"sub": [
"Search opposite the entrance",
"Look for the large empty room"
]
},
{
"t": "Take the <i>Boat</i> ➜ <z>The Submerged Passage</z>",
"sub": []
},
{
"t": "Continue to <z>The Ledge</z>",
"sub": []
},
{
"t": "Continue to <z>The Climb</z>",
"sub": []
},
{
"t": "Continue to <z>The Lower Prison</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Lioneye's Watch</z>",
"sub": []
},
{
"t": "Hand in the quest <q>The Dweller of the Deep</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>The Caged Brute</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Lower Prison</z>",
"sub": []
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": [
"Usually <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Continue to <z>The Upper Prison</z>",
"sub": []
},
{
"t": "Find <i>Chemist's Strongbox</i>",
"sub": [
"Look for map icon, access with nearby switch",
"High chance for <i>Quicksilver Flask</i>",
"Vendor <i>Quicksilver Flask</i> + <i>Orb of Augmentation</i> + Normal <i>Boots</i>",
"Vendor <i>Quicksilver Flask</i> + <i>Orb of Augmentation</i> + Movement Speed <i>Boots</i>"
]
},
{
"t": "Go to <a>The Warden's Quarters</a>, kill <k>Brutus, Lord Incarcerator</k>",
"sub": [
"Recommended Level: 8"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Caged Brute</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Prisoner's Gate</z>",
"sub": []
},
{
"t": "Continue to <z>The Ship Graveyard</z>",
"sub": [
"Go down the ledge next to the road"
]
},
{
"t": "Kill <k>Captain Fairgraves</k>, take <i>Allflame</i>",
"sub": []
},
{
"t": "Continue to <z>The Cavern of Wrath</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Lioneye's Watch</z>",
"sub": []
},
{
"t": "Hand in the quest <q>The Marooned Mariner</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>The Siren's Cadence</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Cavern of Wrath</z>",
"sub": []
},
{
"t": "Continue to <z>The Cavern of Anger</z>",
"sub": [
"Follow the water"
]
},
{
"t": "Go to <a>Merveil's Lair</a>, kill <k>Merveil, the Siren</k>",
"sub": [
"Follow the water",
"Recommended Level: 12"
]
}
]
},
{
"tip": "Bandits: for almost every build, kill all three – that gives an extra passive point.",
"title": "Act 2",
"steps": [
{
"t": "Continue to <z>The Southern Forest</z>",
"sub": []
},
{
"t": "Continue to <z>The Forest Encampment</z>",
"sub": []
},
{
"t": "Continue to <z>The Old Fields</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Find <z>The Den</z>, place <l>Place portal</l>",
"sub": []
},
{
"t": "Continue to <z>The Crossroads</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Use the <w>waypoint</w> to <z>The Forest Encampment</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Take <l>Use portal</l>",
"sub": []
},
{
"t": "Continue to <z>The Den</z>",
"sub": []
},
{
"t": "Find and kill <k>The Great White Beast</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Great White Beast</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crossroads</z>",
"sub": []
},
{
"t": "Continue to <z>The Chamber of Sins Level 1</z>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Continue to <z>The Chamber of Sins Level 2</z>",
"sub": [
"Go in same direction as <w>waypoint</w>"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "Kill <k>Fidelitas, the Mourning</k>, take <i>Baleful Gem</i>",
"sub": [
"Look for the long hallway",
"Recommended Level: 14-15"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Intruders in Black</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crossroads</z>",
"sub": []
},
{
"t": "Continue to <z>The Fellshrine Ruins</z>",
"sub": [
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Continue to <z>The Crypt Level 1</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "Continue to <z>The Crypt Level 2</z>",
"sub": []
},
{
"t": "Find <i>Altar</i>, take <i>Golden Hand</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Through Sacred Ground</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Riverways</z>",
"sub": [
"Go <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Follow the road"
]
},
{
"t": "Continue to <z>The Western Forest</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Follow the road"
]
},
{
"t": "Continue to <z>The Weaver's Chambers</z>",
"sub": [
"Search the side of road opposite <w>waypoint</w>"
]
},
{
"t": "Go to <a>The Weaver's Nest</a>, kill <k>The Weaver</k>, take <i>Maligaro's Spike</i>",
"sub": [
"Try go <d>←</d> <i>west</i>, if it's blocked go <d>↗</d> <i>north-east</i>",
"Recommended Level: 16"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Sharp and Cruel</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crossroads</z>",
"sub": []
},
{
"t": "Continue to <z>The Broken Bridge</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Kill <k>Kraityn, Scarbearer</k>, take <i>Kraityn's Amulet</i>",
"sub": [
"Follow the road"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Riverways</z>",
"sub": []
},
{
"t": "Continue to <z>The Wetlands</z>",
"sub": [
"Look for 2 pillars near <w>waypoint</w>, follow the trail"
]
},
{
"t": "Find and kill <k>Oak, Skullbreaker</k>, take <i>Oak's Amulet</i>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Western Forest</z>",
"sub": [
"Search opposite direction of the encampment entrance"
]
},
{
"t": "Kill <k>Alira Darktongue</k>, take <i>Alira's Amulet</i>",
"sub": [
"Go <d>↓</d> <i>south</i> look for the torch touching the road",
"Follow the trail in the direction of the torch"
]
},
{
"t": "Kill <k>Captain Arteri</k>",
"sub": [
"Follow the road <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Take <i>Thaumetic Emblem</i>, activate <i>Thaumetic Seal</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Deal with the Bandits</q> in town, take <i>The Apex</i>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Lioneye's Watch</z>",
"sub": []
},
{
"t": "Hand in the quest <q>The Way Forward</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Wetlands</z>",
"sub": []
},
{
"t": "Poison the <i>Tree Roots</i> ➜ <z>The Vaal Ruins</z>",
"sub": []
},
{
"t": "Continue to <z>The Northern Forest</z>",
"sub": [
"S shape or L shape leads to exit"
]
},
{
"t": "Continue to <z>The Caverns</z>",
"sub": []
},
{
"t": "Continue to <z>The Ancient Pyramid</z>",
"sub": []
},
{
"t": "Go to <a>Pyramid Apex</a>, kill <k>Vaal Oversoul</k>",
"sub": [
"First floor exit will be in one of the 3 corners",
"Remaining floors will have the exit diagonally across from the entrance",
"Recommended Level: 20-22"
]
}
]
},
{
"tip": "Three Trials of Ascendancy in Act 3 – afterwards you can run the first Labyrinth.",
"title": "Act 3",
"steps": [
{
"t": "Continue to <z>The City of Sarn</z>",
"sub": []
},
{
"t": "Help and talk to <i>Clarissa</i>",
"sub": []
},
{
"t": "Continue to <z>The Sarn Encampment</z>",
"sub": []
},
{
"t": "Continue to <z>The Slums</z>",
"sub": [
"Go <d>↑</d> <i>north</i>"
]
},
{
"t": "Continue to <z>The Crematorium</z>",
"sub": [
"Follow Stairs"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "Find and kill <k>Piety</k>, take <i>Tolman's Bracelet</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Talk to <i>Clarissa</i>, take <i>Sewer Keys</i>",
"sub": []
},
{
"t": "Hand in the quest <q>Lost in Love</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Slums</z>",
"sub": [
"Go <d>↑</d> <i>north</i>"
]
},
{
"t": "Continue to <z>The Sewers</z>",
"sub": []
},
{
"t": "Find 1× <i>Platinum Bust</i>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Find 2× <i>Platinum Bust</i>",
"sub": []
},
{
"t": "Continue to <z>The Marketplace</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Continue to <z>The Catacombs</z>",
"sub": [
"Look around nearby"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Victario's Secrets</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Marketplace</z>",
"sub": []
},
{
"t": "Continue to <z>The Battlefront</z>",
"sub": [
"Search <d>↑</d> <i>north</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Find and take <i>Ribbon Spool</i>",
"sub": [
"Go <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Continue to <z>The Solaris Temple Level 1</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Continue to <z>The Solaris Temple Level 2</z>",
"sub": []
},
{
"t": "Go to <a>Eternal Laboratory</a>, get <i>crafting recipe</i>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Battlefront</z>",
"sub": []
},
{
"t": "Continue to <z>The Docks</z>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Find and take <i>Thaumetic Sulphite</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Solaris Temple Level 2</z>",
"sub": []
},
{
"t": "Talk to <i>Lady Dialla</i>",
"sub": []
},
{
"t": "Hand in the quest <q>The Ribbon Spool</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Fiery Dust</q> in town, take <i>Infernal Talc</i>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Sewers</z>",
"sub": []
},
{
"t": "Burn the <i>Undying Blockage</i>",
"sub": []
},
{
"t": "Continue to <z>The Ebony Barracks</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Kill <k>General Gravicius</k>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Continue to <z>The Lunaris Temple Level 1</z>",
"sub": []
},
{
"t": "Continue to <z>The Lunaris Temple Level 2</z>",
"sub": []
},
{
"t": "Find and kill <k>Piety</k>, take <i>Tower Key</i>",
"sub": [
"Follow stairs that are going up",
"At the fork in the road with wagons, go the route with 1 wagon, not 2"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Piety's Pets</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Sever the Right Hand</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Ebony Barracks</z>",
"sub": []
},
{
"t": "Continue to <z>The Imperial Gardens</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Follow the road"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": [
"Go <d>↑</d> <i>north</i>"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Imperial Gardens</z>",
"sub": []
},
{
"t": "Continue to <z>The Sceptre of God</z>",
"sub": []
},
{
"t": "Continue to <z>The Upper Sceptre of God</z>",
"sub": [
"Stairs spawn in one of the corners"
]
},
{
"t": "Go to <a>Tower Rooftop</a>, Kill <k>Dominus, High Templar</k>",
"sub": [
"Look for barricades"
]
}
]
},
{
"tip": "Resistances start to matter now. After Act 5 they drop by 30 %.",
"title": "Act 4",
"steps": [
{
"t": "Continue to <z>The Aqueduct</z>",
"sub": []
},
{
"t": "Continue to <z>Highgate</z>",
"sub": []
},
{
"t": "Continue to <z>The Dried Lake</z>",
"sub": []
},
{
"t": "Find and kill <k>Voll, Emperor of Purity</k>, take <i>Deshret's Banner</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Break <i>Deshret's Seal</i>",
"sub": []
},
{
"t": "Hand in the quest <q>Breaking the Seal</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Mines Level 1</z>",
"sub": []
},
{
"t": "Continue to <z>The Mines Level 2</z>",
"sub": []
},
{
"t": "Free <i>Deshret</i>",
"sub": []
},
{
"t": "Continue to <z>The Crystal Veins</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Highgate</z>",
"sub": []
},
{
"t": "Hand in the quest <q>An Indomitable Spirit</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Sarn Encampment</z>",
"sub": []
},
{
"t": "Go to <z>Aspirants' Plaza</z>, get <w>waypoint</w>",
"sub": []
},
{
"t": "<t>Complete the Labyrinth (Normal)</t>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crystal Veins</z>",
"sub": []
},
{
"t": "Continue to <z>Daresso's Dream</z>",
"sub": []
},
{
"t": "Continue to <z>The Grand Arena</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crystal Veins</z>",
"sub": []
},
{
"t": "Continue to <z>Kaom's Dream</z>",
"sub": []
},
{
"t": "Continue to <z>Kaom's Stronghold</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>",
"Follow Bridges"
]
},
{
"t": "Go to <a>Caldera of the King</a>, kill <k>King Kaom</k>, take <i>The Eye of Fury</i>",
"sub": []
},
{
"t": "<l>Use portal</l>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Grand Arena</z>",
"sub": []
},
{
"t": "Go to <a>The Ring of Blades</a>, kill <k>Daresso, King of Swords</k>, take <i>The Eye of Desire</i>",
"sub": [
"Go <d>↙</d> <i>south-west</i> follow the exits keeping <d>←</d> <i>west</i>"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crystal Veins</z>",
"sub": []
},
{
"t": "Talk to <i>Lady Dialla</i>",
"sub": []
},
{
"t": "Continue to <z>The Belly of the Beast Level 1</z>",
"sub": []
},
{
"t": "Continue to <z>The Belly of the Beast Level 2</z>",
"sub": []
},
{
"t": "Go to <a>The Bowels of the Beast</a>, kill <k>Piety, the Abomination</k>",
"sub": []
},
{
"t": "Talk to <i>Piety</i>",
"sub": []
},
{
"t": "Continue to <z>The Harvest</z>",
"sub": []
},
{
"t": "Find and kill <k>Doedre Darktongue</k>, take <i>Malachai's Lungs</i>",
"sub": []
},
{
"t": "Find and kill <k>Maligaro, The Inquisitor</k>, take <i>Malachai's Heart</i>",
"sub": []
},
{
"t": "Find and kill <k>Shavronne of Umbra</k>, take <i>Malachai's Entrails</i>",
"sub": []
},
{
"t": "Hand in the quest <q>Corpus Malachus</q> in town",
"sub": []
},
{
"t": "Go to <a>The Black Core</a>, kill <k>Malachai, The Nightmare</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Eternal Nightmare</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Ascent</z>",
"sub": []
},
{
"t": "Activate <i>The Resonator</i>, use <i>Oriath Portal</i>",
"sub": []
}
]
},
{
"tip": "End of Act 5: −30 % to all resistances. Adjust your gear beforehand!",
"title": "Act 5",
"steps": [
{
"t": "Continue to <z>The Slave Pens</z>",
"sub": []
},
{
"t": "Find and kill <k>Overseer Krow</k>",
"sub": [
"Go <d>↓</d> <i>south</i> until you find the hanged Karui",
"Loop around clockwise to go <d>←</d> <i>west</i>"
]
},
{
"t": "Continue to <z>Overseer's Tower</z>",
"sub": []
},
{
"t": "Hand in the quest <q>Return to Oriath</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Control Blocks</z>",
"sub": []
},
{
"t": "Find and take <i>Miasmeter</i>",
"sub": [
"Go <d>←</d> <i>west</i> as much as possible"
]
},
{
"t": "Find and kill <k>Justicar Casticus</k>, take <i>Eyes of Zeal</i>",
"sub": [
"Go <d>↗</d> <i>north-east</i> from <i>Miasmeter</i>"
]
},
{
"t": "Continue to <z>Oriath Square</z>",
"sub": []
},
{
"t": "Continue to <z>The Templar Courts</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Continue to <z>The Chamber of Innocence</z>",
"sub": [
"Loop around clockwise",
"Farm Level: 40-42"
]
},
{
"t": "Go to <a>Sanctum of Innocence</a>, kill <k>High Templar Avarius</k>",
"sub": [
"Go <d>↖</d> <i>north-west</i> counter-clockwise spiral"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Key to Freedom</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>In Service to Science</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Death to Purity</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Chamber of Innocence</z>",
"sub": []
},
{
"t": "Continue to <z>The Torched Courts</z>",
"sub": []
},
{
"t": "Continue to <z>The Ruined Square</z>",
"sub": [
"Loop around counter-clockwise"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Continue to <z>The Ossuary</z>",
"sub": []
},
{
"t": "Find and take <i>Sign of Purity</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Ruined Square</z>",
"sub": []
},
{
"t": "Continue to <z>The Reliquary</z>",
"sub": [
"Go <d>↙</d> <i>south-west</i> find the plaza",
"Go <d>↓</d> <i>south</i>"
]
},
{
"t": "Find 3× <i>Kitava's Torment</i>, search in the corners of the map",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Kitava's Torments</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Ruined Square</z>",
"sub": []
},
{
"t": "Continue to <z>The Cathedral Rooftop</z>",
"sub": [
"Go <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Go to <a>Cathedral Apex</a>, kill <k>Kitava, the Insatiable</k>",
"sub": []
},
{
"t": "Talk to <i>Lilly Roth</i>, Sail to Wraeclast",
"sub": []
}
]
},
{
"tip": "Three passive points in Act 6 – do not skip any.",
"title": "Act 6",
"steps": [
{
"t": "Continue to <z>Lioneye's Watch</z>",
"sub": []
},
{
"t": "Continue to <z>The Twilight Strand</z>",
"sub": []
},
{
"t": "Kill <k>Everything</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Fallen from Grace</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Coast</z>",
"sub": []
},
{
"t": "Continue to <z>The Mud Flats</z>",
"sub": []
},
{
"t": "Find and kill <k>The Dishonoured Queen</k>, take <i>Eye of Conquest</i>",
"sub": [
"<d>↗</d> <i>north-east</i> corner of area, normally by a house"
]
},
{
"t": "Continue to <z>The Karui Fortress</z>",
"sub": []
},
{
"t": "Go to <a>Tukohama's Keep</a>, kill <k>Tukohama, Karui God of War</k>",
"sub": [
"Go <d>↗</d> <i>north-east</i>",
"Find and kill the pack of monster on the island <d>↙</d> <i>south-west</i> for a <i>Tattoo</i>"
]
},
{
"t": "Continue to <z>The Ridge</z>",
"sub": [
"Go <d>↑</d> <i>north</i>"
]
},
{
"t": "Continue to <z>The Lower Prison</z>",
"sub": []
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "Continue to <z>Shavronne's Tower</z>",
"sub": []
},
{
"t": "Go to <a>Prison Rooftop</a>, kill <k>Shavronne the Returned</k> &amp; <k>Reassembled Brutus</k>",
"sub": []
},
{
"t": "Go to <a>The Warden's Chambers</a>",
"sub": []
},
{
"t": "Continue to <z>Prisoner's Gate</z>",
"sub": []
},
{
"t": "Go to <a>Valley of the Fire Drinker</a>, kill <k>Abberath, the Cloven One</k>",
"sub": [
"Go down the ledge next to the road"
]
},
{
"t": "<l>Use portal</l>",
"sub": []
},
{
"t": "Hand in the quest <q>The Cloven One</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Prisoner's Gate</z>",
"sub": []
},
{
"t": "Continue to <z>The Western Forest</z>",
"sub": [
"Follow the road",
"Look for the torch touching the road",
"Follow the trail in the direction of the torch"
]
},
{
"t": "Continue to <z>The Riverways</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Follow the road"
]
},
{
"t": "Continue to <z>The Wetlands</z>",
"sub": [
"Look for 2 pillars near <w>waypoint</w>, follow the trail"
]
},
{
"t": "Go to <a>The Spawning Ground</a>, kill <k>Ryslatha, the Puppet Mistress</k>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Father of War</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Essence of Umbra</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>The Puppet Mistress</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Riverways</z>",
"sub": []
},
{
"t": "Continue to <z>The Southern Forest</z>",
"sub": [
"Follow the road until it ends",
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Continue to <z>The Cavern of Anger</z>",
"sub": []
},
{
"t": "Take <i>The Black Flag</i>",
"sub": []
},
{
"t": "Continue to <z>The Beacon</z>",
"sub": [
"Follow the shore"
]
},
{
"t": "Complete <i>Pillar Push</i>",
"sub": []
},
{
"t": "Light the <i>Beacon</i>, throw in <i>The Black Flag</i>",
"sub": []
},
{
"t": "Talk to <i>Weylam Roth</i>, sail to <z>The Brine King's Reef</z>",
"sub": []
},
{
"t": "Go to <a>The Bring King's Throne</a>, kill <k>Tsoagoth, The Brine King</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Select <i>Pantheons</i>",
"sub": []
}
]
},
{
"tip": "Three passive points: Ralakesh, Gruthkul and Kishara's Star.",
"title": "Act 7",
"steps": [
{
"t": "Use the <w>waypoint</w> to <z>The Bridge Encampment</z>",
"sub": []
},
{
"t": "Continue to <z>The Broken Bridge</z>",
"sub": []
},
{
"t": "Find and take <i>Silver Locket</i>",
"sub": [
"Follow the road, look for the broken <w>waypoint</w>"
]
},
{
"t": "Continue to <z>The Crossroads</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Continue to <z>The Fellshrine Ruins</z>",
"sub": [
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Continue to <z>The Crypt</z>",
"sub": [
"Follow the road"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": []
},
{
"t": "Find <i>Sarcophagus</i> to next floor",
"sub": []
},
{
"t": "Find and take <i>Maligaro's Map</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Crossroads</z>",
"sub": []
},
{
"t": "Continue to <z>The Chamber of Sins Level 1</z>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Activate <i>Map Device</i> with <i>Maligaro's Map</i>",
"sub": []
},
{
"t": "Continue to <z>Maligaro's Sanctum</z>",
"sub": []
},
{
"t": "Go to <a>Maligaro's Workshop</a>, kill <k>Maligaro, the Artist</k>, take <i>Black Venom</i>",
"sub": [
"Follow edges of the zone and cross bridges in the corners",
"Typically bridges spawn in the opposite diagonal corners"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Essence of the Artist</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>The Silver Locket</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Chamber of Sins Level 1</z>",
"sub": []
},
{
"t": "Hand in the quest <q>Web of Secrets</q> in town, take <i>Obsidian Key</i>",
"sub": []
},
{
"t": "Continue to <z>The Chamber of Sins Level 2</z>",
"sub": [
"Go in same direction as <w>waypoint</w>"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": [
"Find the switch hidden behind <i>Trial of Ascendancy Plaque</i> to access <i>Hidden Gem: Quality</i>"
]
},
{
"t": "Open <i>Secret Passage</i> ➜ <z>The Den</z>",
"sub": []
},
{
"t": "Continue to <z>The Ashen Fields</z>",
"sub": []
},
{
"t": "Go to <a>The Forest Encampment</a>, kill <k>Greust, Lord of the Forest</k>",
"sub": [
"Go <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Continue to <z>The Northern Forest</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Continue to <z>The Causeway</z>",
"sub": []
},
{
"t": "Find and take <i>Kishara's Star</i>",
"sub": []
},
{
"t": "Continue to <z>The Vaal City</z>",
"sub": []
},
{
"t": "Find <w>waypoint</w>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Northern Forest</z>",
"sub": []
},
{
"t": "Continue to <z>The Dread Thicket</z>",
"sub": []
},
{
"t": "Find and take 7× <i>Firefly</i>",
"sub": []
},
{
"t": "Go to <a>Den of Despair</a>, kill <k>Gruthkul, Mother of Despair</k>",
"sub": []
},
{
"t": "<l>Use portal</l>",
"sub": []
},
{
"t": "Hand in the quest <q>The Master of a Million Faces</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Queen of Despair</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Kishara's Star</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Aspirants' Plaza</z>",
"sub": []
},
{
"t": "<t>Complete the Labyrinth (Cruel)</t>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Vaal City</z>",
"sub": []
},
{
"t": "Hand in the quest <q>Lighting the Way</q> in town",
"sub": []
},
{
"t": "Continue to <z>The Temple of Decay Level 1</z>",
"sub": [
"In the room with a central pit, look <d>↙</d> <i>south-west</i> or <d>↗</d> <i>north-east</i> for a side area containing a <i>Corrupted Unique</i>"
]
},
{
"t": "Continue to <z>The Temple of Decay Level 2</z>",
"sub": []
},
{
"t": "Go to <a>Arakaali's Web</a>, kill <k>Arakaali, Spinner of Shadows</k>",
"sub": []
}
]
},
{
"tip": "Three passive points: Tolman, Gemling Legion, Yugul.",
"title": "Act 8",
"steps": [
{
"t": "Continue to <z>The Sarn Ramparts</z>",
"sub": []
},
{
"t": "Continue to <z>The Sarn Encampment</z>",
"sub": []
},
{
"t": "Continue to <z>The Toxic Conduits</z>",
"sub": [
"Go <d>←</d> <i>west</i>"
]
},
{
"t": "Continue to <z>Doedre's Cesspool</z>",
"sub": [
"Black splashes of paint on ground points to the right direction to go"
]
},
{
"t": "Go to <a>The Cauldron</a>, kill <k>Doedre the Vile</k>",
"sub": []
},
{
"t": "Go to <a>Sewer Outlet</a>",
"sub": []
},
{
"t": "Continue to <z>The Quay</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Find and take <i>Ankh of Eternity</i>",
"sub": [
"Follow <d>←</d> <i>west</i> wall"
]
},
{
"t": "Go to <a>Resurrection Site</a>",
"sub": [
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Talk to <i>Clarissa</i>, kill <k>Tolman</k>",
"sub": []
},
{
"t": "Continue to <z>The Grain Gate</z>",
"sub": []
},
{
"t": "Find and kill <k>Gemling Legionnaires</k>",
"sub": [
"Follow the dead guards by doorways",
"Look for a book icon"
]
},
{
"t": "Continue to <z>The Imperial Fields</z>",
"sub": [
"Follow the dead guards by doorways"
]
},
{
"t": "Continue to <z>The Solaris Temple Level 1</z>",
"sub": [
"Follow the road until <w>waypoint</w>",
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": []
},
{
"t": "Continue to <z>The Solaris Temple Level 2</z>",
"sub": []
},
{
"t": "Find and kill <k>Dawn, Harbinger of Solaris</k>, take <i>Sun Orb</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Essence of the Hag</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>The Gemling Legion</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Love is Dead</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Solaris Temple Level 1</z>",
"sub": []
},
{
"t": "Continue to <z>The Solaris Concourse</z>",
"sub": []
},
{
"t": "Continue to <z>The Harbour Bridge</z>",
"sub": [
"Go <d>↙</d> <i>south-west</i>"
]
},
{
"t": "Continue to <z>The Lunaris Concourse</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Continue to <z>The Lunaris Temple Level 1</z>",
"sub": []
},
{
"t": "Continue to <z>The Lunaris Temple Level 2</z>",
"sub": []
},
{
"t": "Find and kill <k>Dusk, Harbinger of Lunaris</k>, take <i>Moon Orb</i>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Lunaris Concourse</z>",
"sub": []
},
{
"t": "Continue to <z>The Harbour Bridge</z>",
"sub": [
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Go to <a>The Sky Shrine</a>, activate <i>Statue of the Sisters</i>",
"sub": []
},
{
"t": "Kill <k>Lunaris, Eternal Moon</k> &amp; <k>Solaris, Eternal Sun</k>",
"sub": []
},
{
"t": "Continue to <z>The Blood Aqueduct</z>",
"sub": [
"Farm Level: 58-62"
]
},
{
"t": "Continue to <z>Highgate</z>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Lunaris Concourse</z>",
"sub": []
},
{
"t": "Continue to <z>The Bath House</z>",
"sub": [
"Go <d>↓</d> <i>south</i>"
]
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": [
"Search <d>←</d> <i>west</i> side"
]
},
{
"t": "Continue to <z>The High Gardens</z>",
"sub": [
"Search <d>←</d> <i>west</i> side"
]
},
{
"t": "Go to <a>The Pools of Terror</a>, kill <k>Yugul, Reflection of Terror</k>",
"sub": []
},
{
"t": "<l>Use portal</l>",
"sub": []
},
{
"t": "Hand in the quest <q>Reflection of Terror</q> in town",
"sub": []
}
]
},
{
"tip": "Two passive points: Shakari and Garukhan.",
"title": "Act 9",
"steps": [
{
"t": "Use the <w>waypoint</w> to <z>Highgate</z>",
"sub": []
},
{
"t": "Continue to <z>The Descent</z>",
"sub": []
},
{
"t": "Continue to <z>The Vastiri Desert</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>→</d> <i>east</i>"
]
},
{
"t": "Find and take <i>The Storm Blade</i>",
"sub": []
},
{
"t": "Continue to <z>The Foothills</z>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↗</d> <i>north-east</i> until you find the cliff",
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Continue to <z>The Boiling Lake</z>",
"sub": []
},
{
"t": "Find and Kill <k>The Basilisk</k>, take <i>Basilisk Acid</i>",
"sub": [
"Go <d>↗</d> <i>north-east</i> look for petrified soldiers"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Talk to <i>Sin</i>",
"sub": []
},
{
"t": "Hand in the quest <q>The Storm Blade</q> in town",
"sub": []
},
{
"t": "Hand in the quest <q>Queen of the Sands</q> in town, take <i>Bottled Storm</i>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Vastiri Desert</z>",
"sub": []
},
{
"t": "Continue to <z>The Oasis</z>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Go to <a>The Sand Pit</a>, kill <k>Shakari, Queen of the Sands</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Queen of the Sands</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Foothills</z>",
"sub": []
},
{
"t": "Continue to <z>The Tunnel</z>",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Before <w>waypoint</w>, complete <t>Trial of Ascendancy</t>",
"sub": [
"Look for the hidden switch halfway to <i>Trial of Ascendancy Plaque</i> in the corner opposite the entrance to access <i>Hidden Gem: Transfigured</i>"
]
},
{
"t": "Continue to <z>The Quarry</z>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↖</d> <i>north-west</i>"
]
},
{
"t": "Go to <a>Shrine of the Winds</a>, kill <k>Garukhan, Queen of the Winds</k>, take <i>Sekhema Feather</i>",
"sub": [
"<d>↗</d> <i>north-east</i> or <d>↙</d> <i>south-west</i>"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>The Ruler of Highgate</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Quarry</z>",
"sub": []
},
{
"t": "Continue to <z>The Refinery</z>",
"sub": [
"<d>↖</d> <i>north-west</i> or <d>↗</d> <i>north-east</i>",
"Look for a sewer grate leading to <a>Refinery Tunnels</a>, it is attached to the cart tracks"
]
},
{
"t": "Find and kill <k>General Adus</k>, take <i>Trarthan Powder</i>",
"sub": [
"Go <d>↗</d> <i>north-east</i> follow cart tracks"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Quarry</z>",
"sub": []
},
{
"t": "Talk to <i>Sin</i>",
"sub": []
},
{
"t": "Continue to <z>The Belly of the Beast</z>",
"sub": []
},
{
"t": "Continue to <z>The Rotting Core</z>",
"sub": []
},
{
"t": "Go to <a>The Black Core</a>",
"sub": []
},
{
"t": "Talk to <i>Sin</i>",
"sub": []
},
{
"t": "Go to <a>Doedre's Despair</a>, kill <k>Doedre, Darksoul</k>",
"sub": []
},
{
"t": "Go to <a>Maligaro's Misery</a>, kill <k>Maligaro, The Broken</k>",
"sub": []
},
{
"t": "Go to <a>Shavronne's Sorrow</a>, kill <k>Shavronne, Unbound</k>",
"sub": []
},
{
"t": "Talk to <i>Sin</i> ➜ <a>The Black Heart</a>, kill <k>The Depraved Trinity</k>",
"sub": []
},
{
"t": "<l>Use portal</l>",
"sub": []
}
]
},
{
"tip": "Two quests with passive points: Vilenta and An End to Hunger. Then the epilogue – maps!",
"title": "Act 10",
"steps": [
{
"t": "Use the <w>waypoint</w> to <z>Oriath Docks</z>",
"sub": []
},
{
"t": "Continue to <z>The Cathedral Rooftop</z>",
"sub": []
},
{
"t": "Go to <a>Cathedral Apex</a>, kill <k>Plaguewing</k>",
"sub": [
"Go <d>↑</d> <i>north</i>"
]
},
{
"t": "Continue to <z>The Ravaged Square</z>",
"sub": []
},
{
"t": "Place <l>Place portal</l> in the plaza",
"sub": []
},
{
"t": "Continue to <z>The Control Blocks</z>",
"sub": [
"Go <d>↓</d> <i>south</i>"
]
},
{
"t": "Use the <w>waypoint</w> to <z>Oriath Docks</z>",
"sub": []
},
{
"t": "Hand in the quest <q>Safe Passage</q> in town",
"sub": []
},
{
"t": "Take <l>Use portal</l>",
"sub": []
},
{
"t": "Click the <w>waypoint</w> to unlock it",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Continue to <z>The Ossuary</z>",
"sub": []
},
{
"t": "Complete <t>Trial of Ascendancy</t>",
"sub": [
"Interact with the switch just before the zig-zagging walls, go to the opposite side to access <i>Hidden Gem: Facetor's Lens</i>"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Control Blocks</z>",
"sub": []
},
{
"t": "Find and kill <k>Vilenta</k>",
"sub": []
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Hand in the quest <q>Vilenta's Vengeance</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>Aspirants' Plaza</z>",
"sub": []
},
{
"t": "<t>Complete the Labyrinth (Merciless)</t>",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Ravaged Square</z>",
"sub": []
},
{
"t": "Continue to <z>The Torched Courts</z>",
"sub": [
"Go <d>↘</d> <i>south-east</i>"
]
},
{
"t": "Continue to <z>The Desecrated Chambers</z>",
"sub": [
"Loop around clockwise"
]
},
{
"t": "Go to <a>Sanctum of Innocence</a>, kill <k>Avarius, Reassembled</k>, take <i>The Staff of Purity</i>",
"sub": [
"Go <d>↖</d> <i>north-west</i> counter-clockwise spiral"
]
},
{
"t": "<l>Log out</l> (back to town)",
"sub": []
},
{
"t": "Talk to <i>Bannon</i>",
"sub": []
},
{
"t": "Hand in the quest <q>Death and Rebirth</q> in town",
"sub": []
},
{
"t": "Use the <w>waypoint</w> to <z>The Ravaged Square</z>",
"sub": []
},
{
"t": "Talk to <i>Innocence</i>",
"sub": [
"Go <d>↗</d> <i>north-east</i>"
]
},
{
"t": "Continue to <z>The Canals</z>",
"sub": []
},
{
"t": "Continue to <z>The Feeding Trough</z>",
"sub": []
},
{
"t": "Talk to <i>Sin</i>",
"sub": []
},
{
"t": "Go to <a>Altar of Hunger</a>, kill <k>Kitava, the Insatiable</k>",
"sub": []
},
{
"t": "Talk to <i>Sin</i> ➜ <z>Oriath Docks</z>",
"sub": []
},
{
"t": "Talk to <i>Lilly Roth</i>, Set Sail from Oriath",
"sub": []
},
{
"t": "Continue to <z>Karui Shores</z>",
"sub": []
},
{
"t": "Hand in the quest <q>An End to Hunger</q> in town",
"sub": [
"Type <i>/passives</i> in chat to confirm that you have all 24 passives from quests"
]
}
]
}
];
