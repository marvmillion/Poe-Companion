// PoE 2 Kampagnen-Route (Akt 1–4, Interludes, Übergang in die Maps) – Stand 0.5.5 (Forbidden Rites)
// Route aus poe2overlay von Michael Malura (MIT-Lizenz), https://github.com/maluramichael/poe2overlay – Quelle: https://poe2speedrun.malura.de/
window.CAMPAIGN_POE2 = [
{
"act": 1,
"title": "Akt 1: Ogham (Level 1 → 14)",
"short": "Akt 1",
"tip": "Gems schneiden, sobald du ein Uncut Gem hast – und Resistenz-Buffs der Bosse nicht auslassen.",
"steps": [
{
"t": "Geh nach <z>The Riverbank</z>",
"sub": [],
"z": "The Riverbank",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>The Bloated Miller</k> töten",
"sub": [
"Im Eck gegenüber vom Eingang kämpfen: danach direkt an der Blockade vorbei in die Stadt.",
"Über 35 Leben bleiben, dann überlebst du seinen Slam."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Bloated Miller",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell Encampment</z>",
"sub": [],
"z": "Clearfell Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Renly</i> ansprechen → erstes <i>Uncut Skill Gem</i>",
"sub": [
"Skill schneiden, dann direkt raus nach Clearfell."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell</z>",
"sub": [],
"z": "Clearfell",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Beira of the Rotten Pack</k> töten → <i>+10% Kälte-Resi</i>",
"sub": [
"Beira steht in der Mitte der Zone. <i>Head of the Winter Wolf</i> aufheben und benutzen.",
"<i>Minimal:</i> Nur zum Ausgang nach The Grelwood, Beira ist optional.",
"<i>Mysterious Campsite</i> (Checkpoint): garantiertes Uncut Skill Gem, z.B. für Frost Bomb (Exposure).",
"<i>Mud Burrow</i> skippen: gibt nur Support-Gem + Gold von Renly."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Beira of the Rotten Pack",
"npc": ""
},
{
"t": "Geh nach <z>The Grelwood</z>",
"sub": [],
"z": "The Grelwood",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Waypoint</w> am <i>Tree of Souls</i> holen, dann in <i>The Red Vale</i> <span class=\"lvl\">Lv 3-4</span>",
"sub": [
"Den leuchtenden Wurzeln zum Tree of Souls folgen, zur Red Vale den Fluss hinauf.",
"Die 4 POIs bilden eine <i>Raute</i>: Witch Hut, Grim-Tangle-Eingang, Tree of Souls, Brambleghast. Kennst du zwei, weißt du, wo die anderen liegen.",
"Den Pilzen zum <i>Grim-Tangle</i>-Eingang folgen, kurz rein und dort den Waypoint aktivieren.",
"<i>Witch Hut</i> (optional): der Kessel gibt Medium Life + Mana Flask, auch ohne Kill. <i>Areagne, Forgotten Witch</i> droppt ein Support-Gem: vorher Respawn at Checkpoint, dann stehen keine Monster in der Nähe.",
"<i>Gerung, the Brambleghast</i> skippen: gibt nur ein Level-2-Skill-Gem."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Red Vale</z>",
"sub": [],
"z": "The Red Vale",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "3 <i>Obelisks of Rust</i> aktivieren, <k>Rust King</k> töten <span class=\"lvl\">Lv 5</span>",
"sub": [
"Jeder Obelisk ruft eine Welle, die ein Runen-Questitem droppt. Am dritten spawnt stattdessen der Rust King.",
"Alle <i>Rusted Arms</i> und <i>Refined Arms</i> (Waffenständer) anklicken: zusammen droppen sie mindestens eine Waffe jedes Typs außer Wand und Staff. Die beste Base transmuten.",
"Nach dem Kill Portal in die Stadt."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Rust King",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell Encampment</z>",
"sub": [],
"z": "Clearfell Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Renly</i>: Runen abgeben, <i>Runed Spikes</i> nehmen",
"sub": [
"Danach WP nach The Grelwood.",
"Rares erst identifizieren, dann verkaufen: identifiziert bringen sie mehr Gold.",
"Keine brauchbare Waffe aus der Red Vale: beim Vendor eine magische mit Flat-Damage oder %Phys kaufen (Blitz ideal, wegen Shock), sonst eine weiße Base. Ab jetzt jede gute weiße Base transmuten.",
"Vendor per Such-Regex prüfen: Handschuhe mit Flat-Damage, bessere Waffe, Boots mit Movement Speed."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Grelwood</z>",
"sub": [],
"z": "The Grelwood",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Die <i>3 Runic Seals</i> am Tree of Souls mit den Runed Spikes brechen",
"sub": [
"Una am Baum überspringen: Portal in die Stadt, dort <i>Una</i> ansprechen, dann WP nach The Grim Tangle."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Grim Tangle</z>",
"sub": [],
"z": "The Grim Tangle",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "An den Wurzeln <i>Una</i> rufen, dann weiter zum <i>Cemetery of the Eternals</i> <span class=\"lvl\">Lv 5-6</span>",
"sub": [
"Una ansprechen, Dialog wegklicken, sofort in den Checkpoint rollen: dann kommst du durch die Wurzeln, ohne ihr Lied abzuwarten.",
"<i>Minimal:</i> Nur durchlaufen, Ervig ist optional.",
"<i>Ervig</i> (Rotten Druid): garantiertes Support-Gem. Er teleportiert, Cooldowns erst danach zünden.",
"Fungal Zombies explodieren beim Tod: nicht auf Leichen stehen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Cemetery of the Eternals</z>",
"sub": [],
"z": "Cemetery of the Eternals",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Asinia</k> und <k>Draven</k> töten → 2 Memorial Key Pieces <span class=\"lvl\">Lv 7</span>",
"sub": [
"Asinia im <i>Tomb of the Consort</i>, Draven im <i>Mausoleum of the Praetor</i>. Beide Eingänge an der Wand entlang suchen, Waypoint mitnehmen.",
"<i>Ancient Ruin</i> (Sarkophag am Zonenrand): garantiert Iron Ring oder Lazuli Ring. Den Ring transmuten: etwa 1/3 Chance auf einen Damage-Prefix (Flat-Damage für Attacken).",
"<i>Asinia</i> teleportiert: Burst erst nach dem Teleport zünden.",
"<i>Draven</i> ist schwer zu treffen: Schadensfenster, wenn er in den Boden sticht und die Welle auslöst.",
"Tomb: <i>Haunted Treasure</i> (POI) spawnt einen Rare mit garantiertem Support-Gem. Nah dranbleiben und nicht auf sein Schild schlagen, sonst feuert er Projektile.",
"Mausoleum: die runde <i>Wheel</i>-Kachel ist die Mitte. Draven liegt auf der Seite gegenüber vom Eingang.",
"Mausoleum: <i>Forgotten Riches</i> (POI) = Gold + Rare-Truhe mit Support-Gem."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Asinia",
"npc": ""
},
{
"t": "Am <i>Memorial Gate</i> beim Waypoint <k>Lachlann of Endless Lament</k> töten",
"sub": [
"Tor öffnen, sofort Respawn at Checkpoint: Lachlann spawnt ohne Monolog.",
"<i>Count Lachlann's Ring</i> liegen lassen: spart die Cutscene bei Una. Den Hooded One schaltest du am Aktende ohnehin frei.",
"Lachlann droppt ein <i>Level-3-Skill-Gem</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Lachlann of Endless Lament",
"npc": ""
},
{
"t": "Geh nach <z>Hunting Grounds</z>",
"sub": [],
"z": "Hunting Grounds",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>The Crowbell</k> töten → <i>+2 Passive-Punkte</i> <span class=\"lvl\">Lv 7-8</span>",
"sub": [
"Am Zonenrand entlang: dort liegen Crowbell, der Farmlands- und der Freythorn-Eingang.",
"<i>Minimal:</i> Nur zum Ogham-Farmlands-Eingang, Crowbell ist optional.",
"Ogham Farmlands kurz betreten und den Waypoint aktivieren, dann weiter nach Freythorn.",
"Crowbell auf dem Weg in die zweite Arena weiter treffen, Exposure auf seinen Laufweg legen.",
"Droppt <i>Book of Specialisation</i> (per Rechtsklick lesen) und ein Level-3-Skill-Gem.",
"<i>Dryadic Ritual</i> (Rare) am Weg: garantiertes Support-Gem."
],
"z": "",
"k": "pp",
"q": "The Trail of Corruption",
"e": 0,
"kt": "The Crowbell",
"npc": ""
},
{
"t": "Geh nach <z>Freythorn</z>",
"sub": [],
"z": "Freythorn",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) 3 Ritual-Altäre reinigen, <k>The King in the Mists</k> töten → <i>+30 Spirit</i> <span class=\"lvl\">Lv 8-9</span>",
"sub": [
"Die Rauchfahnen am gereinigten Altar zeigen zum nächsten. Danach oben der große Altar: Welle töten, dann spawnt der King.",
"<i>Gembloom Skull</i> aufheben und benutzen: +30 Spirit + Uncut Spirit Gem Level 4.",
"Er teleportiert oft: Burst erst nach dem Teleport. In Phase 2 fliegt er bei Stun weit zurück.",
"Ritual-Fenster öffnen: Gear-Upgrade nehmen (z.B. Damage-Handschuhe), sonst Currency."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The King in the Mists",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell Encampment</z>",
"sub": [],
"z": "Clearfell Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Finn</i>: Charm wählen, <i>Una</i>: Greater Life/Mana Flask kaufen <span class=\"lvl\">Lv 10</span>",
"sub": [
"Danach WP nach Ogham Farmlands.",
"Finn bietet Ruby, Sapphire oder Topaz Charm.",
"Mit Level 10 den Vendor auf neue Waffenbases prüfen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Ogham Farmlands</z>",
"sub": [],
"z": "Ogham Farmlands",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Una's Lute</i> einsammeln → bei Una <i>+2 Passive-Punkte</i> <span class=\"lvl\">Lv 10</span>",
"sub": [
"Die Straßen führen zu <i>Una's Hut</i> (Checkpoint) mit der Laute, danach einer Straße nach Ogham Village folgen.",
"<i>Minimal:</i> Nur durchlaufen, die Laute ist optional.",
"<i>Crop Circle</i> (Rare im Weizenfeld): garantiertes Uncut Skill Gem Level 4. In die Mitte laufen, dann spawnen die Mobs."
],
"z": "",
"k": "pp",
"q": "The Lost Lute",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Ogham Village</z>",
"sub": [],
"z": "Ogham Village",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>The Executioner</k> töten, Hebel ziehen, <i>Leitis</i> ansprechen <span class=\"lvl\">Lv 11</span>",
"sub": [
"Sein Loot braucht ein paar Sekunden: in der Zeit den Hebel am Podest ziehen, dann Loot einsammeln.",
"<i>Minimal:</i> Executioner, Hebel und Leitis sind Pflicht, Workshop und Truhe optional.",
"Der Straße zu <i>Renly's Workshop</i> folgen: die <i>Smithing Tools</i> schalten bei Renly die Salvage Bench frei.",
"<i>Blacksmith's Chest</i> neben den Tools: Blank Rune + Artificer's Orb, für die Level-16-Waffe aufheben."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Executioner",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell Encampment</z>",
"sub": [],
"z": "Clearfell Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Una</i>: Laute abgeben → <i>+2 Passive-Punkte</i>",
"sub": [
"Portal oder WP aus der Village. Geht auch erst am Aktende, zusammen mit dem Hooded One.",
"<i>Leitis</i>: Uncut Skill Gem Level 5 abholen.",
"<i>Renly</i>: Smithing Tools abgeben, Blank Rune gegen eine Lesser Rune tauschen (Desert, Glacial, Storm oder Iron).",
"Una's Book of Specialisation per Rechtsklick lesen.",
"Greater Life Flask kaufen, falls du noch keine hast: Ramparts und Manor treffen hart."
],
"z": "",
"k": "pp",
"q": "The Lost Lute",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Manor Ramparts</z>",
"sub": [],
"z": "The Manor Ramparts",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Zur <i>Ogham Manor</i>, dabei auf <i>Level 13</i> kommen <span class=\"lvl\">Lv 12</span>",
"sub": [
"Am inneren Rand entlang, unterwegs alles killen: gute XP-Zone.",
"<i>The Gallows</i> (Außenrand, Checkpoint): Leiche anklicken und sofort weglaufen, dann droppt das Support-Gem neben dir statt oben auf dem Galgen.",
"Neben der Gallows steht ein garantiertes magisches Pack: mitnehmen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Ogham Manor</z>",
"sub": [],
"z": "Ogham Manor",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Count Geonor</k> mit <i>Level 14</i> töten <span class=\"lvl\">Lv 14</span>",
"sub": [
"Etage 1: <i>Candlemass, the Living Rite</i> für <i>+20 Leben</i> (meist obere Ecke, vor oder hinter der Brücke). Geonor: am Ende von Etage 3 mit dem Aufzug runter.",
"<i>Minimal:</i> Nur Geonor ist Pflicht, Candlemass optional.",
"Jede Etage ist Bereich, Brücke, Bereich. Auf der nächsten Etage in die Gegenrichtung laufen.",
"Level 14 macht Gem-Level 5 nutzbar (Leitis-Gem). Darunter in der Manor weiter Packs killen.",
"Unter 50% verschwindet Geonor im Nebel: Adds für Flask-Ladungen killen, am Ende jeder Sprachzeile springt er dich an, dann ausweichen. Kälte-Strahlen mit Schild blocken.",
"<i>Speed-Reihenfolge:</i> Geonor zuerst töten, während sein Dialog läuft mit dem Aufzug hoch, per Checkpoint zu Candlemass, dann zurück zu Geonors Loot."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Count Geonor",
"npc": ""
},
{
"t": "Geh nach <z>Clearfell Encampment</z>",
"sub": [],
"z": "Clearfell Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> ansprechen → <i>Follow the Beast's trail</i>",
"sub": [
"Reise zu den Vastiri Outskirts. Vorher Inventar verkaufen und Vendor prüfen.",
"Offenes nachholen: Laute bei Una, Level-5-Gem bei Leitis, Smithing Tools und Blank Rune bei Renly."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 2,
"title": "Akt 2: Vastiri (Level 14 → 28/29)",
"short": "Akt 2",
"tip": "",
"steps": [
{
"t": "Geh nach <z>Vastiri Outskirts</z>",
"sub": [],
"z": "Vastiri Outskirts",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Rathbreaker</k> töten <span class=\"lvl\">Lv 14</span>",
"sub": [
"Den Speerlinien am Boden folgen: sie zeigen zum Knochen-Durchgang Richtung Rathbreaker.",
"Hinter ihm bleiben: dann trifft dich sein Slam nicht.",
"Mit Leap/Pounce: an der Klippe einen Mob neben Rathbreaker anvisieren und direkt hochspringen.",
"Optional: <i>Raider Camp</i> (Checkpoint) = Tier-2-Support-Gem.",
"Danach Portal, bei <i>Zarka</i> das Uncut Skill Gem nehmen, dann <i>The Ardura Caravan</i> betreten."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Rathbreaker",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i>, dann <i>Asala</i> sprechen → Wüstenkarte <i>Mawdun Quarry</i>",
"sub": [
"Im ganzen Akt zuerst das Ziel auf der Wüstenkarte wählen, dann während der Fahrt verkaufen und Stash erledigen.",
"Vendor checken: <i>Level-16-Waffe</i>, Damage-Handschuhe, Boots mit <i>15% Movement Speed</i>."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Mawdun Quarry</z>",
"sub": [],
"z": "Mawdun Quarry",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Eingang <i>Mawdun Mine</i> finden <span class=\"lvl\">Lv 16</span>",
"sub": [
"<i>Whetstones und Armour Scraps</i> alle aufheben: die Zone ist voll davon.",
"Optional: <i>War Cache</i> am Zonenrand (Checkpoint) = garantierter Artificer's Orb. Nicht dafür zurücklaufen.",
"Mit Level 16 die Waffe craften (Loot-Sektion: Waffen-Crafting)."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Mawdun Mine</z>",
"sub": [],
"z": "Mawdun Mine",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Rudja, the Dread Engineer</k> töten, <i>Risu</i> befreien <span class=\"lvl\">Lv 16-17</span>",
"sub": [
"Beim Betreten sofort Respawn at Checkpoint (skippt den Aufzug), dann nach Norden bzw. Nordosten den Schienen folgen.",
"Rudja macht harten Feuerschaden auf Distanz und im Nahkampf: dicht dran und hinter ihr bleiben.",
"Mit <i>Risu</i> sprechen, dann Portal zur Karawane."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Rudja, the Dread Engineer",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Risu</i>, dann <i>Asala</i> sprechen → Wüstenkarte <i>Traitor's Passage</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Traitor's Passage</z>",
"sub": [],
"z": "Traitor's Passage",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durchlaufen bis <i>The Halani Gates</i> <span class=\"lvl\">Lv 17-18</span>",
"sub": [
"An der Kreuzung mit Obelisk und Checkpoint: Wände ohne Pergament führen zum Ausgang, Wände mit Pergament zu Balbala.",
"<i>Minimal:</i> Nur durchlaufen, Balbala ist optional.",
"Frühe Ascendancy: den Pergamenten folgen, <i>Balbala, the Traitor</i> töten → Barya (Level 22). Sie ist schnell und schwer zu treffen.",
"Sonst Balbala skippen: eine Level-28-Barya gibt es in Deshar.",
"Optional: Truhe mit Glocken (Checkpoint) = Uncut Skill Gem Level 6."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Halani Gates</z>",
"sub": [],
"z": "The Halani Gates",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Jamanra, the Risen King</k> töten <span class=\"lvl\">Lv 18</span>",
"sub": [
"Asala öffnet die drei Tore: an jeder Brücke auf sie warten, nicht vorrennen.",
"Hängt Asala fest: zum Checkpoint vor der 2. Brücke, Respawn at Checkpoint: sie steht dann wieder bei dir.",
"Mit mindestens <i>Level 18</i> zu Jamanra.",
"Danach die Treppe hinter der Arena runter bis zum Sandsturm (Quest-Update), dann Portal zur Karawane."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Jamanra, the Risen King",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Bei <i>Zarka</i> das Uncut Skill Gem (Level 7) holen, <i>Asala</i> sprechen → Wüstenkarte <i>Mastodon Badlands</i>",
"sub": [
"Asala schickt dich in drei Regionen für das Horn: Mastodon Badlands, Keth, Valley of the Titans.",
"Reihenfolge <i>Badlands -> Keth -> Valley</i>: Badlands vor Keth, dann droppt Kabala ein Level-7-Gem statt Level 6."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Trial of the Sekhemas</z>",
"sub": [],
"z": "Trial of the Sekhemas",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Trial of the Sekhemas</i> mit Balbalas Barya (Level 22) <span class=\"lvl\">Lv 19-22</span>",
"sub": [
"Nur für starke Builds (Level ~19-22), sonst später mit der Level-28-Barya aus Deshar.",
"Anreise: <i>Zarka</i> sprechen, dann Wüstenkarte → <i>Trial of the Sekhemas</i>.",
"Ritual- und Chalice-Räume sind kurz, Hourglass und Gauntlet dauern länger."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Mastodon Badlands</z>",
"sub": [],
"z": "Mastodon Badlands",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Eingang <i>The Bone Pits</i> finden <span class=\"lvl\">Lv 20</span>",
"sub": [
"Den Rissen im Boden folgen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Bone Pits</z>",
"sub": [],
"z": "The Bone Pits",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Iktab, the Deathlord & Ekbab, Ancient Steed</k> töten → <i>Mastodon Tusks</i> <span class=\"lvl\">Lv 20-21</span>",
"sub": [
"Hinter Iktab (Nekromant) stellen, damit Ekbab auf ihn läuft: beide gleichzeitig treffen, Iktab zuerst töten.",
"Die Bosse liegen in Blickrichtung des Zoneneingangs.",
"<i>Minimal:</i> Nur die Bosse sind Pflicht, das <i>Sun Clan Relic</i> (für den Charm-Slot) ist optional.",
"Das Sun Clan Relic droppt nur von <i>Hyänen</i> (große häufiger): jede Hyäne töten.",
"Fehlt das Relikt: weitersuchen, nicht per Checkpoint resetten, sonst spawnen alle Monster neu.",
"Danach Portal, bei <i>Zarka</i> die Tusks abgeben (Support Gem), Wüstenkarte → <i>Keth</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Iktab, the Deathlord & Ekbab, Ancient Steed",
"npc": ""
},
{
"t": "Geh nach <z>Keth</z>",
"sub": [],
"z": "Keth",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Kabala, Constrictor Queen</k> töten → <i>+2 Passive-Punkte (+2 Waffenset-Punkte)</i> <span class=\"lvl\">Lv 21-22</span>",
"sub": [
"Den Schlangen folgen und sie töten: sie führen zu Kabalas Arena (Checkpoint).",
"<i>Minimal:</i> Nur zum Ausgang <i>The Lost City</i> am anderen Ende der Zone, Kabala ist optional.",
"Schlangen droppen das <i>Kabala Clan Relic</i> (auch in The Lost City): für den Charm-Slot im Valley of the Titans.",
"Optional: <i>Abandoned Prayer</i> (Secret) = garantiertes magisches Amulett."
],
"z": "",
"k": "pp",
"q": "The City of Seven Waters",
"e": 0,
"kt": "Kabala, Constrictor Queen",
"npc": ""
},
{
"t": "Geh nach <z>The Lost City</z>",
"sub": [],
"z": "The Lost City",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Eingang <i>Buried Shrines</i> finden <span class=\"lvl\">Lv 22</span>",
"sub": [
"Der erste Korridor zeigt die Grundrichtung. Der Eingang liegt am Zonenrand beim Checkpoint an der V-förmigen Brücke.",
"Kabala Clan Relic noch nicht da: weiter Schlangen töten."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Buried Shrines</z>",
"sub": [],
"z": "Buried Shrines",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Azarian, the Forsaken Son</k> töten → <i>Essence of Water</i> <span class=\"lvl\">Lv 22-23</span>",
"sub": [
"Loot liegen lassen, sofort zur <i>Water Goddess</i>: ansprechen, mit den Everburning Cinders erlösen, während der Animation Loot holen, dann die Essence aufheben.",
"<i>2x2 Platz</i> im Inventar für die Essence freihalten.",
"Auf den Brücken stehen garantierte magische Packs: mitnehmen.",
"Optional: <i>Elemental Offering</i> (Checkpoint) = Resi-Ring + passende Rune: niedrigste Resi wählen, im Zweifel Blitz.",
"Danach Portal, bei <i>Zarka</i> die Essence abgeben (Support Gem), Wüstenkarte → <i>Valley of the Titans</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Azarian, the Forsaken Son",
"npc": ""
},
{
"t": "Geh nach <z>Valley of the Titans</z>",
"sub": [],
"z": "Valley of the Titans",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>3 Ancient Seals</i> aktivieren: je eine am Ende jedes Canyons <span class=\"lvl\">Lv 23</span>",
"sub": [
"Der Checkpoint am Eingang Titan Grotto liegt nah am Start: mitnehmen, nach den Seals per Checkpoint zurück.",
"<i>Minimal:</i> Nur die 3 Seals sind Pflicht, der Relikt-Altar ist optional.",
"<i>Relikt-Altar</i> (im Canyon mit dem Waypoint): Kabala Clan + Sun Clan Relic einsetzen → <i>+1 Charm-Slot</i> + Wahl: 30% mehr Charm-Charges oder 30% längere Charm-Dauer (später änderbar).",
"Hat dein Gürtel schon genug Charm-Slots, kannst du die Relikte skippen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Titan Grotto</z>",
"sub": [],
"z": "The Titan Grotto",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Zalmarath, the Colossus</k> töten → <i>Flame Ruby</i> <span class=\"lvl\">Lv 24</span>",
"sub": [
"Direkt an seine Brust unter den Arm stellen: dort treffen seine Angriffe kaum.",
"Optional: <i>Titan's Sword</i> (POI) = garantierte Lesser Rune. Nur mitnehmen, wenn es am Weg liegt.",
"Danach Portal, bei <i>Zarka</i> den Flame Ruby abgeben: sie gibt dir das <i>Horn of the Vastiri</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Zalmarath, the Colossus",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per Wüstenkarte zum Sandsturm (<i>Traitor's Passage</i>), dann vorne an der Karawane <i>Sound the Horn</i>",
"sub": [
"Das Horn gibt Zarka erst, wenn Mastodon Tusks, Essence of Water und Flame Ruby abgegeben sind.",
"Danach <i>Asala</i> sprechen → Wüstenkarte <i>Deshar</i>.",
"Während der Fahrt <i>Flasks</i> auf Level-23-Bases upgraden."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Deshar</z>",
"sub": [],
"z": "Deshar",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Final Letter</i> bei <i>Fallen Dekhara</i> holen (für Shambrin: +2 Passive-Punkte (+2 Waffenset-Punkte)) <span class=\"lvl\">Lv 24</span>",
"sub": [
"Fallen Dekhara liegt zufällig am Fuß eines der Grabtürme: auf dem Weg zum Ausgang jeden Turmfuß prüfen, sonst danach zurücksuchen.",
"<i>Minimal:</i> Nur zum Ausgang <i>Path of Mourning</i>, Brief und Barya sind optional.",
"Späte Ascendancy: bei den Leichen (Checkpoint) die zwei Geier (<i>Watchful Twins</i>) töten → garantierte Barya (Level 28).",
"Optional: garantierter <i>Artificer's Orb</i> gleich am Anfang am linken oder rechten Rand.",
"Mit mindestens <i>Level 24</i> rein: bis Level 27 gibt die Zone volle XP."
],
"z": "",
"k": "pp",
"q": "Tradition's Toll",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Path of Mourning</z>",
"sub": [],
"z": "Path of Mourning",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durchlaufen bis <i>The Spires of Deshar</i> <span class=\"lvl\">Lv 25</span>",
"sub": [
"Die Weltkarte (U) zeigt die Richtung zum Ausgang.",
"Brauchst du die Punkte schon für Tor Gul: per Waypoint zur Karawane, Final Letter bei <i>Shambrin</i> abgeben."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Spires of Deshar</z>",
"sub": [],
"z": "The Spires of Deshar",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Tor Gul, the Defiler</k> töten <span class=\"lvl\">Lv 26</span>",
"sub": [
"Du startest mit Blick nach Norden: Tor Gul steht am Nordende der Zone.",
"<i>Minimal:</i> Tor Gul ist Pflicht, die Sisters of Garukhan sind optional.",
"<i>Sisters of Garukhan</i> (Statue am Checkpoint) anklicken → <i>+10% Blitz-Resi</i>. Die Wege um die Statue bilden auf der Karte ein <i>G</i>.",
"Tor Gul macht Physisch-, Feuer- und Giftschaden: <i>Feuer-Resi</i> hoch, sein Feueratem ist der gefährlichste Angriff. Mindestens <i>Level 26</i>.",
"Danach Portal zur Karawane."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Tor Gul, the Defiler",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Wüstenkarte <i>The Dreadnought</i> wählen, während der Fahrt <i>Final Letter</i> bei <i>Shambrin</i> abgeben → <i>+2 Passive-Punkte (+2 Waffenset-Punkte)</i>",
"sub": [
"Erst Ziel wählen, dann shoppen: so entfällt das Heranfahren an die Dreadnought (~10 s).",
"Späte Ascendancy vorher: <i>Zarka</i> sprechen, Wüstenkarte → <i>Trial of the Sekhemas</i> (nächste Karte), danach erst The Dreadnought."
],
"z": "",
"k": "pp",
"q": "Tradition's Toll",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Trial of the Sekhemas</z>",
"sub": [],
"z": "Trial of the Sekhemas",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Trial of the Sekhemas</i> mit der Level-28-Barya aus Deshar <span class=\"lvl\">Lv ~28</span>",
"sub": [
"Balbala gibt dir im Trial eine Level-22-Barya: am Altar manuell die Level-28-Barya einsetzen.",
"Ritual- und Chalice-Räume sind kurz, Hourglass und Gauntlet dauern länger."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Dreadnought</z>",
"sub": [],
"z": "The Dreadnought",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Jamanra, the Abomination</k> töten (Aktboss) <span class=\"lvl\">Lv 28-29</span>",
"sub": [
"Schnell ~55k Schaden reinhauen: dann kommt er nicht zu seinem Sturm-Angriff. Phase 2: nah dran bleiben, Slam und Slash wegrollen.",
"Mindestens <i>Level 28</i>, besser 29: sonst Zone resetten und farmen.",
"Seit 0.5 gibt es keine Dreadnought Vanguard mehr: Jamanra steht am Ende von The Dreadnought.",
"Danach <i>Asala</i> sprechen, Portal zur Karawane."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Jamanra, the Abomination",
"npc": ""
},
{
"t": "Geh nach <z>The Ardura Caravan</z>",
"sub": [],
"z": "The Ardura Caravan",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> im Schrein nordwestlich der Karawanen-Mitte sprechen (Rampe runter)",
"sub": [
"Warten, bis die Quest 'Talk to Asala...' anzeigt, dann Esc → Charakterauswahl und wieder rein: du stehst am Waypoint.",
"Dann <i>Asala</i> sprechen → <i>Sandswept Marsh</i> (Akt 3)."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 3,
"title": "Akt 3: Dschungel & Vaal (Level 29 → 41)",
"short": "Akt 3",
"tip": "",
"steps": [
{
"t": "Geh nach <z>Sandswept Marsh</z>",
"sub": [],
"z": "Sandswept Marsh",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Zum <i>Ziggurat Encampment</i> durchlaufen <span class=\"lvl\">Lv 29</span>",
"sub": [
"Übergang am Rand der Anfangszone nehmen, dann quer durch den Sumpf.",
"<i>Minimal:</i> Nur durchqueren, alles andere optional.",
"<i>Orok Campfire</i> nahe Ausgang: Korb mit <i>Lesser Jeweller's Orb</i>.",
"<i>Rootdredge</i> töten, wenn er am Weg liegt: droppt Uncut Skill Gem Level 9.",
"Mit mindestens Level 29 in die Stadt, sonst hier nachfarmen: die frühen Akt-3-Zonen geben wenig XP."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Ziggurat Encampment</z>",
"sub": [],
"z": "Ziggurat Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Oswald</i> ansprechen, Vendors checken <span class=\"lvl\">Lv 29</span>",
"sub": [
"Ausgang zu den Jungle Ruins oben in der Stadt.",
"Oswald zuerst ansprechen, sonst ist sein Shop nicht offen.",
"Ab Level 30: <i>Colossal Life Flask</i> bei Servi. Noch Level 29: beim nächsten Stadtbesuch kaufen.",
"Oswald: Waffen, Rüstung, Gürtel. Servi: Sceptres, Wands, Staves, Flasks, Ringe, Amulette, Charms."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Jungle Ruins</z>",
"sub": [],
"z": "Jungle Ruins",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Mighty Silverfist</k> töten → <i>+2 Passive-Punkte</i> (+2 Waffenset-Punkte) <span class=\"lvl\">Lv 29-30</span>",
"sub": [
"Am Wasser entlang zum WP. Silverfist steht in der Mitte der Zone.",
"<i>Minimal:</i> Zone ist Pflicht, Silverfist optional.",
"Swing und Slam wegrollen. Sein Roll-Angriff ist mit wenig Armour tödlich.",
"<i>Troubled Camp</i>: Truhe neben dem Händler = garantierte rare Handschuhe.",
"Die Schlangen-Spur führt zum Eingang der <i>Venom Crypts</i> (Checkpoint davor)."
],
"z": "",
"k": "pp",
"q": "Legacy of the Vaal",
"e": 0,
"kt": "Mighty Silverfist",
"npc": ""
},
{
"t": "Geh nach <z>Venom Crypts</z>",
"sub": [],
"z": "Venom Crypts",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Corpse-snake Venom</i> von der Leiche holen <span class=\"lvl\">Lv 30</span>",
"sub": [
"Den humanoiden Gegnern zur Leiche folgen, dann den Ausgang dort zurück in die Jungle Ruins nehmen.",
"Venom bei <i>Servi</i> in der Stadt abgeben: <i>Artificer's Orb</i> + permanente Wahl, Empfehlung <i>25% Stun Threshold</i>.",
"Alternativen: 30% Elemental Ailment Threshold oder 25% Mana Regeneration Rate. Die Wahl ist endgültig.",
"Dieser Ausgang kommt nahe dem Eingang zu den <i>Infested Barrens</i> raus."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Infested Barrens</z>",
"sub": [],
"z": "Infested Barrens",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Zu den <i>Chimeral Wetlands</i> durchlaufen <span class=\"lvl\">Lv 31</span>",
"sub": [
"WP mitnehmen. Der NPC im Troubled Camp deckt den Ausgang auf der Karte auf.",
"<i>Level 31 = Gems auf Level 9.</i>",
"<i>Troubled Camp</i>: Truhe neben dem Händler = garantierte rare Boots."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Chimeral Wetlands</z>",
"sub": [],
"z": "Chimeral Wetlands",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Xyclucian</k> töten, weiter in <i>Jiquani's Machinarium</i> <span class=\"lvl\">Lv 32</span>",
"sub": [
"Beides am Zonenrand: Temple-of-Chaos-WP und Xyclucian vor dem Machinarium-Eingang.",
"Bei 75/50/25% fliegt er auf eine Säule: Steinplattform darunter zerstören, dann ist er kurz betäubt.",
"<i>Chimeral Inscribed Ultimatum</i> aufheben: Schlüssel für die Trial of Chaos.",
"Venom dabei? WP aktivieren, Portal in die Stadt, bei <i>Servi</i> abgeben, durchs Portal zurück."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Xyclucian",
"npc": ""
},
{
"t": "Geh nach <z>Jiquani's Machinarium</z>",
"sub": [],
"z": "Jiquani's Machinarium",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Blackjaw</k> töten → <i>Flame Core</i>: <i>+10% Feuer-Resi</i> <span class=\"lvl\">Lv 33</span>",
"sub": [
"Je 1 Small Soul Core: Stone Altar am Start, verschlossener Ausgang (roter Linie folgen), Blackjaws Raum am Seitenrand.",
"<i>Minimal:</i> 2 Small Soul Cores (Altar + Ausgang), Blackjaw optional.",
"Dem Hauptkorridor folgen, nur für Cores (Quest-Item-Sound) oder Blackjaw abbiegen.",
"Blockaden im Korridor mit Leap Slam, Pounce oder Thunderous Leap überspringen."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Blackjaw",
"npc": ""
},
{
"t": "Geh nach <z>Jiquani's Sanctum</z>",
"sub": [],
"z": "Jiquani's Sanctum",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Zicoatl</k> töten → <i>Large Soul Core</i> <span class=\"lvl\">Lv 33</span>",
"sub": [
"2 Medium Soul Cores in die 2 Generatoren (V-Form). Dann Respawn at Checkpoint, zum Start, Core anklicken: Zicoatl kommt sofort.",
"Suchmuster: eine Seite bis zum Checkpoint, per Checkpoint zurück zum Start, dann die andere Seite.",
"Cores liegen meist Richtung Zonenmitte.",
"Dreiecks-Slam: an einer Ecke des Dreiecks stehen.",
"Danach WP zu den <i>Jungle Ruins</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Zicoatl",
"npc": ""
},
{
"t": "Geh nach <z>Jungle Ruins</z>",
"sub": [],
"z": "Jungle Ruins",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Large Soul Core</i> in den <i>Stone Altar</i> → öffnet die <i>Matlan Waterways</i>",
"sub": [
"Altar und Waterways-Eingang liegen beim WP.",
"Der Waterways-Eingang liegt seit 0.5 in den Jungle Ruins."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Matlan Waterways</z>",
"sub": [],
"z": "Matlan Waterways",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Druckplatten ablaufen, am Ende den <i>Mechanismus</i> aktivieren <span class=\"lvl\">Lv 34</span>",
"sub": [
"WP unterwegs mitnehmen. Danach per Checkpoint zum WP: dort ist der Eingang zum <i>Azak Bog</i>.",
"<i>Ravaged Corpse</i> nahe dem Azak-Bog-Eingang anklicken, Servi beschwören und ansprechen: rarer Gürtel.",
"<i>Narag's Hut</i>: Rare droppt eine rare Waffe.",
"Ohne Azak Bog: nach dem Mechanismus Portal in die Stadt.",
"Druckplatten statt Hebeln, der letzte Abschnitt ist schon trocken."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Azak Bog</z>",
"sub": [],
"z": "Azak Bog",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Ignagduk</k> töten → <i>Gemrot Skull: +30 Spirit</i> + Uncut Spirit Gem Level 10 <span class=\"lvl\">Lv 35</span>",
"sub": [
"Erst <i>Flameskin Ritual</i>: 5 Effigies anzünden, dann die mittlere: +25% Feuer-Resi für die Zone. Danach zeigen die Flammen zu Ignagduk.",
"Beim Betreten Servi beschwören und ansprechen: startet die Quest.",
"<i>Ghastly Spear</i> aufheben, bei Servi gegen einen Charm tauschen (Thawing oder Staunching empfohlen).",
"Level-Rückstand? Mobs rund ums Ritual killen, Respawn at Checkpoint, wiederholen: viele magische und rare Packs.",
"Danach Portal in die Stadt."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Ignagduk",
"npc": ""
},
{
"t": "Geh nach <z>Ziggurat Encampment</z>",
"sub": [],
"z": "Ziggurat Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Alva</i> unten am Ziggurat ansprechen → <i>Drowned City</i>",
"sub": [
"Vorher Servi: Ghastly Spear gegen Charm, Venom abgeben falls noch nicht erledigt.",
"Colossal Life Flask kaufen, falls noch nicht erledigt."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Trial of Chaos</z>",
"sub": [],
"z": "Trial of Chaos",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Trial of Chaos</i> mit dem Chimeral Inscribed Ultimatum: Aufstieg",
"sub": [
"WP <i>Temple of Chaos</i>. Build-abhängig, geht auch nach der Kampagne.",
"Das Ultimatum hat 4 Trials. Die Chaos Statue in Utzaal gibt ein weiteres Inscribed Ultimatum.",
"Jederzeit verlassbar, Fortsetzen im selben Raum. Belohnungskiste nach jedem Raum."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Drowned City</z>",
"sub": [],
"z": "Drowned City",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Zum <i>Apex of Filth</i> durchlaufen <span class=\"lvl\">Lv 36</span>",
"sub": [
"WP am Anfang mitnehmen, den brauchst du für den Rückweg.",
"<i>Level 36 = Gems auf Level 10.</i>",
"Türkise Wasser-Kugel meiden: wer zu lange drin steht, ertrinkt.",
"Molten Vault geplant? Unterwegs kurz rein, WP holen, wieder raus."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Apex of Filth</z>",
"sub": [],
"z": "Apex of Filth",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Queen of Filth</k> töten → <i>Temple Door Idol</i> <span class=\"lvl\">Lv 36-37</span>",
"sub": [
"Sie steht in der Zonenmitte. Pilze und Cauldron Keeper ignorieren. Roll-Slam: beim Aufkommen wegrollen.",
"Rückweg: Checkpoint zum WP, WP <i>Drowned City</i>, Ausgang in die Stadt: du landest direkt an der Tür zum <i>Temple of Kopec</i>.",
"In der Stadt <i>Alva</i> ansprechen: öffnet den Temple of Kopec."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Queen of Filth",
"npc": ""
},
{
"t": "Geh nach <z>Molten Vault</z>",
"sub": [],
"z": "Molten Vault",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Mektul</i> töten → Hammer of Kamasa zu <i>Oswald</i>: <i>Reforging Bench</i> <span class=\"lvl\">Lv 37</span>",
"sub": [
"WP Molten Vault. Dem flüssigen Gold folgen, am Ende Sluice Gate Lever, Lift runter. Unter 4 Minuten, dann flutet das Gold die Arena.",
"Nur beim ersten Char der Liga, bei weiteren Chars skippen.",
"Oswald gibt dazu Uncut Skill Gem Level 10, Artificer's Orb und 1.000 Gold."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Temple of Kopec</z>",
"sub": [],
"z": "Temple of Kopec",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Ganz nach oben laufen, <k>Ketzuli</k> töten <span class=\"lvl\">Lv 37</span>",
"sub": [
"Jede Etage ist ein Dreieck: zuerst die ferne Ecke checken (~50% der Fälle). Etage 2: dem Bodenriss von der Sonne zur Wand folgen, rüberspringen.",
"Danach Alva beschwören und ansprechen. Sobald sie 'wait' oder 'offering' sagt: Portal in die Stadt, spart den Rest der Szene.",
"Im Sonnenlicht stackt ein Brand-Debuff: im Schatten laufen."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Ketzuli",
"npc": ""
},
{
"t": "Geh nach <z>Ziggurat Encampment</z>",
"sub": [],
"z": "Ziggurat Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durch das <i>Gateway</i>, die Treppe runter nach <i>Utzaal</i>",
"sub": [
"Das Gateway erscheint erst nach Alvas Szene: Wartezeit für Vendors nutzen.",
"Kälte-Resi oder Sapphire Charm mitnehmen: die Eye-of-Winter-Caster in Utzaal sind gefährlich."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Utzaal</z>",
"sub": [],
"z": "Utzaal",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Viper Napuatzi</k> töten <span class=\"lvl\">Lv 38</span>",
"sub": [
"Dem Kriegsschrei-Sound zu ihr folgen. Speer-Phase: jeden Stich wegrollen.",
"Jeden <i>Vaal Goliath</i> killen: nur sie droppen das <i>Sacrificial Heart</i>.",
"Nach dem Kampf die restlichen Schildwachen töten, dann weiter nach <i>Aggorat</i>.",
"Verkleinern die Soldaten die Arena, füllen sich Flask-Charges auf."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Viper Napuatzi",
"npc": ""
},
{
"t": "Geh nach <z>Aggorat</z>",
"sub": [],
"z": "Aggorat",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Sacrificial Heart</i> am Blutopfer-Altar opfern → <i>+2 Passive-Punkte</i> (+2 Waffenset-Punkte) <span class=\"lvl\">Lv 39</span>",
"sub": [
"Altar am Rand in der zweiten Zonenhälfte: Heart einsetzen, Sacrificial Dagger nehmen, zustechen.",
"<i>Minimal:</i> Nur durchqueren, das Heart ist optional.",
"Noch kein Heart? Goliaths in der zweiten Zonenhälfte killen, bis es droppt.",
"Nach den Punkten Respawn at Checkpoint, dann zum Eingang der <i>Black Chambers</i> am Zonenrand."
],
"z": "",
"k": "pp",
"q": "Legacy of the Vaal",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Black Chambers</z>",
"sub": [],
"z": "Black Chambers",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Doryani</k> töten <span class=\"lvl\">Lv 40</span>",
"sub": [
"Zone = Labyrinthe, durch Brücken verbunden. Doryani vor dem Laser-Altar unter 50% bringen: spart 15-20 s.",
"Mech-Phase unter 50%: die Riesenfaust verfolgt dich und slammt, rechtzeitig rauslaufen.",
"Danach Portal in die Stadt."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Doryani",
"npc": ""
},
{
"t": "Geh nach <z>Ziggurat Encampment</z>",
"sub": [],
"z": "Ziggurat Encampment",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Doryani</i> ansprechen, dann mit <i>Alva</i> nach <i>Kingsmarch</i>",
"sub": [
"Doryani löst den Kataklysmus aus. Nach dem Aufwachen: Doryani, Hooded One, zuletzt Alva."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 4,
"title": "Akt 4: Die Inseln (Level 41 → 50)",
"short": "Akt 4",
"tip": "",
"steps": [
{
"t": "Geh nach <z>Kingsmarch</z>",
"sub": [],
"z": "Kingsmarch",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Doryani</i> und <i>Alva</i> ansprechen, dann <i>Makoru</i> am Schiff → Isle of Kin <span class=\"lvl\">Lv 41</span>",
"sub": [
"Ctrl+Klick auf Makoru öffnet direkt die Seekarte.",
"<i>3 Waffenteile</i> nötig. Der Inselboss, der Matiki gefangen hält, zählt nicht: Matiki sitzt jede Liga bei einem anderen der 4 Bosse.",
"<i>Diesen Patch hält Diamora Matiki:</i> Pflicht sind <i>Krutog, Prisoner, Scourge of the Skies</i>. Whakapanu/Singing Caverns nur für die Buffs.",
"Torn Map Pieces (Plunder's Point) ignorieren."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Isle of Kin</z>",
"sub": [],
"z": "Isle of Kin",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durch zu den <i>Volcanic Warrens</i>",
"sub": [
"Optional: <i>Beast Pen</i> (Checkpoint) → Uncut Support Gem Stufe 4.",
"Optional: <i>Blind Beast</i> → Blank Greater Rune, bei <i>Dannig</i> in Kingsmarch gegen eine Greater Rune nach Wahl tauschen. Nur, wenn du noch einen freien Rune-Sockel hast.",
"Optional: <i>Fossilised Formation</i> an den Außenwänden = Lesser Jeweller's Orb."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Volcanic Warrens</z>",
"sub": [],
"z": "Volcanic Warrens",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Krutog</k> töten → Waffenteil 1/3",
"sub": [
"Dem Lavafluss flussaufwärts folgen. Beim Slam zwischen seinen Beinen durchrollen.",
"Warten, bis der <i>Hooded One</i> das Waffenteil aufgehoben hat, erst dann raus: sonst musst du zurück.",
"<i>Nest</i> (Checkpoint): Magma-Golems töten, der zuletzt getötete bestimmt den Ring: Feuer → Ruby, Blitz → Topaz. Starker Ring für diese Phase.",
"<i>Minimal:</i> Nest auslassen."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Krutog",
"npc": ""
},
{
"t": "Geh nach <z>Kedge Bay</z>",
"sub": [],
"z": "Kedge Bay",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) Durch nach <i>Journey's End</i>",
"sub": [
"Nur für die +2 Passive-Punkte aus Journey's End."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Journey's End</z>",
"sub": [],
"z": "Journey's End",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Omniphobia</k> töten → <i>+2 Passive-Punkte</i> (+2 Waffenset-Punkte)",
"sub": [
"Waypoint nehmen, Tujen beschwören und ansprechen, <i>Captain Hartlin</i> töten, Verisium Ingots aufheben.",
"Portal nach Kingsmarch: <i>Dannig</i> macht daraus die Verisium Spikes.",
"Zurück: Spikes an den Totems benutzen (Freya Hartlin befreien), Omniphobia töten.",
"In Kingsmarch <i>Tujen</i> ansprechen: Mist-shrouded Tome (Rechtsklick) + Uncut Skill Gem.",
"Omniphobia ist kälteresistent und tanky. Ist dein Build zu schwach: nach Hartlin weiter und vor Arastas per Waypoint zurückkommen."
],
"z": "",
"k": "pp",
"q": "Dark Mists",
"e": 0,
"kt": "Omniphobia",
"npc": ""
},
{
"t": "Geh nach <z>Abandoned Prison</z>",
"sub": [],
"z": "Abandoned Prison",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durch nach <i>Solitary Confinement</i> <span class=\"lvl\">Lv 43</span>",
"sub": [
"<i>Kapellen-Schlüssel</i> droppt von Spined Necromancers. In der Kapelle die <i>Goddess of Justice</i> anklicken → 30% Life-Flask-Recovery (oder Mana).",
"<i>Armoury</i> (Checkpoint) plündern: Chance auf große Waffen-Upgrades.",
"<i>Minimal:</i> Kapelle und Armoury auslassen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Solitary Confinement</z>",
"sub": [],
"z": "Solitary Confinement",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>The Prisoner</k> töten → Waffenteil 2/3",
"sub": [
"Der Außenwand auf der Meerseite folgen, sie führt direkt zum Boss.",
"Warten, bis der <i>Hooded One</i> das Waffenteil aufgehoben hat, erst dann raus: sonst musst du zurück.",
"Bei 50% und 25% Leben eine <i>Ballista</i> benutzen.",
"Monster im Wasser haben ~80% Schadensreduktion: vorbeilaufen.",
"Mit Leap/Pounce: durch die Gitterwände springen statt außen herum."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Prisoner",
"npc": ""
},
{
"t": "Geh nach <z>Shrike Island</z>",
"sub": [],
"z": "Shrike Island",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Scourge of the Skies</k> töten → Waffenteil 3/3",
"sub": [
"Bis ans Ende der Zone laufen.",
"Warten, bis der <i>Hooded One</i> das Waffenteil aufgehoben hat, erst dann raus: sonst musst du zurück."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Scourge of the Skies",
"npc": ""
},
{
"t": "Geh nach <z>Whakapanu Island</z>",
"sub": [],
"z": "Whakapanu Island",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Great White One</k> töten → <i>Shark Fin</i>",
"sub": [
"Hai-Arena am Zonenrand (Checkpoint), dann weiter nach Singing Caverns.",
"Diesen Patch hält Diamora Matiki: beide Zonen sind deshalb optional.",
"Speedrunner skippen die Hai-Arena: der Buff ist die Zeit kaum wert.",
"Fin behalten: <i>Kaimana</i> gibt am Aktende in Kingsmarch den permanenten Defensiv-Buff.",
"Optional: <i>Crabshell Cavern</i> (Checkpoint) → Uncut Support Gem."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Great White One",
"npc": ""
},
{
"t": "Geh nach <z>Singing Caverns</z>",
"sub": [],
"z": "Singing Caverns",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Diamora</k> töten → <i>Matiki</i> befreien",
"sub": [
"Der Singstimme folgen. Kälte-Resi anziehen.",
"Diesen Patch hält Diamora Matiki: beide Zonen sind deshalb optional.",
"Matiki ansprechen, zurück zum Schiff, Matiki erneut ansprechen → Segeln zum <i>Eye of Hinekora</i>.",
"<i>Beckoning Clam</i> (Checkpoint) öffnen → Humming Pearl für Rog (Amulett mit allen Resis).",
"Wenn sie singt, nicht in die Wasserspiegel am Arenarand schauen: sonst Versteinerungs-Stacks."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Diamora",
"npc": ""
},
{
"t": "Geh nach <z>Eye of Hinekora</z>",
"sub": [],
"z": "Eye of Hinekora",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Silent Hall</i> → <i>+5% max. Mana</i> <span class=\"lvl\">Lv 45</span>",
"sub": [
"Matiki ansprechen, in den Well of Passing schauen, die 3 Tests of Mettle (Kaom, Maata, Rakiata) schaffen. Silent Hall liegt hinter einem Checkpoint.",
"Silent Hall anklicken, <i>Respawn at Checkpoint, sobald +5% Mana im Chat steht</i>: skippt die Animation (Pausieren muss aus sein).",
"Truhe hinter dem Wasserfall (zwischen Test 2 und 3): garantiertes Spirit Gem."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Halls of the Dead</z>",
"sub": [],
"z": "Halls of the Dead",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) 3 Tests schaffen → <i>3 Tattoos</i>",
"sub": [
"Blank Tattoo am Totem tauschen: je +5% Resi (empfohlen) oder +5 Attribut. Einmalige Wahl.",
"<i>Yama the White</i> töten, Silver Coin aufheben, dann durch das Portal zu Trial of the Ancestors."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Trial of the Ancestors</z>",
"sub": [],
"z": "Trial of the Ancestors",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Navali</i> ansprechen → <i>+2 Passive-Punkte</i> (+2 Waffenset-Punkte)",
"sub": [
"Tattoo of Hinekora per Rechtsklick benutzen."
],
"z": "",
"k": "pp",
"q": "Trial of the Ancestors",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Kingsmarch</z>",
"sub": [],
"z": "Kingsmarch",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> ansprechen, dann <i>Makoru</i> → Arastas",
"sub": [
"Geht erst mit allen 3 Waffenteilen.",
"Humming Pearl bei <i>Rog</i> abgeben → Pearlescent Amulet (alle Resis).",
"Journey's End noch offen? Jetzt per Waypoint Omniphobia machen, danach Tujen ansprechen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Arastas</z>",
"sub": [],
"z": "Arastas",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Torvian</k> töten <span class=\"lvl\">Lv 46-47</span>",
"sub": [
"Lorandis folgen, das Kraftfeld zerstören, den Hinterhalt überleben. Priester: der rechte gibt Torvian Schadensreduktion, der linke Elementar-Immunität. Torvian töten, bevor sie buffen.",
"<i>Nach der Blase das Pack draußen komplett töten:</i> erst dann springt die Quest weiter. Sonst schickt dich jeder Tod oder Checkpoint-Reset vor die Cutscene zurück (~1 min).",
"Glocke auf der Klippenseite = <i>3 Exalted Orbs</i>, Glocke gegenüber = 3 Regal Orbs.",
"<i>Minimal:</i> Glocken auslassen."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Torvian",
"npc": ""
},
{
"t": "Geh nach <z>The Excavation</z>",
"sub": [],
"z": "The Excavation",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Benedictus</k> töten",
"sub": [
"Blitz-Resi anziehen. Im Labyrinth rechtzeitig auf die sichere Seite laufen.",
"Arena betreten, dann sofort Respawn at Checkpoint: skippt Benedictus' langen Dialog.",
"Bei 50% wird er immun (Steine auf beiden Seiten): Burst für danach aufheben.",
"Garantierter Shrine in der Zone: mitnehmen (XP-Shrine = doppelte XP).",
"Excavated Site betreten: sobald die Quest <i>Speak to the Hooded One</i> zeigt, Esc → Respawn at Checkpoint (skippt die Cutscene).",
"Hooded One ansprechen, Portal nach Kingsmarch."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Benedictus",
"npc": ""
},
{
"t": "Geh nach <z>Kingsmarch</z>",
"sub": [],
"z": "Kingsmarch",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> ansprechen, dann <i>Rhodri</i> am Schiff → Ngakanu",
"sub": [
"Makoru ist verletzt: ab hier segelt Rhodri.",
"Tankigste Ausrüstung anlegen: Ngakanu und Heart of the Tribe haben viele Projektile und das größte Level-Defizit."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Ngakanu -> Heart of the Tribe</z>",
"sub": [],
"z": "Ngakanu -> Heart of the Tribe",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Tavakai</k> töten <span class=\"lvl\">Lv 48</span>",
"sub": [
"Heart of the Tribe: nach dem 1. Checkpoint zwischen den zwei Gebäuden durch, dann immer tiefer in die Zone. Weitere Checkpoints markieren Nebenziele: umdrehen.",
"3 Phasen, stirbst du, startet der Kampf von vorn.",
"Phase 2: in eine Ecke stellen, bei den Spikes aus der Luft rausrollen und wieder rein. Phase 3 genauso, dazu stunnen.",
"Danach: Hooded One heilt Tavakai und Makoru, Tavakai ansprechen, Portal nach Kingsmarch."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Tavakai",
"npc": ""
},
{
"t": "Geh nach <z>Kingsmarch</z>",
"sub": [],
"z": "Kingsmarch",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> ansprechen → Interludes offen",
"sub": [
"<i>Kaimana</i> (Plattform am Dock-Ende, gegenüber dem Schiff): Shark Fin abgeben → <i>Kaom's Lesson</i> (30% erhöhte Armour/Evasion/ES) oder Rakiata's Lesson. Permanent.",
"Tujen-Belohnung (Journey's End) abgeholt? Sonst jetzt."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 5,
"title": "Interludes 1-3 (Level ~50 → 56-60)",
"short": "Interludes",
"tip": "Interludes geben dir die restlichen Passivpunkte und Spirit vor den Maps.",
"steps": [
{
"t": "Geh nach <z>The Khari Bazaar</z>",
"sub": [],
"z": "The Khari Bazaar",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Asala</i> und <i>Zarka</i> ansprechen, Nordost-Ausgang nehmen <span class=\"lvl\">Lv ~50</span>",
"sub": [
"Interlude 2, Teil 1. Anreise: Hooded One in Kingsmarch → Vastiri."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Skullmaw Stairway</z>",
"sub": [],
"z": "Skullmaw Stairway",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <i>Molten One's Gift</i> nehmen → <i>+5% max. Leben</i>",
"sub": [
"Khari Crossing: nach Norden, an der Wand links zum Molten Shrine, runter in die Stairway, Gegner räumen.",
"Danach <i>Respawn at Checkpoint</i>: bringt dich zurück in die Khari Crossing."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Galai Gates</z>",
"sub": [],
"z": "The Galai Gates",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Nur den <w>Waypoint</w> holen, zurück in die Khari Crossing",
"sub": [
"In der Khari Crossing an der Westwand entlang.",
"<i>Vornas</i> erst später töten (nach Elzarah)."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Khari Crossing</z>",
"sub": [],
"z": "The Khari Crossing",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Akthi & Anundr</k> töten → Risu: <i>+2 Passive-Punkte (+2 Waffenset-Punkte)</i>",
"sub": [
"Per Checkpoint zum Stadteingang, von dort nach Osten zur Arena. Danach Portal in den Bazaar, Buch bei <i>Risu</i> holen.",
"<i>Torbik</i> (Händler im Wagen mit Checkpoint, Nordosten der Zone): erst die Angreifer töten. Verkauft Caster-Waffen, Sceptres und Schmuck."
],
"z": "",
"k": "pp",
"q": "Clearing the Way",
"e": 0,
"kt": "Akthi & Anundr",
"npc": ""
},
{
"t": "Geh nach <z>Pools of Khatal</z>",
"sub": [],
"z": "Pools of Khatal",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Waypoint</w> aktivieren, per WP zurück in den Khari Bazaar",
"sub": [
"Bazaar: Südwest-Ausgang, in der Khari Crossing nach Westen.",
"Im Bazaar: <i>Hooded One -> Mount Kriar</i> (Interlude 3).",
"Der Quest-Schritt Tower of Ab Binayi / Wayfinder ist nur Wegweiser: direkt nach Westen laufen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Glade -> Ashen Forest</z>",
"sub": [],
"z": "The Glade -> Ashen Forest",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Durch den <i>Ashen Forest</i> nach <i>Kriar Village</i> <span class=\"lvl\">Lv ~51</span>",
"sub": [
"Interlude 3. Ashen Forest hat keinen Waypoint.",
"Optional: <i>Ancient Monument</i> (Checkpoint) = Uncut Skill Gem Level 14."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Kriar Village</z>",
"sub": [],
"z": "Kriar Village",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Lythara</k> töten → <i>+40 Spirit</i>",
"sub": [
"Bei halber HP stunnen und im Stun-Fenster umhauen. Sie wird mit der Zeit durch Wisps stärker: bursten.",
"<i>Gemcrust Skull</i> rechtsklicken: +40 Spirit + Uncut Spirit Gem Level 14."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Lythara",
"npc": ""
},
{
"t": "Geh nach <z>Glacial Tarn -> Howling Caves</z>",
"sub": [],
"z": "Glacial Tarn -> Howling Caves",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Abominable Yeti</k> töten → Hilda: <i>+2 Passive-Punkte (+2 Waffenset-Punkte)</i>",
"sub": [
"Glacial Tarn: an der Ostwand (rechts) zu den Howling Caves.",
"<i>Icy Tusks</i> aufheben, Portal in The Glade, bei <i>Hilda</i> abgeben, per WP zurück in den Glacial Tarn."
],
"z": "",
"k": "pp",
"q": "Howling Winds",
"e": 0,
"kt": "Abominable Yeti",
"npc": ""
},
{
"t": "Geh nach <z>Glacial Tarn</z>",
"sub": [],
"z": "Glacial Tarn",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Rakkar</k> töten → Kriar Peaks",
"sub": [
"An der Nordwestwand entlang: Rakkar bewacht den Eingang zu den Kriar Peaks."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Rakkar",
"npc": ""
},
{
"t": "Geh nach <z>Kriar Peaks</z>",
"sub": [],
"z": "Kriar Peaks",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Elder Madox</i> ansprechen → <i>1 Unique nach Wahl</i>",
"sub": [
"Seitenweg am Zonenrand, von Eulen markiert. Am Ende mit der Plattform runter in die Etched Ravine.",
"<i>Minimal:</i> Nur durchlaufen, Elder Madox ist optional."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Etched Ravine</z>",
"sub": [],
"z": "Etched Ravine",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Stormgore</k> töten → Cuachic Vault",
"sub": [
"Bewacht den Eingang zur Vault. Slams per Dodge-Roll durchrollen."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Stormgore",
"npc": ""
},
{
"t": "Geh nach <z>The Cuachic Vault</z>",
"sub": [],
"z": "The Cuachic Vault",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Zolin & Zelina</k> töten, dann <i>Doryani beschwören und ansprechen</i>",
"sub": [
"<i>Zelina zuerst</i>: ihre Klaue macht starken Bleed, Staunching Charm tragen.",
"Ohne das Doryani-Gespräch ist das Interlude nicht abgeschlossen.",
"Danach direkt per WP zu den <i>Pools of Khatal</i>: Waypoints gehen interlude-übergreifend."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Zolin & Zelina",
"npc": ""
},
{
"t": "Geh nach <z>Sel Khari Sanctuary</z>",
"sub": [],
"z": "Sel Khari Sanctuary",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Elzarah</k> töten, dann <i>Asala</i> ansprechen <span class=\"lvl\">Lv ~54</span>",
"sub": [
"Interlude 2, Teil 2. Von den Pools of Khatal weiter in die Sanctuary.",
"Optional: <i>Yoon's</i> und <i>Rangeen's Barya</i> (findest du beim Durchlaufen) in die zwei Sockel am Rand → 2 Wünsche: Rare-Ring, -Amulett oder -Jewel.",
"Droppt Elzarah eine <i>Level-60-Barya</i>: aufheben für die 3. Ascendancy.",
"<i>Minimal:</i> Elzarah und Asala sind Pflicht, die Baryas optional."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Elzarah",
"npc": ""
},
{
"t": "Geh nach <z>The Galai Gates</z>",
"sub": [],
"z": "The Galai Gates",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Vornas</k> töten → Qimah",
"sub": [
"Portal in den Bazaar, per WP zu den Galai Gates. Vornas: Physisch + Blitz.",
"Nach Interlude 3 sind die Zonen hier Level 60: Resi-Malus -50%. Resis checken."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Vornas",
"npc": ""
},
{
"t": "Geh nach <z>Qimah</z>",
"sub": [],
"z": "Qimah",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Boon</i> an den Seven Pillars wählen, <i>Jado</i> beschwören",
"sub": [
"Pillars: Seitenraum mit Checkpoint, am Nordrand oder südöstlich vom Arena-Eingang. Jado am Zeremonieplatz, er öffnet das Qimah Reservoir.",
"<i>Tabana's</i>: +5% alle Ele-Resis. <i>Orbala's</i>: 3% Movespeed. Sonst: Kochai's +5 Attribute, Halani's 12% Cooldown Recovery, Ahkeli's 15% Defences, Galai's 20% Presence. Jederzeit wechselbar.",
"<i>Alima's</i> (+5% XP) dreht alle sechs anderen Boons ins Negative: nicht nehmen.",
"<i>Minimal:</i> Jado ist Pflicht, der Boon optional."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Qimah Reservoir</z>",
"sub": [],
"z": "Qimah Reservoir",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Azmadi</k> töten, <i>Grand Barya</i> benutzen, <i>Jado</i> ansprechen",
"sub": [
"Lange Kombos: durchrollen und nur im Fenster Schaden machen, oder direkt bursten.",
"Optional: 2 <i>Vials of Sacred Water</i> (droppen von Monstern) in die Sacred Wells → je 1 zufällige Currency.",
"Danach Portal in den Bazaar: <i>Hooded One -> Ogham</i> (Interlude 1)."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Azmadi",
"npc": ""
},
{
"t": "Geh nach <z>The Refuge -> Scorched Farmlands</z>",
"sub": [],
"z": "The Refuge -> Scorched Farmlands",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Isolde & Heldra</k> töten → Stones of Serle <span class=\"lvl\">Lv ~57</span>",
"sub": [
"Interlude 1. Zuerst den Checkpoint an der Dunkelheitswand holen, dann die beiden suchen. Isolde: Kälte, Heldra: Feuer.",
"Zonen hier sind jetzt Level 62-64: Resi-Malus -50%. Resis vorher auffüllen.",
"Optional: Uncut Skill Gem an einer Leiche am Weg (Checkpoint)."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Isolde & Heldra",
"npc": ""
},
{
"t": "Geh nach <z>Stones of Serle</z>",
"sub": [],
"z": "Stones of Serle",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>6 Megalithen</i> aktivieren, dann <k>Siora</k> töten",
"sub": [
"Megalithen stehen am Zonenrand, Siora im Steinkreis in der Mitte. Verdunkelt sie die Arena: zum leuchtenden Megalith laufen.",
"Siora ist sehr mobil: stunnen.",
"Danach auf <i>Una</i> warten und sie ansprechen. Erst zurückgehen, wenn die Quest 'Return to the Darkness' anzeigt."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Siora",
"npc": ""
},
{
"t": "Geh nach <z>The Blackwood -> Holten</z>",
"sub": [],
"z": "The Blackwood -> Holten",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per Checkpoint zur Dunkelheit, durch <i>The Blackwood</i> nach <i>Holten</i>",
"sub": [
"Omen-Altäre im Blackwood auslassen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Holten</z>",
"sub": [],
"z": "Holten",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) Beim <i>Soul of the Ferryman</i> Greater Runes kaufen",
"sub": [
"Am Nordostrand bis zur Brücke, rüber, dann Richtung Südwest. Etwa 2000 Gold pro Rune.",
"Runen für Resis und die nächste Waffe. <i>Sigbert & Godwin</i> (Psalm of Blood) skippen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Wolvenhold</z>",
"sub": [],
"z": "Wolvenhold",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "(optional) <k>Oswin</k> töten → <i>Warden's Ledger</i>: +2 Passive-Punkte (+2 Waffenset-Punkte)",
"sub": [
"Holten: am Nordostrand nach Wolvenhold. Oswin sitzt am Nordost- oder Nordwest-Ende der Zone.",
"Danach per Checkpoint zurück nach Holten."
],
"z": "",
"k": "pp",
"q": "Kill Oswin -> Warden's Ledger: +2 passiv",
"e": 0,
"kt": "Oswin",
"npc": ""
},
{
"t": "Geh nach <z>Holten Estate</z>",
"sub": [],
"z": "Holten Estate",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<k>Thane Wulfric & Lady Elswyth</k> töten",
"sub": [
"Holten: am Nordrand zum Estate. Links herum zur Treppe, im Obergeschoss genauso zur Arena.",
"<i>Lady Elswyth zuerst</i>."
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Thane Wulfric & Lady Elswyth",
"npc": ""
},
{
"t": "Geh nach <z>The Refuge</z>",
"sub": [],
"z": "The Refuge",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Renly</i> ansprechen, per WP nach Kingsmarch",
"sub": [
"Portal aus dem Holten Estate."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Kingsmarch</z>",
"sub": [],
"z": "Kingsmarch",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i>: Book of Specialisation holen → <i>+2 Passive-Punkte (+2 Waffenset-Punkte)</i>",
"sub": [
"Buch sofort benutzen, dann beim Hooded One <i>Travel to Oriath</i>."
],
"z": "",
"k": "pp",
"q": "Siege of Oriath",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>The Ziggurat Refuge</z>",
"sub": [],
"z": "The Ziggurat Refuge",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Hooded One</i> und <i>Doryani</i> ansprechen, <i>Map Device</i> benutzen",
"sub": [
"Die Reise nach Oriath endet hier. Kampagne fertig, weiter im Tab Maps."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 6,
"title": "Bonus: Von der Kampagne in die Maps",
"short": "Maps",
"tip": "",
"steps": [
{
"t": "Waystone von <i>Doryani</i> nehmen, an der <i>Reforging Bench</i> hochreforgen",
"sub": [
"3 Waystones gleicher Stufe → 1 der nächsten Stufe. Doryani verkauft bis zu 10 Waystones: Tier 1 oder 1 Tier unter deinem höchsten abgeschlossenen.",
"Hast du 2 Waystones einer Stufe: 3 der Stufe darunter kaufen, zu einem dritten reforgen, dann alle drei eine Stufe hoch.",
"Gold für Waystones sammeln: Rares beim Vendor verkaufen statt liegen lassen.",
"Die Vendoren hier verkaufen Level-65-Items: nach einer neuen Waffenbase schauen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Atlas</z>",
"sub": [],
"z": "Atlas",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Powerful Map Bosses</i> ansteuern: der Boss droppt einen Waystone 1 Tier höher",
"sub": [
"Den höchsten Waystone immer in eine Powerful-Boss-Map legen und direkt zum Boss laufen.",
"Waystones magic machen (Transmute + Augment), Powerful-Boss-Maps rare: höhere Chance auf Waystone-Drops.",
"<i>Hilda's Campsite</i> (nahe am Start): ersten Great Beast töten, Punkt in <i>Mighty Prey</i> (25% Chance, dass Map-Bosse Powerful werden)."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Erstes Ziel: <i>Fortress-Questline</i> für Atlas-Punkte",
"sub": [
"Tower → Ancient Gateway → Burning Monolith. Eastern/Western Gateway brauchen T5+, Eastern/Western Enigma T10+.",
"Maps mit <i>+</i> auf dem Atlas geben einen Atlas-Punkt: auf dem Weg mitnehmen.",
"Liga-Mechaniken erst ab ~100 Atlas-Punkten bzw. T15. Vorher nur Boss-Rush, Essences und Shrines mitnehmen."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Höchstens <i>6-8 Level</i> unter dem Map-Level bleiben",
"sub": [
"Liegst du weiter zurück: eine Map ohne Tier-Aufstieg dazwischenschieben. Ab Level 65 spielt der XP-Malus kaum noch eine Rolle."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<i>Feuer- und Blitz-Resi cappen</i>, Kälte notfalls offen lassen",
"sub": [
"Mit 40% auf allen drei stirbt man an jedem Element. Zwei gecappt = gegen zwei Elemente sicher."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Trial of the Sekhemas / Trial of Chaos</z>",
"sub": [],
"z": "Trial of the Sekhemas / Trial of Chaos",
"k": "travel",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<i>Ascendancy nachholen</i>: 2. Trial mit dem Chimeral Inscribed Ultimatum (Akt 3), 3. mit einer Level-60-Barya",
"sub": [
"3. Trial mit ~Level 70 laufen: leicht überlevelt geht er schnell.",
"Links und rechts vom Mittelweg am Burning Monolith liegen Maps mit garantiertem Trial-Key (Barya oder Ultimatum).",
"Relikte mit Honour-Resistenz machen den Sekhemas-Trial deutlich leichter."
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
}
];
window.CAMPAIGN_POE2_EN = [
{
"tip": "",
"title": "Act 1: Ogham (Level 1 → 14)",
"short": "Act 1",
"steps": [
{
"t": "Go to <z>The Riverbank</z>",
"sub": []
},
{
"t": "Kill <k>The Bloated Miller</k>",
"sub": [
"Fight him in the corner opposite the entrance: afterwards walk straight past the blockade into town.",
"Stay above 35 life and his slam won't kill you."
]
},
{
"t": "Go to <z>Clearfell Encampment</z>",
"sub": []
},
{
"t": "Talk to <i>Renly</i> → first <i>Uncut Skill Gem</i>",
"sub": [
"Cut your skill, then head straight out to Clearfell."
]
},
{
"t": "Go to <z>Clearfell</z>",
"sub": []
},
{
"t": "Kill <k>Beira of the Rotten Pack</k> → <i>+10% cold resistance</i>",
"sub": [
"Beira is in the middle of the zone. Pick up and use the <i>Head of the Winter Wolf</i>.",
"<i>Minimal:</i> Just run to the exit to The Grelwood, Beira is optional.",
"<i>Mysterious Campsite</i> (checkpoint): guaranteed Uncut Skill Gem, e.g. for Frost Bomb (Exposure).",
"Skip the <i>Mud Burrow</i>: it only gives a Support Gem + gold from Renly."
]
},
{
"t": "Go to <z>The Grelwood</z>",
"sub": []
},
{
"t": "Grab the <w>Waypoint</w> at the <i>Tree of Souls</i>, then into <i>The Red Vale</i> <span class=\"lvl\">Lv 3-4</span>",
"sub": [
"Follow the glowing roots to the Tree of Souls, then go upriver to the Red Vale.",
"The 4 POIs form a <i>diamond</i>: Witch Hut, Grim Tangle entrance, Tree of Souls, Brambleghast. Once you know two, you know where the others are.",
"Follow the mushrooms to the <i>Grim Tangle</i> entrance, step in briefly and activate its Waypoint.",
"<i>Witch Hut</i> (optional): the cauldron gives a Medium Life + Mana Flask, even without the kill. <i>Areagne, Forgotten Witch</i> drops a Support Gem: Respawn at Checkpoint first so no monsters are nearby.",
"Skip <i>Gerung, the Brambleghast</i>: it only gives a level 2 Skill Gem."
]
},
{
"t": "Go to <z>The Red Vale</z>",
"sub": []
},
{
"t": "Activate 3 <i>Obelisks of Rust</i>, kill the <k>Rust King</k> <span class=\"lvl\">Lv 5</span>",
"sub": [
"Each obelisk summons a wave that drops a rune quest item. At the third one the Rust King spawns instead.",
"Click every <i>Rusted Arms</i> and <i>Refined Arms</i> (weapon racks): together they drop at least one weapon of every type except wand and staff. Transmute the best base.",
"Portal to town after the kill."
]
},
{
"t": "Go to <z>Clearfell Encampment</z>",
"sub": []
},
{
"t": "<i>Renly</i>: hand in the runes, take the <i>Runed Spikes</i>",
"sub": [
"Then WP to The Grelwood.",
"Identify rares before selling: identified they sell for more gold.",
"No usable weapon from the Red Vale: buy a magic one with flat damage or %phys from the vendor (lightning is ideal, for shock), otherwise a white base. From now on transmute every good white base.",
"Check the vendor with a search regex: gloves with flat damage, a better weapon, boots with movement speed."
]
},
{
"t": "Go to <z>The Grelwood</z>",
"sub": []
},
{
"t": "Break the <i>3 Runic Seals</i> at the Tree of Souls with the Runed Spikes",
"sub": [
"Skip Una at the tree: portal to town, talk to <i>Una</i> there, then WP to The Grim Tangle."
]
},
{
"t": "Go to <z>The Grim Tangle</z>",
"sub": []
},
{
"t": "Summon <i>Una</i> at the roots, then on to the <i>Cemetery of the Eternals</i> <span class=\"lvl\">Lv 5-6</span>",
"sub": [
"Talk to Una, click away the dialogue, roll straight into the checkpoint: you pass the roots without waiting for her song.",
"<i>Minimal:</i> Just run through, Ervig is optional.",
"<i>Ervig</i> (Rotten Druid): guaranteed Support Gem. He teleports, fire your cooldowns after that.",
"Fungal Zombies explode on death: don't stand on corpses."
]
},
{
"t": "Go to <z>Cemetery of the Eternals</z>",
"sub": []
},
{
"t": "Kill <k>Asinia</k> and <k>Draven</k> → 2 Memorial Key Pieces <span class=\"lvl\">Lv 7</span>",
"sub": [
"Asinia is in the <i>Tomb of the Consort</i>, Draven in the <i>Mausoleum of the Praetor</i>. Hug the walls to find both entrances, grab the Waypoint.",
"<i>Ancient Ruin</i> (sarcophagus at the zone edge): guaranteed Iron Ring or Lazuli Ring. Transmute the ring: about a 1/3 chance of a damage prefix (flat attack damage).",
"<i>Asinia</i> teleports: use your burst only after the teleport.",
"<i>Draven</i> is hard to hit: your damage window is when he stabs the ground and sends out his wave.",
"Tomb: <i>Haunted Treasure</i> (POI) spawns a rare with a guaranteed Support Gem. Stay close and don't hit his shield, or he fires projectiles.",
"Mausoleum: the round <i>Wheel</i> tile is the center. Draven is on the side opposite the entrance.",
"Mausoleum: <i>Forgotten Riches</i> (POI) = gold + rare chest with a Support Gem."
]
},
{
"t": "Kill <k>Lachlann of Endless Lament</k> at the <i>Memorial Gate</i> by the Waypoint",
"sub": [
"Open the gate, then Respawn at Checkpoint right away: Lachlann spawns without his monologue.",
"Leave <i>Count Lachlann's Ring</i> on the ground: saves the cutscene with Una. You unlock the Hooded One at the end of the act anyway.",
"Lachlann drops a <i>level 3 Skill Gem</i>."
]
},
{
"t": "Go to <z>Hunting Grounds</z>",
"sub": []
},
{
"t": "Kill <k>The Crowbell</k> → <i>+2 passive points</i> <span class=\"lvl\">Lv 7-8</span>",
"sub": [
"Follow the zone edge: Crowbell and the Farmlands and Freythorn entrances are along it.",
"<i>Minimal:</i> Only go to the Ogham Farmlands entrance, Crowbell is optional.",
"Step into Ogham Farmlands briefly and activate the Waypoint, then continue to Freythorn.",
"Keep hitting Crowbell as he runs to the second arena, drop Exposure on his path.",
"Drops a <i>Book of Specialisation</i> (right-click to use) and a level 3 Skill Gem.",
"<i>Dryadic Ritual</i> (rare) on the way: guaranteed Support Gem."
]
},
{
"t": "Go to <z>Freythorn</z>",
"sub": []
},
{
"t": "(optional) Cleanse 3 Ritual Altars, kill <k>The King in the Mists</k> → <i>+30 Spirit</i> <span class=\"lvl\">Lv 8-9</span>",
"sub": [
"The smoke trails at a cleansed altar point to the next one. Then the large altar at the top: kill the wave and the King spawns.",
"Pick up and use the <i>Gembloom Skull</i>: +30 Spirit + level 4 Uncut Spirit Gem.",
"He teleports a lot: burst after the teleport. In phase 2 he gets knocked far back when stunned.",
"Open the ritual window: take a gear upgrade (e.g. damage gloves), otherwise currency."
]
},
{
"t": "Go to <z>Clearfell Encampment</z>",
"sub": []
},
{
"t": "(optional) <i>Finn</i>: pick a Charm, <i>Una</i>: buy a Greater Life/Mana Flask <span class=\"lvl\">Lv 10</span>",
"sub": [
"Then WP to Ogham Farmlands.",
"Finn offers a Ruby, Sapphire or Topaz Charm.",
"At level 10 check the vendor for new weapon bases."
]
},
{
"t": "Go to <z>Ogham Farmlands</z>",
"sub": []
},
{
"t": "Pick up <i>Una's Lute</i> → <i>+2 passive points</i> from Una <span class=\"lvl\">Lv 10</span>",
"sub": [
"The roads lead to <i>Una's Hut</i> (checkpoint) with the lute, then follow a road to Ogham Village.",
"<i>Minimal:</i> Just run through, the lute is optional.",
"<i>Crop Circle</i> (rare in the wheat field): guaranteed level 4 Uncut Skill Gem. Walk into the center to spawn the mobs."
]
},
{
"t": "Go to <z>Ogham Village</z>",
"sub": []
},
{
"t": "Kill <k>The Executioner</k>, pull the lever, talk to <i>Leitis</i> <span class=\"lvl\">Lv 11</span>",
"sub": [
"His loot takes a few seconds to drop: pull the lever on the platform meanwhile, then pick it up.",
"<i>Minimal:</i> Executioner, lever and Leitis are required, workshop and chest are optional.",
"Follow the road to <i>Renly's Workshop</i>: the <i>Smithing Tools</i> unlock the Salvage Bench at Renly.",
"<i>Blacksmith's Chest</i> next to the tools: Blank Rune + Artificer's Orb, save them for the level 16 weapon."
]
},
{
"t": "Go to <z>Clearfell Encampment</z>",
"sub": []
},
{
"t": "(optional) <i>Una</i>: hand in the lute → <i>+2 passive points</i>",
"sub": [
"Portal or WP from the Village. Can also wait until the end of the act, together with the Hooded One.",
"<i>Leitis</i>: collect a level 5 Uncut Skill Gem.",
"<i>Renly</i>: hand in the Smithing Tools, trade the Blank Rune for a Lesser Rune (Desert, Glacial, Storm or Iron).",
"Right-click Una's Book of Specialisation to use it.",
"Buy a Greater Life Flask if you don't have one yet: the Ramparts and the Manor hit hard."
]
},
{
"t": "Go to <z>The Manor Ramparts</z>",
"sub": []
},
{
"t": "To <i>Ogham Manor</i>, reaching <i>level 13</i> on the way <span class=\"lvl\">Lv 12</span>",
"sub": [
"Follow the inner edge and kill everything on the way: good XP zone.",
"<i>The Gallows</i> (outer edge, checkpoint): click the corpse and walk away immediately, then the Support Gem drops next to you instead of up on the gallows.",
"Next to the Gallows there is a guaranteed magic pack: take it."
]
},
{
"t": "Go to <z>Ogham Manor</z>",
"sub": []
},
{
"t": "Kill <k>Count Geonor</k> at <i>level 14</i> <span class=\"lvl\">Lv 14</span>",
"sub": [
"Floor 1: <i>Candlemass, the Living Rite</i> for <i>+20 life</i> (usually a top corner, before or after the bridge). Geonor: take the lift down at the end of floor 3.",
"<i>Minimal:</i> Only Geonor is required, Candlemass is optional.",
"Each floor is area, bridge, area. On the next floor run the opposite direction.",
"Level 14 lets you use gem level 5 (Leitis' gem). Below that, keep killing packs in the Manor.",
"Below 50% Geonor vanishes into fog: kill the adds for flask charges, he lunges at you at the end of each voice line, dodge then. Block his cold beams with a shield.",
"<i>Speed order:</i> kill Geonor first, while his dialogue plays take the lift up, checkpoint to Candlemass, then back to Geonor's loot."
]
},
{
"t": "Go to <z>Clearfell Encampment</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i> → <i>Follow the Beast's trail</i>",
"sub": [
"Travels to the Vastiri Outskirts. Sell your inventory and check the vendor first.",
"Catch up on anything left: lute to Una, level 5 gem from Leitis, Smithing Tools and Blank Rune to Renly."
]
}
]
},
{
"tip": "",
"title": "Act 2: Vastiri (Level 14 → 28/29)",
"short": "Act 2",
"steps": [
{
"t": "Go to <z>Vastiri Outskirts</z>",
"sub": []
},
{
"t": "Kill <k>Rathbreaker</k> <span class=\"lvl\">Lv 14</span>",
"sub": [
"Follow the spear lines on the ground: they point to the bone passage towards Rathbreaker.",
"Stay behind him: then his slam can't hit you.",
"With Leap/Pounce: target a monster next to Rathbreaker at the cliff and jump straight up.",
"Optional: <i>Raider Camp</i> (checkpoint) = tier-2 support gem.",
"Then portal, take the Uncut Skill Gem from <i>Zarka</i>, then enter <i>The Ardura Caravan</i>."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i>, then <i>Asala</i> → Desert Map <i>Mawdun Quarry</i>",
"sub": [
"All act long, pick the Desert Map destination first, then sell and do stash work while the caravan travels.",
"Check vendors: <i>level-16 weapon</i>, damage gloves, boots with <i>15% movement speed</i>."
]
},
{
"t": "Go to <z>Mawdun Quarry</z>",
"sub": []
},
{
"t": "Find the entrance to <i>Mawdun Mine</i> <span class=\"lvl\">Lv 16</span>",
"sub": [
"Pick up all <i>Whetstones and Armour Scraps</i>: the zone is full of them.",
"Optional: <i>War Cache</i> at the zone edge (checkpoint) = guaranteed Artificer's Orb. Don't backtrack for it.",
"At level 16 craft your weapon (loot section: weapon crafting)."
]
},
{
"t": "Go to <z>Mawdun Mine</z>",
"sub": []
},
{
"t": "Kill <k>Rudja, the Dread Engineer</k>, free <i>Risu</i> <span class=\"lvl\">Lv 16-17</span>",
"sub": [
"On entering, Respawn at Checkpoint right away (skips the elevator), then follow the rails north or northeast.",
"Rudja deals heavy fire damage at range and in melee: stay close and behind her.",
"Talk to <i>Risu</i>, then portal to the caravan."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Talk to <i>Risu</i>, then <i>Asala</i> → Desert Map <i>Traitor's Passage</i>",
"sub": []
},
{
"t": "Go to <z>Traitor's Passage</z>",
"sub": []
},
{
"t": "Run through to <i>The Halani Gates</i> <span class=\"lvl\">Lv 17-18</span>",
"sub": [
"At the intersection with obelisk and checkpoint: walls without parchment lead to the exit, walls with parchment lead to Balbala.",
"<i>Minimal:</i> Just run through, Balbala is optional.",
"Early Ascendancy: follow the parchment, kill <i>Balbala, the Traitor</i> → Barya (level 22). She is fast and hard to hit.",
"Otherwise skip Balbala: a level-28 Barya is available in Deshar.",
"Optional: chest with bells (checkpoint) = Uncut Skill Gem level 6."
]
},
{
"t": "Go to <z>The Halani Gates</z>",
"sub": []
},
{
"t": "Kill <k>Jamanra, the Risen King</k> <span class=\"lvl\">Lv 18</span>",
"sub": [
"Asala opens the three gates: wait for her at every bridge, don't run ahead.",
"If Asala gets stuck: go to the checkpoint before the 2nd bridge, Respawn at Checkpoint: she is back next to you.",
"Fight Jamanra at <i>level 18</i> or higher.",
"Afterwards take the stairs behind the arena down to the sandstorm (quest update), then portal to the caravan."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Take the Uncut Skill Gem (level 7) from <i>Zarka</i>, talk to <i>Asala</i> → Desert Map <i>Mastodon Badlands</i>",
"sub": [
"Asala sends you to three regions for the horn: Mastodon Badlands, Keth, Valley of the Titans.",
"Order <i>Badlands -> Keth -> Valley</i>: Badlands before Keth, then Kabala drops a level-7 gem instead of level 6."
]
},
{
"t": "Go to <z>Trial of the Sekhemas</z>",
"sub": []
},
{
"t": "(optional) <i>Trial of the Sekhemas</i> with Balbala's Barya (level 22) <span class=\"lvl\">Lv 19-22</span>",
"sub": [
"Only for strong builds (level ~19-22), otherwise later with the level-28 Barya from Deshar.",
"Getting there: talk to <i>Zarka</i>, then Desert Map → <i>Trial of the Sekhemas</i>.",
"Ritual and Chalice rooms are short, Hourglass and Gauntlet take longer."
]
},
{
"t": "Go to <z>Mastodon Badlands</z>",
"sub": []
},
{
"t": "Find the entrance to <i>The Bone Pits</i> <span class=\"lvl\">Lv 20</span>",
"sub": [
"Follow the cracks in the ground."
]
},
{
"t": "Go to <z>The Bone Pits</z>",
"sub": []
},
{
"t": "Kill <k>Iktab, the Deathlord & Ekbab, Ancient Steed</k> → <i>Mastodon Tusks</i> <span class=\"lvl\">Lv 20-21</span>",
"sub": [
"Stand behind Iktab (the necromancer) so Ekbab runs onto him: hit both at once, kill Iktab first.",
"The bosses are in the direction the zone entrance faces.",
"<i>Minimal:</i> Only the bosses are required, the <i>Sun Clan Relic</i> (for the charm slot) is optional.",
"The Sun Clan Relic only drops from <i>hyenas</i> (big ones more often): kill every hyena.",
"Relic still missing: keep searching, don't reset via checkpoint, otherwise all monsters respawn.",
"Then portal, hand the tusks to <i>Zarka</i> (support gem), Desert Map → <i>Keth</i>."
]
},
{
"t": "Go to <z>Keth</z>",
"sub": []
},
{
"t": "Kill <k>Kabala, Constrictor Queen</k> → <i>+2 passive points (+2 weapon set points)</i> <span class=\"lvl\">Lv 21-22</span>",
"sub": [
"Follow the snakes and kill them: they lead to Kabala's arena (checkpoint).",
"<i>Minimal:</i> Just run to the <i>The Lost City</i> exit at the far end of the zone, Kabala is optional.",
"Snakes drop the <i>Kabala Clan Relic</i> (also in The Lost City): for the charm slot in the Valley of the Titans.",
"Optional: <i>Abandoned Prayer</i> (secret) = guaranteed magic amulet."
]
},
{
"t": "Go to <z>The Lost City</z>",
"sub": []
},
{
"t": "Find the entrance to the <i>Buried Shrines</i> <span class=\"lvl\">Lv 22</span>",
"sub": [
"The first corridor shows the general direction. The entrance is at the zone edge by the checkpoint at the V-shaped bridge.",
"No Kabala Clan Relic yet: keep killing snakes."
]
},
{
"t": "Go to <z>Buried Shrines</z>",
"sub": []
},
{
"t": "Kill <k>Azarian, the Forsaken Son</k> → <i>Essence of Water</i> <span class=\"lvl\">Lv 22-23</span>",
"sub": [
"Leave the loot, go straight to the <i>Water Goddess</i>: talk to her, put her to rest with the Everburning Cinders, grab loot during the animation, then pick up the Essence.",
"Keep <i>2x2 space</i> in your inventory for the Essence.",
"There are guaranteed magic packs on the bridges: take them.",
"Optional: <i>Elemental Offering</i> (checkpoint) = resistance ring + matching rune: pick your lowest resistance, lightning if unsure.",
"Then portal, hand the Essence to <i>Zarka</i> (support gem), Desert Map → <i>Valley of the Titans</i>."
]
},
{
"t": "Go to <z>Valley of the Titans</z>",
"sub": []
},
{
"t": "Activate the <i>3 Ancient Seals</i>: one at the end of each canyon <span class=\"lvl\">Lv 23</span>",
"sub": [
"The checkpoint at the Titan Grotto entrance is close to the start: take it, return via checkpoint after the seals.",
"<i>Minimal:</i> Only the 3 seals are required, the relic altar is optional.",
"<i>Relic altar</i> (in the canyon with the waypoint): insert Kabala Clan + Sun Clan Relic → <i>+1 charm slot</i> + choice: 30% increased charm charges gained or 30% increased charm duration (changeable later).",
"If your belt already has enough charm slots, you can skip the relics."
]
},
{
"t": "Go to <z>The Titan Grotto</z>",
"sub": []
},
{
"t": "Kill <k>Zalmarath, the Colossus</k> → <i>Flame Ruby</i> <span class=\"lvl\">Lv 24</span>",
"sub": [
"Stand right against his chest under his arm: his attacks barely hit you there.",
"Optional: <i>Titan's Sword</i> (POI) = guaranteed Lesser Rune. Only take it if it is on your path.",
"Then portal, hand the Flame Ruby to <i>Zarka</i>: she gives you the <i>Horn of the Vastiri</i>."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Desert Map to the sandstorm (<i>Traitor's Passage</i>), then <i>Sound the Horn</i> at the front of the caravan",
"sub": [
"Zarka only gives you the horn once the Mastodon Tusks, Essence of Water and Flame Ruby are handed in.",
"Then talk to <i>Asala</i> → Desert Map <i>Deshar</i>.",
"While travelling, upgrade <i>flasks</i> to level-23 bases."
]
},
{
"t": "Go to <z>Deshar</z>",
"sub": []
},
{
"t": "Take the <i>Final Letter</i> from <i>Fallen Dekhara</i> (for Shambrin: +2 passive points (+2 weapon set points)) <span class=\"lvl\">Lv 24</span>",
"sub": [
"Fallen Dekhara lies at the base of a random burial tower: check each tower base on the way to the exit, otherwise search back afterwards.",
"<i>Minimal:</i> Just run to the <i>Path of Mourning</i> exit, letter and Barya are optional.",
"Late Ascendancy: kill the two vultures (<i>Watchful Twins</i>) at the corpses (checkpoint) → guaranteed Barya (level 28).",
"Optional: guaranteed <i>Artificer's Orb</i> right at the start along the left or right edge.",
"Enter at <i>level 24</i> or higher: the zone gives full XP up to level 27."
]
},
{
"t": "Go to <z>Path of Mourning</z>",
"sub": []
},
{
"t": "Run through to <i>The Spires of Deshar</i> <span class=\"lvl\">Lv 25</span>",
"sub": [
"The world map (U) shows the direction of the exit.",
"Need the points for Tor Gul already: waypoint to the caravan, hand the Final Letter to <i>Shambrin</i>."
]
},
{
"t": "Go to <z>The Spires of Deshar</z>",
"sub": []
},
{
"t": "Kill <k>Tor Gul, the Defiler</k> <span class=\"lvl\">Lv 26</span>",
"sub": [
"You start facing north: Tor Gul is at the north end of the zone.",
"<i>Minimal:</i> Tor Gul is required, the Sisters of Garukhan are optional.",
"Click the <i>Sisters of Garukhan</i> (statue at a checkpoint) → <i>+10% lightning resistance</i>. The paths around the statue form a <i>G</i> on the map.",
"Tor Gul deals physical, fire and poison damage: keep <i>fire resistance</i> high, his fire breath is his most dangerous attack. Be at least <i>level 26</i>.",
"Then portal to the caravan."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Pick <i>The Dreadnought</i> on the Desert Map, hand the <i>Final Letter</i> to <i>Shambrin</i> while travelling → <i>+2 passive points (+2 weapon set points)</i>",
"sub": [
"Pick the destination first, then shop: this skips the ride up to the Dreadnought (~10 s).",
"Late Ascendancy first: talk to <i>Zarka</i>, Desert Map → <i>Trial of the Sekhemas</i> (next card), only then The Dreadnought."
]
},
{
"t": "Go to <z>Trial of the Sekhemas</z>",
"sub": []
},
{
"t": "(optional) <i>Trial of the Sekhemas</i> with the level-28 Barya from Deshar <span class=\"lvl\">Lv ~28</span>",
"sub": [
"Balbala hands you a level-22 Barya in the trial: manually place the level-28 Barya in the altar.",
"Ritual and Chalice rooms are short, Hourglass and Gauntlet take longer."
]
},
{
"t": "Go to <z>The Dreadnought</z>",
"sub": []
},
{
"t": "Kill <k>Jamanra, the Abomination</k> (act boss) <span class=\"lvl\">Lv 28-29</span>",
"sub": [
"Burst ~55k damage fast: then he doesn't get to his storm attack. Phase 2: stay close, dodge roll his slam and slash.",
"At least <i>level 28</i>, 29 is better: otherwise reset the zone and farm.",
"Since 0.5 there is no Dreadnought Vanguard anymore: Jamanra is at the end of The Dreadnought.",
"Then talk to <i>Asala</i>, portal to the caravan."
]
},
{
"t": "Go to <z>The Ardura Caravan</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i> in the shrine northwest of the caravan's midpoint (down a ramp)",
"sub": [
"Wait until the quest shows 'Talk to Asala...', then Esc → character select and log back in: you stand at the waypoint.",
"Then talk to <i>Asala</i> → <i>Sandswept Marsh</i> (Act 3)."
]
}
]
},
{
"tip": "",
"title": "Act 3: Jungle & Vaal (Level 29 → 41)",
"short": "Act 3",
"steps": [
{
"t": "Go to <z>Sandswept Marsh</z>",
"sub": []
},
{
"t": "Run through to the <i>Ziggurat Encampment</i> <span class=\"lvl\">Lv 29</span>",
"sub": [
"Take the crossing at the edge of the starting area, then straight through the marsh.",
"<i>Minimal:</i> Just pass through, everything else optional.",
"<i>Orok Campfire</i> near the exit: basket with a <i>Lesser Jeweller's Orb</i>.",
"Kill <i>Rootdredge</i> if he is on the way: drops an Uncut Skill Gem level 9.",
"Reach town at level 29 or higher, otherwise farm here: the early Act 3 zones give little XP."
]
},
{
"t": "Go to <z>Ziggurat Encampment</z>",
"sub": []
},
{
"t": "Talk to <i>Oswald</i>, check vendors <span class=\"lvl\">Lv 29</span>",
"sub": [
"Exit to the Jungle Ruins at the top of town.",
"Talk to Oswald first, otherwise his shop is not open.",
"From level 30: <i>Colossal Life Flask</i> at Servi. Still level 29: buy it on the next town visit.",
"Oswald: weapons, armour, belts. Servi: sceptres, wands, staves, flasks, rings, amulets, charms."
]
},
{
"t": "Go to <z>Jungle Ruins</z>",
"sub": []
},
{
"t": "Kill <k>Mighty Silverfist</k> → <i>+2 passive points</i> (+2 weapon set points) <span class=\"lvl\">Lv 29-30</span>",
"sub": [
"Follow the water's edge to the WP. Silverfist is in the middle of the zone.",
"<i>Minimal:</i> The zone is required, Silverfist is optional.",
"Dodge roll his swing and slam. His roll attack is lethal with little armour.",
"<i>Troubled Camp</i>: chest next to the vendor = guaranteed rare gloves.",
"The trail of snakes leads to the <i>Venom Crypts</i> entrance (checkpoint in front)."
]
},
{
"t": "Go to <z>Venom Crypts</z>",
"sub": []
},
{
"t": "(optional) Take the <i>Corpse-snake Venom</i> from the corpse <span class=\"lvl\">Lv 30</span>",
"sub": [
"Follow the humanoid enemies to the corpse, then take the exit there back into the Jungle Ruins.",
"Hand the venom to <i>Servi</i> in town: <i>Artificer's Orb</i> + permanent choice, recommended <i>25% Stun Threshold</i>.",
"Alternatives: 30% Elemental Ailment Threshold or 25% Mana Regeneration Rate. The choice is final.",
"This exit comes out near the entrance to the <i>Infested Barrens</i>."
]
},
{
"t": "Go to <z>Infested Barrens</z>",
"sub": []
},
{
"t": "Run through to the <i>Chimeral Wetlands</i> <span class=\"lvl\">Lv 31</span>",
"sub": [
"Grab the WP. The NPC in the Troubled Camp reveals the exit on the map.",
"<i>Level 31 = gems to level 9.</i>",
"<i>Troubled Camp</i>: chest next to the vendor = guaranteed rare boots."
]
},
{
"t": "Go to <z>Chimeral Wetlands</z>",
"sub": []
},
{
"t": "Kill <k>Xyclucian</k>, continue into <i>Jiquani's Machinarium</i> <span class=\"lvl\">Lv 32</span>",
"sub": [
"Both along the zone edge: the Temple of Chaos WP and Xyclucian in front of the Machinarium entrance.",
"At 75/50/25% he flies onto a pillar: destroy the stone platform under him to stun him briefly.",
"Pick up the <i>Chimeral Inscribed Ultimatum</i>: key for the Trial of Chaos.",
"Carrying the venom? Activate the WP, portal to town, hand it to <i>Servi</i>, back through the portal."
]
},
{
"t": "Go to <z>Jiquani's Machinarium</z>",
"sub": []
},
{
"t": "Kill <k>Blackjaw</k> → <i>Flame Core</i>: <i>+10% fire resistance</i> <span class=\"lvl\">Lv 33</span>",
"sub": [
"1 Small Soul Core each: Stone Altar at the start, locked exit (follow the red line), Blackjaw's room at the side edge.",
"<i>Minimal:</i> 2 Small Soul Cores (altar + exit), Blackjaw optional.",
"Follow the main corridor, only leave it for cores (quest item sound) or Blackjaw.",
"Jump over the blockages in the corridor with Leap Slam, Pounce or Thunderous Leap."
]
},
{
"t": "Go to <z>Jiquani's Sanctum</z>",
"sub": []
},
{
"t": "Kill <k>Zicoatl</k> → <i>Large Soul Core</i> <span class=\"lvl\">Lv 33</span>",
"sub": [
"2 Medium Soul Cores into the 2 generators (V shape). Then Respawn at Checkpoint, go to the start, click the core: Zicoatl comes at once.",
"Search pattern: one side up to the checkpoint, checkpoint back to the start, then the other side.",
"Cores are usually toward the middle of the zone.",
"Triangle slam: stand at one of the triangle's corners.",
"Afterwards WP to the <i>Jungle Ruins</i>."
]
},
{
"t": "Go to <z>Jungle Ruins</z>",
"sub": []
},
{
"t": "<i>Large Soul Core</i> into the <i>Stone Altar</i> → opens the <i>Matlan Waterways</i>",
"sub": [
"The altar and the Waterways entrance are at the WP.",
"Since 0.5 the Waterways entrance is in the Jungle Ruins."
]
},
{
"t": "Go to <z>Matlan Waterways</z>",
"sub": []
},
{
"t": "Walk over the pressure pads, activate the <i>mechanism</i> at the end <span class=\"lvl\">Lv 34</span>",
"sub": [
"Grab the WP on the way. Afterwards checkpoint back to the WP: the <i>Azak Bog</i> entrance is there.",
"Click the <i>Ravaged Corpse</i> near the Azak Bog entrance, summon and talk to Servi: rare belt.",
"<i>Narag's Hut</i>: the rare drops a rare weapon.",
"Skipping the Azak Bog: portal to town after the mechanism.",
"Pressure pads instead of levers, the last section is already drained."
]
},
{
"t": "Go to <z>Azak Bog</z>",
"sub": []
},
{
"t": "(optional) Kill <k>Ignagduk</k> → <i>Gemrot Skull: +30 Spirit</i> + Uncut Spirit Gem level 10 <span class=\"lvl\">Lv 35</span>",
"sub": [
"First the <i>Flameskin Ritual</i>: light the 5 effigies, then the central one: +25% fire resistance for the zone. Afterwards the flames point to Ignagduk.",
"On entering, summon and talk to Servi: starts the quest.",
"Pick up the <i>Ghastly Spear</i>, trade it to Servi for a charm (Thawing or Staunching recommended).",
"Behind on level? Kill the mobs around the ritual, Respawn at Checkpoint, repeat: lots of magic and rare packs.",
"Afterwards portal to town."
]
},
{
"t": "Go to <z>Ziggurat Encampment</z>",
"sub": []
},
{
"t": "Talk to <i>Alva</i> at the bottom of the Ziggurat → <i>Drowned City</i>",
"sub": [
"Servi first: Ghastly Spear for a charm, hand in the venom if not done yet.",
"Buy the Colossal Life Flask if not done yet."
]
},
{
"t": "Go to <z>Trial of Chaos</z>",
"sub": []
},
{
"t": "(optional) <i>Trial of Chaos</i> with the Chimeral Inscribed Ultimatum: ascendancy",
"sub": [
"WP to the <i>Temple of Chaos</i>. Depends on your build, can also be done after the campaign.",
"The Ultimatum has 4 trials. The Chaos Statue in Utzaal gives another Inscribed Ultimatum.",
"Can be left at any time and resumed in the same room. Reward chest after every room."
]
},
{
"t": "Go to <z>Drowned City</z>",
"sub": []
},
{
"t": "Run through to the <i>Apex of Filth</i> <span class=\"lvl\">Lv 36</span>",
"sub": [
"Grab the WP at the start, you need it for the way back.",
"<i>Level 36 = gems to level 10.</i>",
"Avoid the teal water orb: stay in it too long and you drown.",
"Planning the Molten Vault? Pop in on the way, grab the WP, back out."
]
},
{
"t": "Go to <z>Apex of Filth</z>",
"sub": []
},
{
"t": "Kill the <k>Queen of Filth</k> → <i>Temple Door Idol</i> <span class=\"lvl\">Lv 36-37</span>",
"sub": [
"She is in the middle of the zone. Ignore mushrooms and the Cauldron Keeper. Roll slam: dodge roll as she lands.",
"Way back: checkpoint to the WP, WP to the <i>Drowned City</i>, exit to town: you arrive right at the <i>Temple of Kopec</i> door.",
"Talk to <i>Alva</i> in town: opens the Temple of Kopec."
]
},
{
"t": "Go to <z>Molten Vault</z>",
"sub": []
},
{
"t": "(optional) Kill <i>Mektul</i> → Hammer of Kamasa to <i>Oswald</i>: <i>Reforging Bench</i> <span class=\"lvl\">Lv 37</span>",
"sub": [
"WP to the Molten Vault. Follow the molten gold, at the end the Sluice Gate Lever, lift down. Under 4 minutes, then the gold floods the arena.",
"Only on the league's first character, skip on further characters.",
"Oswald also gives an Uncut Skill Gem level 10, an Artificer's Orb and 1,000 gold."
]
},
{
"t": "Go to <z>Temple of Kopec</z>",
"sub": []
},
{
"t": "Run all the way up, kill <k>Ketzuli</k> <span class=\"lvl\">Lv 37</span>",
"sub": [
"Each floor is a triangle: check the far corner first (~50% of the time). Floor 2: follow the ground crack from the sun to the wall, jump across.",
"Then summon and talk to Alva. As soon as she says 'wait' or 'offering': portal to town, skips the rest of the scene.",
"Standing in the sunlight stacks a burning debuff: stay in the shade."
]
},
{
"t": "Go to <z>Ziggurat Encampment</z>",
"sub": []
},
{
"t": "Through the <i>Gateway</i>, down the stairs to <i>Utzaal</i>",
"sub": [
"The Gateway only appears after Alva's scene: use the wait for vendors.",
"Bring cold resistance or a Sapphire Charm: the Eye of Winter casters in Utzaal are dangerous."
]
},
{
"t": "Go to <z>Utzaal</z>",
"sub": []
},
{
"t": "Kill <k>Viper Napuatzi</k> <span class=\"lvl\">Lv 38</span>",
"sub": [
"Follow the war cry sound to her. Spear phase: dodge roll every thrust.",
"Kill every <i>Vaal Goliath</i>: only they drop the <i>Sacrificial Heart</i>.",
"After the fight kill the remaining shield guards, then on to <i>Aggorat</i>.",
"When the soldiers shrink the arena, flask charges are refilled."
]
},
{
"t": "Go to <z>Aggorat</z>",
"sub": []
},
{
"t": "Sacrifice the <i>Sacrificial Heart</i> at the blood sacrifice altar → <i>+2 passive points</i> (+2 weapon set points) <span class=\"lvl\">Lv 39</span>",
"sub": [
"Altar at the edge in the second half of the zone: place the heart, take the Sacrificial Dagger, stab.",
"<i>Minimal:</i> Just pass through, the heart is optional.",
"No heart yet? Kill Goliaths in the second half of the zone until it drops.",
"After the points Respawn at Checkpoint, then to the <i>Black Chambers</i> entrance at the zone edge."
]
},
{
"t": "Go to <z>Black Chambers</z>",
"sub": []
},
{
"t": "Kill <k>Doryani</k> <span class=\"lvl\">Lv 40</span>",
"sub": [
"Zone = mazes connected by bridges. Get Doryani below 50% before the laser altar: saves 15-20 s.",
"Mech phase below 50%: the giant fist follows you and slams, get out in time.",
"Afterwards portal to town."
]
},
{
"t": "Go to <z>Ziggurat Encampment</z>",
"sub": []
},
{
"t": "Talk to <i>Doryani</i>, then travel with <i>Alva</i> to <i>Kingsmarch</i>",
"sub": [
"Doryani triggers the Cataclysm. After waking up: Doryani, Hooded One, Alva last."
]
}
]
},
{
"tip": "",
"title": "Act 4: The Islands (Level 41 → 50)",
"short": "Act 4",
"steps": [
{
"t": "Go to <z>Kingsmarch</z>",
"sub": []
},
{
"t": "Talk to <i>Doryani</i> and <i>Alva</i>, then <i>Makoru</i> at the ship → Isle of Kin <span class=\"lvl\">Lv 41</span>",
"sub": [
"Ctrl+click on Makoru opens the sea map directly.",
"<i>3 weapon pieces</i> needed. The island boss holding Matiki does not count: Matiki sits with a different one of the 4 bosses each league.",
"<i>This patch Diamora holds Matiki:</i> required are <i>Krutog, Prisoner, Scourge of the Skies</i>. Whakapanu/Singing Caverns only for the buffs.",
"Ignore the Torn Map Pieces (Plunder's Point)."
]
},
{
"t": "Go to <z>Isle of Kin</z>",
"sub": []
},
{
"t": "Go through to the <i>Volcanic Warrens</i>",
"sub": [
"Optional: <i>Beast Pen</i> (checkpoint) → Uncut Support Gem level 4.",
"Optional: <i>Blind Beast</i> → Blank Greater Rune, trade it with <i>Dannig</i> in Kingsmarch for a Greater Rune of your choice. Only if you still have a free rune socket.",
"Optional: <i>Fossilised Formation</i> along the outer walls = Lesser Jeweller's Orb."
]
},
{
"t": "Go to <z>Volcanic Warrens</z>",
"sub": []
},
{
"t": "Kill <k>Krutog</k> → weapon piece 1/3",
"sub": [
"Follow the lava river upstream. On his slam, roll through between his legs.",
"Wait until the <i>Hooded One</i> has picked up the weapon piece, only then leave: otherwise you have to come back.",
"<i>Nest</i> (checkpoint): kill the Magma Golems, the one killed last decides the ring: fire → Ruby, lightning → Topaz. Strong ring for this stage.",
"<i>Minimal:</i> skip the Nest."
]
},
{
"t": "Go to <z>Kedge Bay</z>",
"sub": []
},
{
"t": "(optional) Go through to <i>Journey's End</i>",
"sub": [
"Only for the +2 passive points from Journey's End."
]
},
{
"t": "Go to <z>Journey's End</z>",
"sub": []
},
{
"t": "(optional) Kill <k>Omniphobia</k> → <i>+2 passive points</i> (+2 weapon set points)",
"sub": [
"Take the waypoint, summon and talk to Tujen, kill <i>Captain Hartlin</i>, pick up the Verisium Ingots.",
"Portal to Kingsmarch: <i>Dannig</i> turns them into the Verisium Spikes.",
"Back: use the spikes on the totems (free Freya Hartlin), kill Omniphobia.",
"Talk to <i>Tujen</i> in Kingsmarch: Mist-shrouded Tome (right-click) + Uncut Skill Gem.",
"Omniphobia is cold-resistant and tanky. If your build is too weak: move on after Hartlin and come back via waypoint before Arastas."
]
},
{
"t": "Go to <z>Abandoned Prison</z>",
"sub": []
},
{
"t": "Go through to <i>Solitary Confinement</i> <span class=\"lvl\">Lv 43</span>",
"sub": [
"The <i>chapel key</i> drops from Spined Necromancers. In the chapel click the <i>Goddess of Justice</i> → 30% life flask recovery (or mana).",
"Loot the <i>Armoury</i> (checkpoint): chance for big weapon upgrades.",
"<i>Minimal:</i> skip the chapel and the Armoury."
]
},
{
"t": "Go to <z>Solitary Confinement</z>",
"sub": []
},
{
"t": "Kill <k>The Prisoner</k> → weapon piece 2/3",
"sub": [
"Follow the outer wall on the sea side, it leads straight to the boss.",
"Wait until the <i>Hooded One</i> has picked up the weapon piece, only then leave: otherwise you have to come back.",
"At 50% and 25% life use a <i>ballista</i>.",
"Monsters in the water have ~80% damage reduction: run past them.",
"With Leap/Pounce: jump through the barred walls instead of going around."
]
},
{
"t": "Go to <z>Shrike Island</z>",
"sub": []
},
{
"t": "Kill <k>Scourge of the Skies</k> → weapon piece 3/3",
"sub": [
"Run to the end of the zone.",
"Wait until the <i>Hooded One</i> has picked up the weapon piece, only then leave: otherwise you have to come back."
]
},
{
"t": "Go to <z>Whakapanu Island</z>",
"sub": []
},
{
"t": "(optional) Kill the <k>Great White One</k> → <i>Shark Fin</i>",
"sub": [
"Shark arena at the edge of the zone (checkpoint), then on to Singing Caverns.",
"This patch Diamora holds Matiki: both zones are optional for that reason.",
"Speedrunners skip the shark arena: the buff is barely worth the time.",
"Keep the fin: <i>Kaimana</i> gives the permanent defensive buff at the end of the act in Kingsmarch.",
"Optional: <i>Crabshell Cavern</i> (checkpoint) → Uncut Support Gem."
]
},
{
"t": "Go to <z>Singing Caverns</z>",
"sub": []
},
{
"t": "(optional) Kill <k>Diamora</k> → free <i>Matiki</i>",
"sub": [
"Follow the singing voice. Put on cold resistance.",
"This patch Diamora holds Matiki: both zones are optional for that reason.",
"Talk to Matiki, back to the ship, talk to Matiki again → sail to the <i>Eye of Hinekora</i>.",
"Open the <i>Beckoning Clam</i> (checkpoint) → Humming Pearl for Rog (amulet with all resistances).",
"When she sings, do not look into the water mirrors at the arena edge: otherwise petrification stacks."
]
},
{
"t": "Go to <z>Eye of Hinekora</z>",
"sub": []
},
{
"t": "(optional) <i>Silent Hall</i> → <i>+5% max. mana</i> <span class=\"lvl\">Lv 45</span>",
"sub": [
"Talk to Matiki, peer into the Well of Passing, complete the 3 Tests of Mettle (Kaom, Maata, Rakiata). Silent Hall is behind a checkpoint.",
"Click Silent Hall, <i>Respawn at Checkpoint as soon as +5% mana appears in chat</i>: skips the animation (pausing must be disabled).",
"Chest behind the waterfall (between test 2 and 3): guaranteed Spirit Gem."
]
},
{
"t": "Go to <z>Halls of the Dead</z>",
"sub": []
},
{
"t": "(optional) Complete 3 tests → <i>3 tattoos</i>",
"sub": [
"Trade each Blank Tattoo at the totem: +5% resistance (recommended) or +5 attribute. One-time choice.",
"Kill <i>Yama the White</i>, pick up the Silver Coin, then through the portal to Trial of the Ancestors."
]
},
{
"t": "Go to <z>Trial of the Ancestors</z>",
"sub": []
},
{
"t": "(optional) Talk to <i>Navali</i> → <i>+2 passive points</i> (+2 weapon set points)",
"sub": [
"Use the Tattoo of Hinekora with right-click."
]
},
{
"t": "Go to <z>Kingsmarch</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i>, then <i>Makoru</i> → Arastas",
"sub": [
"Only works with all 3 weapon pieces.",
"Hand the Humming Pearl to <i>Rog</i> → Pearlescent Amulet (all resistances).",
"Journey's End still open? Do Omniphobia now via waypoint, then talk to Tujen."
]
},
{
"t": "Go to <z>Arastas</z>",
"sub": []
},
{
"t": "Kill <k>Torvian</k> <span class=\"lvl\">Lv 46-47</span>",
"sub": [
"Follow Lorandis, destroy the forcefield, survive the ambush. Priests: the right one gives Torvian damage reduction, the left one elemental immunity. Kill Torvian before they buff him.",
"<i>After the bubble, kill the whole pack outside:</i> only then does the quest advance. Otherwise every death or checkpoint reset sends you back before the cutscene (~1 min).",
"Bell on the cliff side = <i>3 Exalted Orbs</i>, bell opposite = 3 Regal Orbs.",
"<i>Minimal:</i> skip the bells."
]
},
{
"t": "Go to <z>The Excavation</z>",
"sub": []
},
{
"t": "Kill <k>Benedictus</k>",
"sub": [
"Put on lightning resistance. In the labyrinth get to the safe side in time.",
"Enter the arena, then Respawn at Checkpoint right away: skips Benedictus' long dialogue.",
"At 50% he becomes immune (stones on both sides): save your burst for after.",
"Guaranteed shrine in the zone: take it (XP shrine = double XP).",
"Enter the Excavated Site: as soon as the quest shows <i>Speak to the Hooded One</i>, Esc → Respawn at Checkpoint (skips the cutscene).",
"Talk to the Hooded One, portal to Kingsmarch."
]
},
{
"t": "Go to <z>Kingsmarch</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i>, then <i>Rhodri</i> at the ship → Ngakanu",
"sub": [
"Makoru is wounded: from here on Rhodri sails.",
"Put on your tankiest gear: Ngakanu and Heart of the Tribe have many projectiles and the biggest level deficit."
]
},
{
"t": "Go to <z>Ngakanu -> Heart of the Tribe</z>",
"sub": []
},
{
"t": "Kill <k>Tavakai</k> <span class=\"lvl\">Lv 48</span>",
"sub": [
"Heart of the Tribe: after the 1st checkpoint go between the two buildings, then keep going deeper into the zone. Further checkpoints mark side objectives: turn back.",
"3 phases, if you die the fight restarts.",
"Phase 2: stand in a corner, roll out and back in when the spikes come from the air. Same in phase 3, plus stun him.",
"Afterwards: the Hooded One cures Tavakai and Makoru, talk to Tavakai, portal to Kingsmarch."
]
},
{
"t": "Go to <z>Kingsmarch</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i> → Interludes unlocked",
"sub": [
"<i>Kaimana</i> (platform at the end of the dock, opposite the ship): hand in the Shark Fin → <i>Kaom's Lesson</i> (30% increased Armour/Evasion/ES) or Rakiata's Lesson. Permanent.",
"Collected Tujen's reward (Journey's End)? Otherwise now."
]
}
]
},
{
"tip": "",
"title": "Interludes 1-3 (level ~50 → 56-60)",
"short": "Interludes",
"steps": [
{
"t": "Go to <z>The Khari Bazaar</z>",
"sub": []
},
{
"t": "Talk to <i>Asala</i> and <i>Zarka</i>, take the north-east exit <span class=\"lvl\">Lv ~50</span>",
"sub": [
"Interlude 2, part 1. Getting here: Hooded One in Kingsmarch → Vastiri."
]
},
{
"t": "Go to <z>Skullmaw Stairway</z>",
"sub": []
},
{
"t": "(optional) Take <i>Molten One's Gift</i> → <i>+5% max. life</i>",
"sub": [
"Khari Crossing: go north, left along the wall to the Molten Shrine, down into the Stairway, clear the monsters.",
"Afterwards <i>Respawn at Checkpoint</i>: takes you back to the Khari Crossing."
]
},
{
"t": "Go to <z>The Galai Gates</z>",
"sub": []
},
{
"t": "Just grab the <i>waypoint</i>, go back to the Khari Crossing",
"sub": [
"In the Khari Crossing, follow the west wall.",
"Kill <i>Vornas</i> later (after Elzarah)."
]
},
{
"t": "Go to <z>The Khari Crossing</z>",
"sub": []
},
{
"t": "(optional) Kill <k>Akthi & Anundr</k> → Risu: <i>+2 passive points (+2 weapon set points)</i>",
"sub": [
"Checkpoint to the town entrance, from there east to the arena. Then portal to the Bazaar, get the book from <i>Risu</i>.",
"<i>Torbik</i> (vendor in a wagon with a checkpoint, north-east of the zone): kill his attackers first. Sells caster weapons, sceptres and jewellery."
]
},
{
"t": "Go to <z>Pools of Khatal</z>",
"sub": []
},
{
"t": "Activate the <i>waypoint</i>, WP back to the Khari Bazaar",
"sub": [
"Bazaar: south-west exit, then west through the Khari Crossing.",
"In the Bazaar: <i>Hooded One -> Mount Kriar</i> (Interlude 3).",
"The quest step Tower of Ab Binayi / Wayfinder only shows the way: run straight west."
]
},
{
"t": "Go to <z>The Glade -> Ashen Forest</z>",
"sub": []
},
{
"t": "Through the <i>Ashen Forest</i> to <i>Kriar Village</i> <span class=\"lvl\">Lv ~51</span>",
"sub": [
"Interlude 3. Ashen Forest has no waypoint.",
"Optional: <i>Ancient Monument</i> (checkpoint) = level 14 Uncut Skill Gem."
]
},
{
"t": "Go to <z>Kriar Village</z>",
"sub": []
},
{
"t": "Kill <k>Lythara</k> → <i>+40 Spirit</i>",
"sub": [
"Stun her at half HP and finish her in the stun window. Wisps empower her over time: burst her.",
"Right-click the <i>Gemcrust Skull</i>: +40 Spirit + level 14 Uncut Spirit Gem."
]
},
{
"t": "Go to <z>Glacial Tarn -> Howling Caves</z>",
"sub": []
},
{
"t": "(optional) Kill the <k>Abominable Yeti</k> → Hilda: <i>+2 passive points (+2 weapon set points)</i>",
"sub": [
"Glacial Tarn: follow the east (right) wall to the Howling Caves.",
"Pick up the <i>Icy Tusks</i>, portal to The Glade, hand them to <i>Hilda</i>, WP back to the Glacial Tarn."
]
},
{
"t": "Go to <z>Glacial Tarn</z>",
"sub": []
},
{
"t": "Kill <k>Rakkar</k> → Kriar Peaks",
"sub": [
"Follow the north-west wall: Rakkar guards the entrance to the Kriar Peaks."
]
},
{
"t": "Go to <z>Kriar Peaks</z>",
"sub": []
},
{
"t": "Talk to <i>Elder Madox</i> → <i>1 Unique of your choice</i>",
"sub": [
"Side path at the zone edge, marked by owls. At the end take the platform down into the Etched Ravine.",
"<i>Minimal:</i> Just run through, Elder Madox is optional."
]
},
{
"t": "Go to <z>Etched Ravine</z>",
"sub": []
},
{
"t": "Kill <k>Stormgore</k> → Cuachic Vault",
"sub": [
"Guards the entrance to the Vault. Roll through his slams."
]
},
{
"t": "Go to <z>The Cuachic Vault</z>",
"sub": []
},
{
"t": "Kill <k>Zolin & Zelina</k>, then <i>summon and talk to Doryani</i>",
"sub": [
"<i>Zelina first</i>: her claw causes heavy bleed, wear a Staunching Charm.",
"Without talking to Doryani the Interlude is not completed.",
"Then WP straight to the <i>Pools of Khatal</i>: waypoints work across Interludes."
]
},
{
"t": "Go to <z>Sel Khari Sanctuary</z>",
"sub": []
},
{
"t": "Kill <k>Elzarah</k>, then talk to <i>Asala</i> <span class=\"lvl\">Lv ~54</span>",
"sub": [
"Interlude 2, part 2. From the Pools of Khatal on into the Sanctuary.",
"Optional: put <i>Yoon's</i> and <i>Rangeen's Barya</i> (found on the way) into the two pedestals at the edge → 2 wishes: rare ring, amulet or jewel.",
"If Elzarah drops a <i>level 60 Barya</i>: keep it for the 3rd ascendancy.",
"<i>Minimal:</i> Elzarah and Asala are required, the Baryas optional."
]
},
{
"t": "Go to <z>The Galai Gates</z>",
"sub": []
},
{
"t": "Kill <k>Vornas</k> → Qimah",
"sub": [
"Portal to the Bazaar, WP to the Galai Gates. Vornas: physical + lightning.",
"After Interlude 3 the zones here are level 60: resistance penalty -50%. Check your resistances."
]
},
{
"t": "Go to <z>Qimah</z>",
"sub": []
},
{
"t": "Pick a <i>boon</i> at the Seven Pillars, summon <i>Jado</i>",
"sub": [
"Pillars: side room with a checkpoint, at the north edge or south-east of the arena entrance. Jado at the ceremony site, he opens the Qimah Reservoir.",
"<i>Tabana's</i>: +5% all elemental resistances. <i>Orbala's</i>: 3% movement speed. Others: Kochai's +5 attributes, Halani's 12% cooldown recovery, Ahkeli's 15% defences, Galai's 20% presence. Can be changed any time.",
"<i>Alima's</i> (+5% XP) inverts all six other boons: do not take it.",
"<i>Minimal:</i> Jado is required, the boon optional."
]
},
{
"t": "Go to <z>Qimah Reservoir</z>",
"sub": []
},
{
"t": "Kill <k>Azmadi</k>, use the <i>Grand Barya</i>, talk to <i>Jado</i>",
"sub": [
"Long combos: roll through them and only deal damage in the window, or burst him down.",
"Optional: 2 <i>Vials of Sacred Water</i> (monster drops) into the Sacred Wells → 1 random currency each.",
"Then portal to the Bazaar: <i>Hooded One -> Ogham</i> (Interlude 1)."
]
},
{
"t": "Go to <z>The Refuge -> Scorched Farmlands</z>",
"sub": []
},
{
"t": "Kill <k>Isolde & Heldra</k> → Stones of Serle <span class=\"lvl\">Lv ~57</span>",
"sub": [
"Interlude 1. First grab the checkpoint at the wall of darkness, then find the two. Isolde: cold, Heldra: fire.",
"Zones here are now level 62-64: resistance penalty -50%. Top up resistances beforehand.",
"Optional: Uncut Skill Gem on a corpse by the road (checkpoint)."
]
},
{
"t": "Go to <z>Stones of Serle</z>",
"sub": []
},
{
"t": "Activate the <i>6 megaliths</i>, then kill <k>Siora</k>",
"sub": [
"The megaliths stand at the zone edge, Siora in the stone circle in the middle. When she darkens the arena: run to the glowing megalith.",
"Siora is very mobile: stun her.",
"Afterwards wait for <i>Una</i> and talk to her. Only go back once the quest shows 'Return to the Darkness'."
]
},
{
"t": "Go to <z>The Blackwood -> Holten</z>",
"sub": []
},
{
"t": "Checkpoint to the darkness, through <i>The Blackwood</i> to <i>Holten</i>",
"sub": [
"Skip the omen altars in the Blackwood."
]
},
{
"t": "Go to <z>Holten</z>",
"sub": []
},
{
"t": "(optional) Buy Greater Runes from the <i>Soul of the Ferryman</i>",
"sub": [
"Along the north-east edge to the bridge, cross it, then head south-west. About 2000 gold per rune.",
"Runes for resistances and your next weapon. Skip <i>Sigbert & Godwin</i> (Psalm of Blood)."
]
},
{
"t": "Go to <z>Wolvenhold</z>",
"sub": []
},
{
"t": "(optional) Kill <k>Oswin</k> → <i>Warden's Ledger</i>: +2 passive points (+2 weapon set points)",
"sub": [
"Holten: along the north-east edge to Wolvenhold. Oswin is at the north-east or north-west end of the zone.",
"Then checkpoint back to Holten."
]
},
{
"t": "Go to <z>Holten Estate</z>",
"sub": []
},
{
"t": "Kill <k>Thane Wulfric & Lady Elswyth</k>",
"sub": [
"Holten: along the north edge to the Estate. Loop left to the stairs, same pattern upstairs to the arena.",
"<i>Lady Elswyth first</i>."
]
},
{
"t": "Go to <z>The Refuge</z>",
"sub": []
},
{
"t": "Talk to <i>Renly</i>, WP to Kingsmarch",
"sub": [
"Portal out of the Holten Estate."
]
},
{
"t": "Go to <z>Kingsmarch</z>",
"sub": []
},
{
"t": "<i>Hooded One</i>: get the Book of Specialisation → <i>+2 passive points (+2 weapon set points)</i>",
"sub": [
"Use the book right away, then <i>Travel to Oriath</i> at the Hooded One."
]
},
{
"t": "Go to <z>The Ziggurat Refuge</z>",
"sub": []
},
{
"t": "Talk to the <i>Hooded One</i> and <i>Doryani</i>, use the <i>Map Device</i>",
"sub": [
"The trip to Oriath ends here. Campaign done, continue in the Maps tab."
]
}
]
},
{
"tip": "",
"title": "Bonus: from the campaign into maps",
"short": "Maps",
"steps": [
{
"t": "Take the waystone from <i>Doryani</i>, reforge it up at the <i>Reforging Bench</i>",
"sub": [
"3 waystones of the same tier → 1 of the next tier. Doryani sells up to 10 waystones: tier 1 or one tier below your highest completed.",
"With 2 waystones of one tier: buy 3 of the tier below, reforge them into a third, then reforge all three one tier up.",
"Save gold for waystones: sell rares to the vendor instead of leaving them.",
"The vendors here sell level 65 items: look for a new weapon base."
]
},
{
"t": "Go to <z>Atlas</z>",
"sub": []
},
{
"t": "Head for <i>Powerful Map Bosses</i>: the boss drops a waystone one tier higher",
"sub": [
"Always put your highest waystone into a Powerful Boss map and run straight to the boss.",
"Make waystones magic (Transmute + Augment), Powerful Boss maps rare: higher chance of waystone drops.",
"<i>Hilda's Campsite</i> (close to the start): kill the first Great Beast, put the point into <i>Mighty Prey</i> (25% chance for map bosses to become Powerful)."
]
},
{
"t": "First goal: the <i>Fortress quest line</i> for Atlas points",
"sub": [
"Tower → Ancient Gateway → Burning Monolith. Eastern/Western Gateway need T5+, Eastern/Western Enigma T10+.",
"Maps marked <i>+</i> on the Atlas give an Atlas point: take them on the way.",
"League mechanics only from ~100 Atlas points or T15. Before that just boss rush, take Essences and Shrines."
]
},
{
"t": "Stay at most <i>6-8 levels</i> below the map level",
"sub": [
"If you fall further behind: run one map without a tier increase in between. From level 65 the XP penalty barely matters."
]
},
{
"t": "<i>Cap fire and lightning resistance</i>, leave cold open if you must",
"sub": [
"With 40% on all three every element kills you. Two capped = safe against two elements."
]
},
{
"t": "Go to <z>Trial of the Sekhemas / Trial of Chaos</z>",
"sub": []
},
{
"t": "<i>Catch up on ascendancy</i>: 2nd trial with the Chimeral Inscribed Ultimatum (Act 3), 3rd with a level 60 Barya",
"sub": [
"Run the 3rd trial at ~level 70: slightly overlevelled it goes fast.",
"Left and right of the middle path at the Burning Monolith are maps with a guaranteed trial key (Barya or Ultimatum).",
"Relics with honour resistance make the Sekhemas trial much easier."
]
}
]
}
];
window.PASSIVE_QUESTS_POE2 = [[1, "The Trail of Corruption", "Hunting Grounds – The Crowbell töten → +2 Passive-Punkte", 2], [1, "The Lost Lute", "Clearfell Encampment – Una: Laute abgeben → +2 Passive-Punkte", 2], [2, "The City of Seven Waters", "Keth – Kabala, Constrictor Queen töten → +2 Passive-Punkte (+2 Waffens", 2], [2, "Tradition's Toll", "The Ardura Caravan – Wüstenkarte The Dreadnought wählen, während der F", 2], [3, "Legacy of the Vaal", "Aggorat – Sacrificial Heart am Blutopfer-Altar opfern → +2 Passive-Pun", 2], [4, "Dark Mists", "Journey's End – Omniphobia töten → +2 Passive-Punkte (+2 Waffenset-Pun", 2], [4, "Trial of the Ancestors", "Trial of the Ancestors – Navali ansprechen → +2 Passive-Punkte (+2 Waf", 2], [5, "Clearing the Way", "The Khari Crossing – Akthi & Anundr töten → Risu: +2 Passive-Punkte (+", 2], [5, "Howling Winds", "Glacial Tarn -> Howling Caves – Abominable Yeti töten → Hilda: +2 Pass", 2], [5, "Kill Oswin -> Warden's Ledger: +2 passiv", "Wolvenhold – Oswin töten → Warden's Ledger: +2 Passive-Punkte (+2 Waff", 2], [5, "Siege of Oriath", "Kingsmarch – Hooded One: Book of Specialisation holen → +2 Passive-Pun", 2]];
// Je nach Spiel des aktiven Profils die passende Route verwenden
(function () { try { if (localStorage.getItem('spiel') === 'poe2') { window.SPIEL = 'poe2'; window.CAMPAIGN = window.CAMPAIGN_POE2; window.CAMPAIGN_EN = window.CAMPAIGN_POE2_EN; window.PASSIVE_QUESTS = window.PASSIVE_QUESTS_POE2; } } catch (e) {} })();
