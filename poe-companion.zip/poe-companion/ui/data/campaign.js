// PoE 1 Kampagnen-Route (Akt 1–10)
// Route basiert auf exile-leveling von HeartofPhos (MIT-Lizenz), https://github.com/HeartofPhos/exile-leveling – übersetzt für den PoE Companion.
window.CAMPAIGN = [
{
"act": 1,
"title": "Akt 1",
"tip": "Gleich am Anfang Quecksilber-Flasche und Bewegungsskill besorgen – spart die ganze Kampagne über Zeit.",
"steps": [
{
"t": "Finde und töte <k>Hillock</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Hillock",
"npc": ""
},
{
"t": "Geh weiter nach <z>Lioneye's Watch</z>",
"sub": [],
"z": "Lioneye's Watch",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Enemy at the Gate</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Enemy at the Gate",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "Geh weiter nach <z>The Coast</z>",
"sub": [],
"z": "The Coast",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Mud Flats</z>",
"sub": [],
"z": "The Mud Flats",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde 3× <i>Glyph</i>",
"sub": [
"Kleine Bäche verbinden die 3 Rhoa-Nester",
"Meist ein Dreieck, selten eine Linie"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Submerged Passage</z>",
"sub": [],
"z": "The Submerged Passage",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Coast</z> reisen",
"sub": [],
"z": "The Coast",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Tidal Island</z>",
"sub": [],
"z": "The Tidal Island",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Hailrake</k>, nimm <i>Medicine Chest</i>",
"sub": [
"Richtung <d>←</d> <i>Westen</i>",
"Bei einer Kante umdrehen und <d>→</d> <i>Osten</i>",
"Empfohlenes Level: 4"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Hailrake",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Breaking Some Eggs</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Breaking Some Eggs",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "In der Stadt die Quest <q>Mercy Mission</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Mercy Mission",
"e": 0,
"kt": "",
"npc": "Nessa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Submerged Passage</z> reisen",
"sub": [],
"z": "The Submerged Passage",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Flooded Depths</z>",
"sub": [
"Rechts an der Brücke vorbei"
],
"z": "The Flooded Depths",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>The Dweller of the Deep</k>",
"sub": [
"Gegenüber vom Eingang suchen",
"Nach dem großen leeren Raum suchen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Dweller of the Deep",
"npc": ""
},
{
"t": "Nimm <i>Boat</i> ➜ <z>The Submerged Passage</z>",
"sub": [],
"z": "The Submerged Passage",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ledge</z>",
"sub": [],
"z": "The Ledge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Climb</z>",
"sub": [],
"z": "The Climb",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lower Prison</z>",
"sub": [],
"z": "The Lower Prison",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Lioneye's Watch</z> reisen",
"sub": [],
"z": "Lioneye's Watch",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Dweller of the Deep</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Dweller of the Deep",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "In der Stadt die Quest <q>The Caged Brute</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Caged Brute",
"e": 0,
"kt": "",
"npc": "Nessa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Lower Prison</z> reisen",
"sub": [],
"z": "The Lower Prison",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Meist <d>↗</d> <i>Nordosten</i>"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Upper Prison</z>",
"sub": [],
"z": "The Upper Prison",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde <i>Chemist's Strongbox</i>",
"sub": [
"Nach dem Karten-Symbol suchen, Schalter daneben",
"Hohe Chance auf <i>Quicksilver Flask</i>",
"Händler-Rezept: <i>Quicksilver Flask</i> + <i>Orb of Augmentation</i> + normale <i>Boots</i>",
"Händler-Rezept: <i>Quicksilver Flask</i> + <i>Orb of Augmentation</i> + Movement-Speed-<i>Boots</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Warden's Quarters</a>, töte <k>Brutus, Lord Incarcerator</k>",
"sub": [
"Empfohlenes Level: 8"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Brutus",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Caged Brute</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Caged Brute",
"e": 0,
"kt": "",
"npc": "Nessa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Prisoner's Gate</z> reisen",
"sub": [],
"z": "Prisoner's Gate",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ship Graveyard</z>",
"sub": [
"Neben dem Weg die Kante hinunter"
],
"z": "The Ship Graveyard",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Captain Fairgraves</k>, nimm <i>Allflame</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Captain Fairgraves",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Cavern of Wrath</z>",
"sub": [],
"z": "The Cavern of Wrath",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Lioneye's Watch</z> reisen",
"sub": [],
"z": "Lioneye's Watch",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Marooned Mariner</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Marooned Mariner",
"e": 0,
"kt": "",
"npc": "Bestel"
},
{
"t": "In der Stadt die Quest <q>The Siren's Cadence</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Siren's Cadence",
"e": 0,
"kt": "",
"npc": "Nessa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Cavern of Wrath</z> reisen",
"sub": [],
"z": "The Cavern of Wrath",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Cavern of Anger</z>",
"sub": [
"Dem Wasser folgen"
],
"z": "The Cavern of Anger",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Merveil's Lair</a>, töte <k>Merveil, the Siren</k>",
"sub": [
"Dem Wasser folgen",
"Empfohlenes Level: 12"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Merveil",
"npc": ""
}
]
},
{
"act": 2,
"title": "Akt 2",
"tip": "Banditen: Für fast alle Builds alle drei töten – gibt einen zusätzlichen Passivpunkt.",
"steps": [
{
"t": "Geh weiter nach <z>The Southern Forest</z>",
"sub": [],
"z": "The Southern Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Forest Encampment</z>",
"sub": [],
"z": "The Forest Encampment",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Old Fields</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Old Fields",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde <z>The Den</z>, platziere <l>Portal setzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crossroads</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Crossroads",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Forest Encampment</z> reisen",
"sub": [
"Dem Weg folgen"
],
"z": "The Forest Encampment",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Nimm <l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Den</z>",
"sub": [],
"z": "The Den",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>The Great White Beast</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Great White Beast",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Great White Beast</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Great White Beast",
"e": 0,
"kt": "",
"npc": "Yeena"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crossroads</z> reisen",
"sub": [],
"z": "The Crossroads",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Chamber of Sins Level 1</z>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Chamber of Sins Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Chamber of Sins Level 2</z>",
"sub": [
"Gleiche Richtung wie zum <w>Wegpunkt</w>"
],
"z": "The Chamber of Sins Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Fidelitas, the Mourning</k>, nimm <i>Baleful Gem</i>",
"sub": [
"Nach dem langen Flur suchen",
"Empfohlenes Level: 14-15"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Fidelitas",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Intruders in Black</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Intruders in Black",
"e": 0,
"kt": "",
"npc": "Greust"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crossroads</z> reisen",
"sub": [],
"z": "The Crossroads",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Fellshrine Ruins</z>",
"sub": [
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "The Fellshrine Ruins",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crypt Level 1</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Crypt Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crypt Level 2</z>",
"sub": [],
"z": "The Crypt Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde <i>Altar</i>, nimm <i>Golden Hand</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Through Sacred Ground</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Through Sacred Ground",
"e": 0,
"kt": "",
"npc": "Yeena"
},
{
"t": "Geh weiter nach <z>The Riverways</z>",
"sub": [
"Richtung <d>↙</d> <i>Südwesten</i>"
],
"z": "The Riverways",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Dem Weg folgen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Western Forest</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Western Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Dem Weg folgen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Weaver's Chambers</z>",
"sub": [
"Auf der Straßenseite gegenüber vom <w>Wegpunkt</w> suchen"
],
"z": "The Weaver's Chambers",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Weaver's Nest</a>, töte <k>The Weaver</k>, nimm <i>Maligaro's Spike</i>",
"sub": [
"<d>←</d> <i>Westen</i> versuchen, wenn versperrt <d>↗</d> <i>Nordosten</i>",
"Empfohlenes Level: 16"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "The Weaver",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Sharp and Cruel</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Sharp and Cruel",
"e": 0,
"kt": "",
"npc": "Silk"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crossroads</z> reisen",
"sub": [],
"z": "The Crossroads",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Broken Bridge</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Broken Bridge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Kraityn, Scarbearer</k>, nimm <i>Kraityn's Amulet</i>",
"sub": [
"Dem Weg folgen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Kraityn",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Riverways</z> reisen",
"sub": [],
"z": "The Riverways",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Wetlands</z>",
"sub": [
"Nach 2 Säulen beim <w>Wegpunkt</w> suchen, dem Pfad folgen"
],
"z": "The Wetlands",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Oak, Skullbreaker</k>, nimm <i>Oak's Amulet</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Oak",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Western Forest</z> reisen",
"sub": [
"Gegenüber vom Lager-Eingang suchen"
],
"z": "The Western Forest",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Alira Darktongue</k>, nimm <i>Alira's Amulet</i>",
"sub": [
"<d>↓</d> <i>Süden</i>, nach der Fackel am Weg suchen",
"Dem Pfad in Richtung der Fackel folgen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Alira Darktongue",
"npc": ""
},
{
"t": "Töte <k>Captain Arteri</k>",
"sub": [
"Dem Weg <d>↙</d> <i>Südwesten</i> folgen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Captain Arteri",
"npc": ""
},
{
"t": "Nimm <i>Thaumetic Emblem</i>, aktiviere <i>Thaumetic Seal</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Deal with the Bandits</q> abgeben, nimm <i>The Apex</i>",
"sub": [],
"z": "",
"k": "pp",
"q": "Deal with the Bandits",
"e": 0,
"kt": "",
"npc": "Eramir"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Lioneye's Watch</z> reisen",
"sub": [],
"z": "Lioneye's Watch",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Way Forward</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Way Forward",
"e": 0,
"kt": "",
"npc": "Bestel"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Wetlands</z> reisen",
"sub": [],
"z": "The Wetlands",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Vergifte <i>Tree Roots</i> ➜ <z>The Vaal Ruins</z>",
"sub": [],
"z": "The Vaal Ruins",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Northern Forest</z>",
"sub": [
"S- oder L-Form führt zum Ausgang"
],
"z": "The Northern Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Caverns</z>",
"sub": [],
"z": "The Caverns",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ancient Pyramid</z>",
"sub": [],
"z": "The Ancient Pyramid",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Pyramid Apex</a>, töte <k>Vaal Oversoul</k>",
"sub": [
"Ausgang im ersten Stock: in einer der 3 Ecken",
"Weitere Stockwerke: Ausgang diagonal gegenüber vom Eingang",
"Empfohlenes Level: 20-22"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Vaal Oversoul",
"npc": ""
}
]
},
{
"act": 3,
"title": "Akt 3",
"tip": "Drei Aufstiegsprüfungen in Akt 3 – danach kannst du das erste Labyrinth machen.",
"steps": [
{
"t": "Geh weiter nach <z>The City of Sarn</z>",
"sub": [],
"z": "The City of Sarn",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Hilf und sprich mit <i>Clarissa</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Sarn Encampment</z>",
"sub": [],
"z": "The Sarn Encampment",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Slums</z>",
"sub": [
"Richtung <d>↑</d> <i>Norden</i>"
],
"z": "The Slums",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crematorium</z>",
"sub": [
"Den Treppen folgen"
],
"z": "The Crematorium",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Piety</k>, nimm <i>Tolman's Bracelet</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Piety",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Clarissa</i>, nimm <i>Sewer Keys</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Lost in Love</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Lost in Love",
"e": 0,
"kt": "",
"npc": "Maramoa"
},
{
"t": "Geh weiter nach <z>The Slums</z>",
"sub": [
"Richtung <d>↑</d> <i>Norden</i>"
],
"z": "The Slums",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Sewers</z>",
"sub": [],
"z": "The Sewers",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde 1× <i>Platinum Bust</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde 2× <i>Platinum Bust</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Marketplace</z>",
"sub": [],
"z": "The Marketplace",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Catacombs</z>",
"sub": [
"In der Nähe umsehen"
],
"z": "The Catacombs",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Victario's Secrets</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Victario's Secrets",
"e": 0,
"kt": "",
"npc": "Hargan"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Marketplace</z> reisen",
"sub": [],
"z": "The Marketplace",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Battlefront</z>",
"sub": [
"<d>↑</d> <i>Norden</i> suchen"
],
"z": "The Battlefront",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Ribbon Spool</i>",
"sub": [
"Richtung <d>↙</d> <i>Südwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Solaris Temple Level 1</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Solaris Temple Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Solaris Temple Level 2</z>",
"sub": [],
"z": "The Solaris Temple Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Eternal Laboratory</a>, hole <i>Crafting-Rezept</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Battlefront</z> reisen",
"sub": [],
"z": "The Battlefront",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Docks</z>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Docks",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Thaumetic Sulphite</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Solaris Temple Level 2</z> reisen",
"sub": [],
"z": "The Solaris Temple Level 2",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Lady Dialla</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Ribbon Spool</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Ribbon Spool",
"e": 0,
"kt": "",
"npc": "Lady Dialla"
},
{
"t": "In der Stadt die Quest <q>Fiery Dust</q> abgeben, nimm <i>Infernal Talc</i>",
"sub": [],
"z": "",
"k": "main",
"q": "Fiery Dust",
"e": 0,
"kt": "",
"npc": "Lady Dialla"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Sewers</z> reisen",
"sub": [],
"z": "The Sewers",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Verbrenne <i>Undying Blockage</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ebony Barracks</z>",
"sub": [],
"z": "The Ebony Barracks",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>General Gravicius</k>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "General Gravicius",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lunaris Temple Level 1</z>",
"sub": [],
"z": "The Lunaris Temple Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lunaris Temple Level 2</z>",
"sub": [],
"z": "The Lunaris Temple Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Piety</k>, nimm <i>Tower Key</i>",
"sub": [
"Treppen nach oben folgen",
"An der Weggabelung mit Wagen: den Weg mit 1 Wagen nehmen, nicht 2"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Piety",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Piety's Pets</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Piety's Pets",
"e": 0,
"kt": "",
"npc": "Grigor"
},
{
"t": "In der Stadt die Quest <q>Sever the Right Hand</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Sever the Right Hand",
"e": 0,
"kt": "",
"npc": "Maramoa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Ebony Barracks</z> reisen",
"sub": [],
"z": "The Ebony Barracks",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Imperial Gardens</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Imperial Gardens",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Dem Weg folgen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Richtung <d>↑</d> <i>Norden</i>"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Imperial Gardens</z> reisen",
"sub": [],
"z": "The Imperial Gardens",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Sceptre of God</z>",
"sub": [],
"z": "The Sceptre of God",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Upper Sceptre of God</z>",
"sub": [
"Treppen sind in einer der Ecken"
],
"z": "The Upper Sceptre of God",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Tower Rooftop</a>, Töte <k>Dominus, High Templar</k>",
"sub": [
"Nach Barrikaden suchen"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Dominus",
"npc": ""
}
]
},
{
"act": 4,
"title": "Akt 4",
"tip": "Ab hier werden Resistenzen wichtig. Nach Akt 5 fallen sie um 30 %.",
"steps": [
{
"t": "Geh weiter nach <z>The Aqueduct</z>",
"sub": [],
"z": "The Aqueduct",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Highgate</z>",
"sub": [],
"z": "Highgate",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Dried Lake</z>",
"sub": [],
"z": "The Dried Lake",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Voll, Emperor of Purity</k>, nimm <i>Deshret's Banner</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Voll",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Zerstöre <i>Deshret's Seal</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Breaking the Seal</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Breaking the Seal",
"e": 0,
"kt": "",
"npc": "Oyun"
},
{
"t": "Geh weiter nach <z>The Mines Level 1</z>",
"sub": [],
"z": "The Mines Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Mines Level 2</z>",
"sub": [],
"z": "The Mines Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Befreie <i>Deshret</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crystal Veins</z>",
"sub": [],
"z": "The Crystal Veins",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Highgate</z> reisen",
"sub": [],
"z": "Highgate",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>An Indomitable Spirit</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "An Indomitable Spirit",
"e": 0,
"kt": "",
"npc": "Tasuni"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Sarn Encampment</z> reisen",
"sub": [],
"z": "The Sarn Encampment",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <z>Aspirants' Plaza</z>, hole <w>Wegpunkt</w>",
"sub": [],
"z": "Aspirants' Plaza",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<t>Labyrinth (Normal) abschließen</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crystal Veins</z> reisen",
"sub": [],
"z": "The Crystal Veins",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Daresso's Dream</z>",
"sub": [],
"z": "Daresso's Dream",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Grand Arena</z>",
"sub": [],
"z": "The Grand Arena",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crystal Veins</z> reisen",
"sub": [],
"z": "The Crystal Veins",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Kaom's Dream</z>",
"sub": [],
"z": "Kaom's Dream",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Kaom's Stronghold</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>",
"Den Brücken folgen"
],
"z": "Kaom's Stronghold",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Caldera of the King</a>, töte <k>King Kaom</k>, nimm <i>The Eye of Fury</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "King Kaom",
"npc": ""
},
{
"t": "<l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Grand Arena</z> reisen",
"sub": [],
"z": "The Grand Arena",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Ring of Blades</a>, töte <k>Daresso, King of Swords</k>, nimm <i>The Eye of Desire</i>",
"sub": [
"<d>↙</d> <i>Südwesten</i>, Ausgänge nehmen und <d>←</d> <i>Westen</i> halten"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Daresso",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crystal Veins</z> reisen",
"sub": [],
"z": "The Crystal Veins",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Lady Dialla</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Belly of the Beast Level 1</z>",
"sub": [],
"z": "The Belly of the Beast Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Belly of the Beast Level 2</z>",
"sub": [],
"z": "The Belly of the Beast Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Bowels of the Beast</a>, töte <k>Piety, the Abomination</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Piety",
"npc": ""
},
{
"t": "Sprich mit <i>Piety</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Harvest</z>",
"sub": [],
"z": "The Harvest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Doedre Darktongue</k>, nimm <i>Malachai's Lungs</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Doedre Darktongue",
"npc": ""
},
{
"t": "Finde und töte <k>Maligaro, The Inquisitor</k>, nimm <i>Malachai's Heart</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Maligaro",
"npc": ""
},
{
"t": "Finde und töte <k>Shavronne of Umbra</k>, nimm <i>Malachai's Entrails</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Shavronne of Umbra",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Corpus Malachus</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Corpus Malachus",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Black Core</a>, töte <k>Malachai, The Nightmare</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Malachai",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Eternal Nightmare</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Eternal Nightmare",
"e": 0,
"kt": "",
"npc": "Dialla"
},
{
"t": "Geh weiter nach <z>The Ascent</z>",
"sub": [],
"z": "The Ascent",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Aktiviere <i>The Resonator</i>, benutze <i>Oriath Portal</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 5,
"title": "Akt 5",
"tip": "Am Ende von Akt 5: −30 % auf alle Resistenzen. Gear vorher anpassen!",
"steps": [
{
"t": "Geh weiter nach <z>The Slave Pens</z>",
"sub": [],
"z": "The Slave Pens",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Overseer Krow</k>",
"sub": [
"<d>↓</d> <i>Süden</i> bis zum gehängten Karui",
"Im Uhrzeigersinn herum, dann <d>←</d> <i>Westen</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Overseer Krow",
"npc": ""
},
{
"t": "Geh weiter nach <z>Overseer's Tower</z>",
"sub": [],
"z": "Overseer's Tower",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Return to Oriath</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Return to Oriath",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Geh weiter nach <z>The Control Blocks</z>",
"sub": [],
"z": "The Control Blocks",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Miasmeter</i>",
"sub": [
"So weit wie möglich <d>←</d> <i>Westen</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Justicar Casticus</k>, nimm <i>Eyes of Zeal</i>",
"sub": [
"<d>↗</d> <i>Nordosten</i> vom <i>Miasmeter</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Justicar Casticus",
"npc": ""
},
{
"t": "Geh weiter nach <z>Oriath Square</z>",
"sub": [],
"z": "Oriath Square",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Templar Courts</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Templar Courts",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Chamber of Innocence</z>",
"sub": [
"Im Uhrzeigersinn herum",
"Hier bei Bedarf leveln: 40-42"
],
"z": "The Chamber of Innocence",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Sanctum of Innocence</a>, töte <k>High Templar Avarius</k>",
"sub": [
"<d>↖</d> <i>Nordwesten</i> gegen den Uhrzeigersinn spiralförmig"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "High Templar Avarius",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Key to Freedom</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Key to Freedom",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "In der Stadt die Quest <q>In Service to Science</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "In Service to Science",
"e": 0,
"kt": "",
"npc": "Vilenta"
},
{
"t": "In der Stadt die Quest <q>Death to Purity</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Death to Purity",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Chamber of Innocence</z> reisen",
"sub": [],
"z": "The Chamber of Innocence",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Torched Courts</z>",
"sub": [],
"z": "The Torched Courts",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ruined Square</z>",
"sub": [
"Gegen den Uhrzeigersinn herum"
],
"z": "The Ruined Square",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ossuary</z>",
"sub": [],
"z": "The Ossuary",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Sign of Purity</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Ruined Square</z> reisen",
"sub": [],
"z": "The Ruined Square",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Reliquary</z>",
"sub": [
"<d>↙</d> <i>Südwesten</i> bis zum Platz",
"Richtung <d>↓</d> <i>Süden</i>"
],
"z": "The Reliquary",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde 3× <i>Kitava's Torment</i>, in den Ecken suchen",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Kitava's Torments</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Kitava's Torments",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Ruined Square</z> reisen",
"sub": [],
"z": "The Ruined Square",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Cathedral Rooftop</z>",
"sub": [
"Richtung <d>↙</d> <i>Südwesten</i>"
],
"z": "The Cathedral Rooftop",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Cathedral Apex</a>, töte <k>Kitava, the Insatiable</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Kitava",
"npc": ""
},
{
"t": "Sprich mit <i>Lilly Roth</i>, segle nach Wraeclast",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 6,
"title": "Akt 6",
"tip": "Drei Passivpunkte in Akt 6 – keinen auslassen.",
"steps": [
{
"t": "Geh weiter nach <z>Lioneye's Watch</z>",
"sub": [],
"z": "Lioneye's Watch",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Twilight Strand</z>",
"sub": [],
"z": "The Twilight Strand",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Everything</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Everything",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Fallen from Grace</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Fallen from Grace",
"e": 0,
"kt": "",
"npc": "Lilly Roth"
},
{
"t": "Geh weiter nach <z>The Coast</z>",
"sub": [],
"z": "The Coast",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Mud Flats</z>",
"sub": [],
"z": "The Mud Flats",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>The Dishonoured Queen</k>, nimm <i>Eye of Conquest</i>",
"sub": [
"Ecke <d>↗</d> <i>Nordosten</i>, meist bei einem Haus"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Dishonoured Queen",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Karui Fortress</z>",
"sub": [],
"z": "The Karui Fortress",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Tukohama's Keep</a>, töte <k>Tukohama, Karui God of War</k>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>",
"Monstergruppe auf der Insel <d>↙</d> <i>Südwesten</i> töten für ein <i>Tattoo</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Tukohama",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ridge</z>",
"sub": [
"Richtung <d>↑</d> <i>Norden</i>"
],
"z": "The Ridge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lower Prison</z>",
"sub": [],
"z": "The Lower Prison",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Shavronne's Tower</z>",
"sub": [],
"z": "Shavronne's Tower",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Prison Rooftop</a>, töte <k>Shavronne the Returned</k> &amp; <k>Reassembled Brutus</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Shavronne the Returned",
"npc": ""
},
{
"t": "Geh nach <a>The Warden's Chambers</a>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Prisoner's Gate</z>",
"sub": [],
"z": "Prisoner's Gate",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Valley of the Fire Drinker</a>, töte <k>Abberath, the Cloven One</k>",
"sub": [
"Neben dem Weg die Kante hinunter"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Abberath",
"npc": ""
},
{
"t": "<l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Cloven One</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Cloven One",
"e": 0,
"kt": "",
"npc": "Bestel"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Prisoner's Gate</z> reisen",
"sub": [],
"z": "Prisoner's Gate",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Western Forest</z>",
"sub": [
"Dem Weg folgen",
"Nach der Fackel am Weg suchen",
"Dem Pfad in Richtung der Fackel folgen"
],
"z": "The Western Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Riverways</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Riverways",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Dem Weg folgen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Wetlands</z>",
"sub": [
"Nach 2 Säulen beim <w>Wegpunkt</w> suchen, dem Pfad folgen"
],
"z": "The Wetlands",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Spawning Ground</a>, töte <k>Ryslatha, the Puppet Mistress</k>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Ryslatha",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Father of War</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Father of War",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "In der Stadt die Quest <q>Essence of Umbra</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Essence of Umbra",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "In der Stadt die Quest <q>The Puppet Mistress</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Puppet Mistress",
"e": 0,
"kt": "",
"npc": "Tarkleigh"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Riverways</z> reisen",
"sub": [],
"z": "The Riverways",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Southern Forest</z>",
"sub": [
"Dem Weg bis zum Ende folgen",
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "The Southern Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Cavern of Anger</z>",
"sub": [],
"z": "The Cavern of Anger",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Nimm <i>The Black Flag</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Beacon</z>",
"sub": [
"Am Ufer entlang"
],
"z": "The Beacon",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <i>Pillar Push</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Zünde an: <i>Beacon</i>, wirf hinein: <i>The Black Flag</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Weylam Roth</i>, segle nach <z>The Brine King's Reef</z>",
"sub": [],
"z": "The Brine King's Reef",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Bring King's Throne</a>, töte <k>Tsoagoth, The Brine King</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Tsoagoth",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Wähle <i>Pantheons</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 7,
"title": "Akt 7",
"tip": "Drei Passivpunkte: Ralakesh, Gruthkul und Kishara's Star.",
"steps": [
{
"t": "Per <w>Wegpunkt</w> nach <z>The Bridge Encampment</z> reisen",
"sub": [],
"z": "The Bridge Encampment",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Broken Bridge</z>",
"sub": [],
"z": "The Broken Bridge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Silver Locket</i>",
"sub": [
"Dem Weg folgen, nach dem kaputten <w>Wegpunkt</w> suchen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crossroads</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Crossroads",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Fellshrine Ruins</z>",
"sub": [
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "The Fellshrine Ruins",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Crypt</z>",
"sub": [
"Dem Weg folgen"
],
"z": "The Crypt",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde <i>Sarcophagus</i> zum nächsten Stockwerk",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Maligaro's Map</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Crossroads</z> reisen",
"sub": [],
"z": "The Crossroads",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Chamber of Sins Level 1</z>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Chamber of Sins Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Aktiviere <i>Map Device</i> mit <i>Maligaro's Map</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Maligaro's Sanctum</z>",
"sub": [],
"z": "Maligaro's Sanctum",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Maligaro's Workshop</a>, töte <k>Maligaro, the Artist</k>, nimm <i>Black Venom</i>",
"sub": [
"Am Rand entlang, Brücken in den Ecken nehmen",
"Brücken meist in diagonal gegenüberliegenden Ecken"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Maligaro",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Essence of the Artist</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Essence of the Artist",
"e": 0,
"kt": "",
"npc": "Helena"
},
{
"t": "In der Stadt die Quest <q>The Silver Locket</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Silver Locket",
"e": 0,
"kt": "",
"npc": "Weylam Roth"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Chamber of Sins Level 1</z> reisen",
"sub": [],
"z": "The Chamber of Sins Level 1",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Web of Secrets</q> abgeben, nimm <i>Obsidian Key</i>",
"sub": [],
"z": "",
"k": "main",
"q": "Web of Secrets",
"e": 0,
"kt": "",
"npc": "Silk"
},
{
"t": "Geh weiter nach <z>The Chamber of Sins Level 2</z>",
"sub": [
"Gleiche Richtung wie zum <w>Wegpunkt</w>"
],
"z": "The Chamber of Sins Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Versteckter Schalter hinter <i>Trial of Ascendancy Plaque</i> → <i>Hidden Gem: Quality</i>"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Öffne <i>Secret Passage</i> ➜ <z>The Den</z>",
"sub": [],
"z": "The Den",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ashen Fields</z>",
"sub": [],
"z": "The Ashen Fields",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Forest Encampment</a>, töte <k>Greust, Lord of the Forest</k>",
"sub": [
"Richtung <d>↙</d> <i>Südwesten</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Greust",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Northern Forest</z>",
"sub": [],
"z": "The Northern Forest",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Causeway</z>",
"sub": [],
"z": "The Causeway",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Kishara's Star</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Vaal City</z>",
"sub": [],
"z": "The Vaal City",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde <w>Wegpunkt</w>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Northern Forest</z> reisen",
"sub": [],
"z": "The Northern Forest",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Dread Thicket</z>",
"sub": [],
"z": "The Dread Thicket",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm 7× <i>Firefly</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Den of Despair</a>, töte <k>Gruthkul, Mother of Despair</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Gruthkul",
"npc": ""
},
{
"t": "<l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Master of a Million Faces</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Master of a Million Faces",
"e": 0,
"kt": "",
"npc": "Eramir"
},
{
"t": "In der Stadt die Quest <q>Queen of Despair</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Queen of Despair",
"e": 0,
"kt": "",
"npc": "Eramir"
},
{
"t": "In der Stadt die Quest <q>Kishara's Star</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Kishara's Star",
"e": 0,
"kt": "",
"npc": "Weylam Roth"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Aspirants' Plaza</z> reisen",
"sub": [],
"z": "Aspirants' Plaza",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<t>Labyrinth (Cruel) abschließen</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Vaal City</z> reisen",
"sub": [],
"z": "The Vaal City",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Lighting the Way</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Lighting the Way",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Temple of Decay Level 1</z>",
"sub": [
"Im Raum mit der Grube <d>↙</d> <i>Südwesten</i> oder <d>↗</d> <i>Nordosten</i> nach einem Nebenraum mit <i>Corrupted Unique</i> suchen"
],
"z": "The Temple of Decay Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Temple of Decay Level 2</z>",
"sub": [],
"z": "The Temple of Decay Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Arakaali's Web</a>, töte <k>Arakaali, Spinner of Shadows</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Arakaali",
"npc": ""
}
]
},
{
"act": 8,
"title": "Akt 8",
"tip": "Drei Passivpunkte: Tolman, Gemling Legion, Yugul.",
"steps": [
{
"t": "Geh weiter nach <z>The Sarn Ramparts</z>",
"sub": [],
"z": "The Sarn Ramparts",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Sarn Encampment</z>",
"sub": [],
"z": "The Sarn Encampment",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Toxic Conduits</z>",
"sub": [
"Richtung <d>←</d> <i>Westen</i>"
],
"z": "The Toxic Conduits",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Doedre's Cesspool</z>",
"sub": [
"Schwarze Farbspritzer am Boden zeigen die Richtung"
],
"z": "Doedre's Cesspool",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Cauldron</a>, töte <k>Doedre the Vile</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Doedre the Vile",
"npc": ""
},
{
"t": "Geh nach <a>Sewer Outlet</a>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Quay</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Quay",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>Ankh of Eternity</i>",
"sub": [
"Der Wand <d>←</d> <i>Westen</i> folgen"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Resurrection Site</a>",
"sub": [
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Clarissa</i>, töte <k>Tolman</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Tolman",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Grain Gate</z>",
"sub": [],
"z": "The Grain Gate",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Gemling Legionnaires</k>",
"sub": [
"Den toten Wachen an den Türen folgen",
"Nach dem Buch-Symbol suchen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Gemling Legionnaires",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Imperial Fields</z>",
"sub": [
"Den toten Wachen an den Türen folgen"
],
"z": "The Imperial Fields",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Solaris Temple Level 1</z>",
"sub": [
"Dem Weg folgen bis <w>Wegpunkt</w>",
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Solaris Temple Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Solaris Temple Level 2</z>",
"sub": [],
"z": "The Solaris Temple Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Dawn, Harbinger of Solaris</k>, nimm <i>Sun Orb</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Dawn",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Essence of the Hag</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Essence of the Hag",
"e": 0,
"kt": "",
"npc": "Hargan"
},
{
"t": "In der Stadt die Quest <q>The Gemling Legion</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Gemling Legion",
"e": 0,
"kt": "",
"npc": "Maramoa"
},
{
"t": "In der Stadt die Quest <q>Love is Dead</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Love is Dead",
"e": 0,
"kt": "",
"npc": "Clarissa"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Solaris Temple Level 1</z> reisen",
"sub": [],
"z": "The Solaris Temple Level 1",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Solaris Concourse</z>",
"sub": [],
"z": "The Solaris Concourse",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Harbour Bridge</z>",
"sub": [
"Richtung <d>↙</d> <i>Südwesten</i>"
],
"z": "The Harbour Bridge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lunaris Concourse</z>",
"sub": [],
"z": "The Lunaris Concourse",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lunaris Temple Level 1</z>",
"sub": [],
"z": "The Lunaris Temple Level 1",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Lunaris Temple Level 2</z>",
"sub": [],
"z": "The Lunaris Temple Level 2",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Dusk, Harbinger of Lunaris</k>, nimm <i>Moon Orb</i>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Dusk",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Lunaris Concourse</z> reisen",
"sub": [],
"z": "The Lunaris Concourse",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Harbour Bridge</z>",
"sub": [
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "The Harbour Bridge",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Sky Shrine</a>, aktiviere <i>Statue of the Sisters</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Töte <k>Lunaris, Eternal Moon</k> &amp; <k>Solaris, Eternal Sun</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Lunaris",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Blood Aqueduct</z>",
"sub": [
"Hier bei Bedarf leveln: 58-62"
],
"z": "The Blood Aqueduct",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Highgate</z>",
"sub": [],
"z": "Highgate",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Lunaris Concourse</z> reisen",
"sub": [],
"z": "The Lunaris Concourse",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Bath House</z>",
"sub": [
"Richtung <d>↓</d> <i>Süden</i>"
],
"z": "The Bath House",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Auf der Seite <d>←</d> <i>Westen</i> suchen"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The High Gardens</z>",
"sub": [
"Auf der Seite <d>←</d> <i>Westen</i> suchen"
],
"z": "The High Gardens",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Pools of Terror</a>, töte <k>Yugul, Reflection of Terror</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Yugul",
"npc": ""
},
{
"t": "<l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Reflection of Terror</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Reflection of Terror",
"e": 0,
"kt": "",
"npc": "Hargan"
}
]
},
{
"act": 9,
"title": "Akt 9",
"tip": "Zwei Passivpunkte: Shakari und Garukhan.",
"steps": [
{
"t": "Per <w>Wegpunkt</w> nach <z>Highgate</z> reisen",
"sub": [],
"z": "Highgate",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Descent</z>",
"sub": [],
"z": "The Descent",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Vastiri Desert</z>",
"sub": [],
"z": "The Vastiri Desert",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>→</d> <i>Osten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und nimm <i>The Storm Blade</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Foothills</z>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Foothills",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"<d>↗</d> <i>Nordosten</i> bis zur Klippe",
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Boiling Lake</z>",
"sub": [],
"z": "The Boiling Lake",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>The Basilisk</k>, nimm <i>Basilisk Acid</i>",
"sub": [
"<d>↗</d> <i>Nordosten</i>, nach versteinerten Soldaten suchen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Basilisk",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Storm Blade</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "The Storm Blade",
"e": 0,
"kt": "",
"npc": "Petarus and Vanja"
},
{
"t": "In der Stadt die Quest <q>Queen of the Sands</q> abgeben, nimm <i>Bottled Storm</i>",
"sub": [],
"z": "",
"k": "pp",
"q": "Queen of the Sands",
"e": 0,
"kt": "",
"npc": "Irasha"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Vastiri Desert</z> reisen",
"sub": [],
"z": "The Vastiri Desert",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Oasis</z>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "The Oasis",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Sand Pit</a>, töte <k>Shakari, Queen of the Sands</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Shakari",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Queen of the Sands</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Queen of the Sands",
"e": 0,
"kt": "",
"npc": "Irasha"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Foothills</z> reisen",
"sub": [],
"z": "The Foothills",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Tunnel</z>",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "The Tunnel",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Vor <w>Wegpunkt</w>, erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Versteckter Schalter auf halbem Weg zu <i>Trial of Ascendancy Plaque</i> (Ecke gegenüber Eingang) → <i>Hidden Gem: Transfigured</i>"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Quarry</z>",
"sub": [],
"z": "The Quarry",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>↖</d> <i>Nordwesten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Shrine of the Winds</a>, töte <k>Garukhan, Queen of the Winds</k>, nimm <i>Sekhema Feather</i>",
"sub": [
"<d>↗</d> <i>Nordosten</i> oder <d>↙</d> <i>Südwesten</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Garukhan",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>The Ruler of Highgate</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "The Ruler of Highgate",
"e": 0,
"kt": "",
"npc": "Irasha"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Quarry</z> reisen",
"sub": [],
"z": "The Quarry",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Refinery</z>",
"sub": [
"<d>↖</d> <i>Nordwesten</i> oder <d>↗</d> <i>Nordosten</i>",
"Kanalgitter zu <a>Refinery Tunnels</a> suchen (an den Schienen)"
],
"z": "The Refinery",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>General Adus</k>, nimm <i>Trarthan Powder</i>",
"sub": [
"<d>↗</d> <i>Nordosten</i>, den Loren-Schienen folgen"
],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "General Adus",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Quarry</z> reisen",
"sub": [],
"z": "The Quarry",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Belly of the Beast</z>",
"sub": [],
"z": "The Belly of the Beast",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Rotting Core</z>",
"sub": [],
"z": "The Rotting Core",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>The Black Core</a>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Doedre's Despair</a>, töte <k>Doedre, Darksoul</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Doedre",
"npc": ""
},
{
"t": "Geh nach <a>Maligaro's Misery</a>, töte <k>Maligaro, The Broken</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Maligaro",
"npc": ""
},
{
"t": "Geh nach <a>Shavronne's Sorrow</a>, töte <k>Shavronne, Unbound</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Shavronne",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i> ➜ <a>The Black Heart</a>, töte <k>The Depraved Trinity</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "The Depraved Trinity",
"npc": ""
},
{
"t": "<l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
}
]
},
{
"act": 10,
"title": "Akt 10",
"tip": "Zwei Quests mit Passivpunkten: Vilenta und An End to Hunger. Danach Epilog – Maps!",
"steps": [
{
"t": "Per <w>Wegpunkt</w> nach <z>Oriath Docks</z> reisen",
"sub": [],
"z": "Oriath Docks",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Cathedral Rooftop</z>",
"sub": [],
"z": "The Cathedral Rooftop",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Cathedral Apex</a>, töte <k>Plaguewing</k>",
"sub": [
"Richtung <d>↑</d> <i>Norden</i>"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Plaguewing",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ravaged Square</z>",
"sub": [],
"z": "The Ravaged Square",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "platziere <l>Portal setzen</l> auf dem Platz",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Control Blocks</z>",
"sub": [
"Richtung <d>↓</d> <i>Süden</i>"
],
"z": "The Control Blocks",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Oriath Docks</z> reisen",
"sub": [],
"z": "Oriath Docks",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Safe Passage</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Safe Passage",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Nimm <l>Portal benutzen</l>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<w>Wegpunkt</w> anklicken, um ihn freizuschalten",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Ossuary</z>",
"sub": [],
"z": "The Ossuary",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "erledige <t>Aufstiegsprüfung</t>",
"sub": [
"Schalter vor den Zickzack-Wänden betätigen, gegenüber → <i>Hidden Gem: Facetor's Lens</i>"
],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Control Blocks</z> reisen",
"sub": [],
"z": "The Control Blocks",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Finde und töte <k>Vilenta</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 0,
"kt": "Vilenta",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Vilenta's Vengeance</q> abgeben",
"sub": [],
"z": "",
"k": "pp",
"q": "Vilenta's Vengeance",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>Aspirants' Plaza</z> reisen",
"sub": [],
"z": "Aspirants' Plaza",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "<t>Labyrinth (Merciless) abschließen</t>",
"sub": [],
"z": "",
"k": "trial",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Ravaged Square</z> reisen",
"sub": [],
"z": "The Ravaged Square",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Torched Courts</z>",
"sub": [
"Richtung <d>↘</d> <i>Südosten</i>"
],
"z": "The Torched Courts",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Desecrated Chambers</z>",
"sub": [
"Im Uhrzeigersinn herum"
],
"z": "The Desecrated Chambers",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Sanctum of Innocence</a>, töte <k>Avarius, Reassembled</k>, nimm <i>The Staff of Purity</i>",
"sub": [
"<d>↖</d> <i>Nordwesten</i> gegen den Uhrzeigersinn spiralförmig"
],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Avarius",
"npc": ""
},
{
"t": "<l>Ausloggen</l> (zurück in die Stadt)",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Bannon</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>Death and Rebirth</q> abgeben",
"sub": [],
"z": "",
"k": "main",
"q": "Death and Rebirth",
"e": 0,
"kt": "",
"npc": "Lani"
},
{
"t": "Per <w>Wegpunkt</w> nach <z>The Ravaged Square</z> reisen",
"sub": [],
"z": "The Ravaged Square",
"k": "travel",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Innocence</i>",
"sub": [
"Richtung <d>↗</d> <i>Nordosten</i>"
],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Canals</z>",
"sub": [],
"z": "The Canals",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>The Feeding Trough</z>",
"sub": [],
"z": "The Feeding Trough",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i>",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh nach <a>Altar of Hunger</a>, töte <k>Kitava, the Insatiable</k>",
"sub": [],
"z": "",
"k": "boss",
"q": "",
"e": 1,
"kt": "Kitava",
"npc": ""
},
{
"t": "Sprich mit <i>Sin</i> ➜ <z>Oriath Docks</z>",
"sub": [],
"z": "Oriath Docks",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Sprich mit <i>Lilly Roth</i>, segle von Oriath los",
"sub": [],
"z": "",
"k": "main",
"q": "",
"e": 0,
"kt": "",
"npc": ""
},
{
"t": "Geh weiter nach <z>Karui Shores</z>",
"sub": [],
"z": "Karui Shores",
"k": "main",
"q": "",
"e": 1,
"kt": "",
"npc": ""
},
{
"t": "In der Stadt die Quest <q>An End to Hunger</q> abgeben",
"sub": [
"<i>/passives</i> in den Chat tippen: prüft, ob du alle 24 Quest-Passivpunkte hast"
],
"z": "",
"k": "pp",
"q": "An End to Hunger",
"e": 0,
"kt": "",
"npc": "Lani"
}
]
}
];

// Passivpunkt-Quests (für die Checkliste)
window.PASSIVE_QUESTS = [
 [1, 'The Dweller of the Deep', 'Flooded Depths – Dweller töten', 1],
 [1, 'The Marooned Mariner', 'Ship Graveyard – Allflame & Fairgraves', 1],
 [2, 'Through Sacred Ground', 'Crypt Level 2 – Golden Hand', 1],
 [2, 'The Way Forward', 'Western Forest – Arteri, Emblem zu Bestel', 1],
 [2, 'Deal with the Bandits', 'Alle drei Banditen töten (Eramir)', 1],
 [3, "Victario's Secrets", 'Sewers – drei Büsten', 1],
 [3, "Piety's Pets", 'Lunaris Temple Level 2 – Piety', 1],
 [4, 'An Indomitable Spirit', 'Mines Level 2 – Deshret befreien', 1],
 [5, 'In Service to Science', 'Control Blocks – Miasmeter', 1],
 [5, "Kitava's Torments", 'Reliquary – drei Teile', 1],
 [6, 'The Father of War', 'Karui Fortress – Tukohama', 1],
 [6, 'The Cloven One', "Prisoner's Gate – Abberath", 1],
 [6, 'The Puppet Mistress', 'Wetlands – Ryslatha', 1],
 [7, 'The Master of a Million Faces', 'Crypt-Karte → Ralakesh', 1],
 [7, 'Queen of Despair', 'Dread Thicket – Gruthkul', 1],
 [7, "Kishara's Star", 'Causeway – Truhe am Ende', 1],
 [8, 'Love is Dead', 'Quay – Ankh & Tolman', 1],
 [8, 'The Gemling Legion', 'Grain Gate', 1],
 [8, 'Reflection of Terror', 'High Gardens – Yugul', 1],
 [9, 'Queen of the Sands', 'Vastiri Desert – Shakari', 1],
 [9, 'The Ruler of Highgate', 'Quarry – Garukhan', 1],
 [10, "Vilenta's Vengeance", 'Control Blocks – Vilenta', 1],
 [10, 'An End to Hunger', 'Feeding Trough – Kitava', 2],
];
